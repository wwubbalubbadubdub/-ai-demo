@echo off
cd /d "%~dp0"
"..\.venv\Scripts\python.exe" demo\live2d_capture_demo.py %*
