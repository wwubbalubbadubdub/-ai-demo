"""Noise-ratio curriculum and heartbeat cache prototype.

This replaces the "global amplitude spring" idea with graded behavior targets:

    full anger -> frown + head shake -> sigh + idle

At lower useful-context ratios the result is not the same motion at lower
amplitude; specific action tokens drop out and neutral/residual tokens enter.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import random
from typing import Iterable


@dataclass
class BehaviorTarget:
    ratio: float
    label: str
    tokens: dict[str, float]

    def to_dict(self) -> dict:
        return asdict(self)


# Explicit ladder: the important part is not a scalar amplitude but which
# action components survive as the useful signal weakens.
ANGER_LADDER: tuple[BehaviorTarget, ...] = (
    BehaviorTarget(1.00, "anger_full", {"head_snap": 0.95, "glare": 0.90, "frown": 0.70, "tail_lash": 0.80, "idle": 0.02}),
    BehaviorTarget(0.75, "anger_high", {"glare": 0.80, "frown": 0.75, "head_shake": 0.55, "tail_slow": 0.45, "idle": 0.15}),
    BehaviorTarget(0.50, "anger_mid", {"frown": 0.70, "head_shake": 0.40, "sigh": 0.30, "tail_still": 0.25, "idle": 0.45}),
    BehaviorTarget(0.25, "anger_residual", {"frown": 0.35, "sigh": 0.25, "idle": 0.80, "look_away": 0.20}),
    BehaviorTarget(0.00, "neutral_idle", {"idle": 1.00}),
)


def target_for_ratio(ratio: float, ladder: Iterable[BehaviorTarget] = ANGER_LADDER) -> BehaviorTarget:
    ratio = max(0.0, min(1.0, float(ratio)))
    items = list(ladder)
    return min(items, key=lambda item: abs(item.ratio - ratio))


def noise_count_for_ratio(ratio: float, *, max_noise: int = 8) -> int:
    ratio = max(0.0, min(1.0, float(ratio)))
    if ratio >= 1.0:
        return 0
    if ratio <= 0.0:
        return max_noise
    return max(1, min(max_noise, round((1.0 - ratio) / ratio)))


def build_mixture_example(
    useful_text: str,
    noise_pool: Iterable[str],
    ratio: float,
    *,
    rng: random.Random | None = None,
    max_noise: int = 8,
) -> dict:
    """Build one training context and its behavior target.

    The ratio is the useful signal share. 0.5 means roughly one useful and one
    noise sentence; 0.25 means one useful and three noise sentences. Positions
    are shuffled so the model cannot use "useful first" as a shortcut.
    """

    rng = rng or random.Random(13)
    ratio = max(0.0, min(1.0, float(ratio)))
    pool = [text for text in noise_pool if text and text != useful_text]
    count = noise_count_for_ratio(ratio, max_noise=max_noise)
    if count > len(pool) and pool:
        count = len(pool)
    noise = rng.sample(pool, count) if count else []
    parts = ([useful_text] if ratio > 0 else []) + noise
    rng.shuffle(parts)
    target = target_for_ratio(ratio)
    return {
        "ratio": ratio,
        "noise_count": len(noise),
        "context": parts,
        "target": target.to_dict(),
    }


def ratio_schedule(steps: int = 5) -> list[float]:
    steps = max(2, int(steps))
    return [round(1.0 - index / (steps - 1), 2) for index in range(steps)]

class SignalRatioWindow:
    """Tracks how much useful signal remains versus accumulated neutral noise.

    This is not an amplitude spring. The ratio only chooses which rung of the
    behavior ladder is active; each rung has different action tokens.
    """

    def __init__(
        self,
        *,
        half_life: float = 22.0,
        noise_per_second: float = 0.015,
        initial_noise: float = 0.12,
    ) -> None:
        self.half_life = max(0.1, float(half_life))
        self.noise_per_second = max(0.0, float(noise_per_second))
        self.useful_weight = 0.0
        self.noise_weight = max(0.0, float(initial_noise))
        self._last_time: float | None = None

    def _advance(self, now: float) -> None:
        if self._last_time is None:
            self._last_time = now
            return
        dt = max(0.0, float(now) - self._last_time)
        if dt <= 0:
            return
        import math

        self.useful_weight *= math.exp(-dt * math.log(2.0) / self.half_life)
        self.noise_weight += self.noise_per_second * dt
        self._last_time = now

    def add_useful(self, now: float, weight: float = 1.0) -> float:
        self._advance(now)
        self.useful_weight += max(0.0, float(weight))
        return self.ratio

    def add_noise(self, now: float, weight: float = 0.1) -> float:
        self._advance(now)
        self.noise_weight += max(0.0, float(weight))
        return self.ratio

    def advance(self, now: float) -> float:
        self._advance(now)
        return self.ratio

    @property
    def ratio(self) -> float:
        total = self.useful_weight + self.noise_weight
        if total <= 1e-9:
            return 0.0
        return max(0.0, min(1.0, self.useful_weight / total))

    def target(self, ladder: Iterable[BehaviorTarget] = ANGER_LADDER) -> BehaviorTarget:
        return target_for_ratio(self.ratio, ladder)

# A noise curriculum can also be built by progressively corrupting one useful
# sentence, instead of mixing in unrelated sentences. This models ASR drift,
# truncation, repetition, and masking as one continuous degradation path.
def distort_text(text: str, level: float, *, rng: random.Random | None = None) -> str:
    """Degrade one sentence toward noise while keeping a trace of its shape."""

    rng = rng or random.Random(17)
    source = (text or "").strip()
    level = max(0.0, min(1.0, float(level)))
    if not source or level <= 0.0:
        return source
    chars = list(source)
    remove = int(round(len(chars) * level * 0.55))
    replace = int(round(len(chars) * level * 0.25))
    if remove:
        for index in sorted(rng.sample(range(len(chars)), min(remove, len(chars))), reverse=True):
            chars.pop(index)
    for _ in range(min(replace, len(chars))):
        index = rng.randrange(len(chars))
        chars[index] = rng.choice("呃啊嗯哦这个那个就是然后呢吧嘛啊？？……")
    result = "".join(chars)
    if level >= 0.5:
        result = result + "……" * int(level * 3)
    if level >= 0.75:
        result = "".join(rng.choice(result) for _ in range(max(1, len(result) // 2))) + result[-max(1, len(result) // 3):]
    return result.strip()


def build_degradation_example(
    useful_text: str,
    level: float,
    *,
    steps: int = 4,
    rng: random.Random | None = None,
) -> dict:
    """Build a context where one sentence is progressively distorted.

    level 0 is the clean sentence; level 1 is mostly noise. The returned ratio
    is the useful share, so the behavior ladder changes with the distortion.
    """

    rng = rng or random.Random(23)
    level = max(0.0, min(1.0, float(level)))
    steps = max(2, int(steps))
    ratio = 1.0 - level
    context = []
    for index in range(steps):
        local = level * index / (steps - 1)
        context.append(distort_text(useful_text, local, rng=rng))
    if ratio <= 0.0:
        context = [distort_text(useful_text, 1.0, rng=rng)]
    return {
        "ratio": ratio,
        "level": level,
        "context": context,
        "target": target_for_ratio(ratio).to_dict(),
    }