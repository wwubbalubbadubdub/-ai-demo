# Local text compiler prototype

This is the first working slice of the motion-language pipeline. It is **not in the desktop app yet**.

It currently has six pieces:

1. `canonicalizer.py` — local spaCy-based Chinese SVO extraction.
2. `lexicon.py` — controlled seed vocabulary and category validation.
3. `phrase.py` — frame-to-phrase builder, closed-vocabulary validator, command rejection.
4. `teacher.py` — DeepSeek teacher prompt and strict JSON parser (no API call is made).
5. `noise_curriculum.py` — useful/noise ratio schedules and a behavior ladder.
6. `heartbeat.py` — low-frequency cognition ticks with a bounded cache.

No paid API is used. The only dependency is spaCy plus its Chinese model, in `.venv-capture`.

`affect.py` is kept only as an earlier spring/damper baseline. It is **not the recommended path** anymore.

## Why this exists

The requirements are:

- distinguish `我骂了他` from `我被他骂了` and `他把我骂了`;
- keep meaningful attributives and negation;
- remove topic/inversion/omission noise where possible;
- never collapse the text into a single "happy/sad" label;
- when the emotional signal weakens, do not simply scale the same motion down;
- instead, let the behavior degrade through different action tokens;
- support noisy, mostly irrelevant input text;
- run a small model at low frequency with cache hits, not every frame.

## Canonicalization

Example:

```json
{
  "source": "我被他狠狠骂了一顿。",
  "canonical": "他狠狠骂我",
  "subject": "他",
  "predicate": "骂",
  "object": "我",
  "attributives": ["狠狠"],
  "negated": false,
  "passive": true,
  "speaker_role": "patient"
}
```

```json
{
  "source": "我骂了他。",
  "canonical": "我骂他",
  "subject": "我",
  "predicate": "骂",
  "object": "他",
  "speaker_role": "agent"
}
```

This preserves actor/patient roles, negation (`不是`), possessives (`他的气`), complements (`可爱`), topics, and subject omission with a known speaker.

## Controlled lexicon and teacher

The seed lexicon currently has **196 tokens** across 11 categories. It is a
schema and a high-value seed, not the final 800–1000 word vocabulary.

The intended expansion path is:

1. tokenize the subtitle/chat corpus;
2. keep motion-relevant verbs, affect, manner, body cues, and social events;
3. review duplicates and category conflicts;
4. merge into this lexicon without changing the runtime contract.

`PhraseBuilder` converts a canonical frame to a descriptive phrase such as:

```text
他/骂/我/委屈/难过/狠狠/低头/移开视线
```

It keeps subject/object roles, so `我骂他` and `他骂我` remain different. It is
not a command sequence.

`PhraseValidator` rejects tokens outside the closed lexicon, wrong category
placement, phrases with no affect/body cue, and command-like markers.

`teacher.py` builds the DeepSeek prompt with the closed vocabulary and a strict
JSON schema, then parses and validates the reply. The API is **not called** by
this prototype; a caller can reuse the existing chat client or write a batch.
## Noise-ratio behavior ladder

The useful signal is mixed with irrelevant sentences at decreasing ratios:

```text
1.00  full anger: head snap, glare, frown, tail lash
0.75  glare, frown, head shake, slow tail
0.50  frown, head shake, sigh, mostly still
0.25  small frown, sigh, look away, idle
0.00  neutral idle
```

The important point: these are **different tokens**, not the same motion multiplied by 0.5. The behavior degrades semantically.

Training data can be built with:

```python
build_mixture_example(
    "他骂我。",
    noise_pool=["今天可能下雨。", "文件已经保存。", "现在三点。"],
    ratio=0.25,
)
```

Noise is randomly placed, so the model cannot learn "useful sentence is always first".

`SignalRatioWindow` models the slow loss of useful signal:

```text
useful_weight decays with a half-life
noise_weight accumulates over time
ratio = useful / (useful + noise)
```

At each rung, a different behavior target is selected. This is still a decay, but it decays the **signal ratio**, not every motion amplitude.

## Heartbeat and cache

The semantic model should not run every frame.

- Rendering: 30/60 FPS, independent.
- Cognition heartbeat: 0.25–2 Hz, configurable.
- Cache: TTL and max entries, keyed by normalized context.
- A **new input key wakes immediately** for responsiveness.
- Same fresh key within TTL: cache hit, no model call.
- Expired or changed key: one low-cost local computation.

Typical defaults in the prototype:

```text
interval = 4.0 s
ttl = 30.0 s
max_entries = 128
```

No DeepSeek call is made per heartbeat. DeepSeek, if used, should be an offline teacher that fills transition ladders or labels batches.

## Tiny model demo

A small CPU model is included:

- features: 2244 (hashed character n-grams + 196 lexicon indicators)
- model: one hidden layer, 64 units, 57 multi-label behavior outputs
- training data: 1,993 synthetic Chinese templates
- training: pure numpy, no GPU, no paid API

Artifacts:

- `artifacts/tiny_model.npz`
- `artifacts/tiny_model.json`
- `artifacts/demo.md`
- `artifacts/demo.json`

Run predictions:

```powershell
.\.venv-capture\Scripts\python.exe -m tools.text_compiler.predict "我被他狠狠骂了一顿。"
```

Important: this demo is trained on **synthetic templates**, not on the provided video. It proves the text → canonical frame → behavior tokens pipeline and the low-cost training path. It does not yet have real human-labeled motion data.

## Demo

```powershell
.\.venv-capture\Scripts\python.exe -m tools.text_compiler.demo
```

It writes `.tmp_analysis/noise_heartbeat_demo.json`.

## Tests

```powershell
.\.venv-capture\Scripts\python.exe -m unittest discover -s tools\text_compiler\tests -t . -v
```

Current coverage (40 tests):

- active SVO;
- passive reordering;
- 把 construction;
- omitted subject with a known speaker;
- topic extraction;
- negation + possessive object;
- complement clauses;
- agentless passive;
- noise-ratio ladder is not uniform amplitude scaling;
- mixture counts and shuffled placement;
- useful ratio decreases over time;
- behavior ladder changes at lower ratios;
- heartbeat cache hit avoids model call;
- immediate wake on new input;
- TTL expiry and bounded cache;
- deterministic simulations;
- seed lexicon duplicates and category coverage;
- phrase builder preserves active/passive roles;
- closed-vocabulary and command rejection;
- teacher prompt and strict JSON parsing;
- feature-encoder determinism;
- toy training loss decreases;
- saved demo model loads and predicts 生气 for 我骂了他;
- question content-verb parsing;
- weather sentence does not infer a speaker.

## Current limitations

- spaCy's small parser is not perfect for long clauses, irony, and nested clauses.
- `speaker_role` for deeply embedded complements is approximate.
- The lexicon is a 196-token seed; the 800–1000 word expansion is not done.
- The included student model is trained only on synthetic templates; real-input quality is not yet validated.
- The DeepSeek teacher prompt is implemented but not executed here (no API key; budget untouched).
- No Live2D motion tokens are connected to the model yet.
- No Live2D motion tokens are connected yet.
- The behavior ladder is hand-authored; DeepSeek can later fill transition ladders offline.
- The old `affect.py` spring baseline remains for comparison only.

## Next steps

1. Expand the 196-token seed lexicon to 800–1000 from the subtitle/chat corpus.
2. Use DeepSeek offline to compress useful/noise mixtures into codebook phrases.
3. Train a small local student: frozen sentence encoder + relevance head + behavior token head.
4. Add a transition ladder generated offline for each emotion pair.
5. Connect `motion_energy`/behavior tokens to the Live2D layer.
6. Evaluate on held-out noisy contexts and measure cache/compute cost.