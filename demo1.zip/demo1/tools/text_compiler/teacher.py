"""DeepSeek teacher prompts and strict validation for phrase compression.

No API request is made here. The caller can use the returned messages with the
existing chat client, or write them to a JSONL batch file.
"""

from __future__ import annotations

import json
import re
from typing import Any

from .canonicalizer import CanonicalFrame
from .lexicon import CATEGORY_LABELS, DEFAULT_LEXICON, Lexicon
from .phrase import PhraseValidator, SemanticPhrase


class TeacherFormatError(ValueError):
    pass


def allowed_tokens_text(lexicon: Lexicon = DEFAULT_LEXICON) -> str:
    lines = []
    for category, label in CATEGORY_LABELS.items():
        words = "、".join(lexicon.by_category(category))
        lines.append(f"- {label}({category}): {words}")
    return "\n".join(lines)


def teacher_system_prompt(lexicon: Lexicon = DEFAULT_LEXICON) -> str:
    return f"""你是“动作语义压缩器”，不是聊天助手，也不是动作指令生成器。

任务：把用户输入/字幕压缩成一个很短的、描述性的语义短语，供本地小模型生成 Live2D 动作。

必须遵守：
1. 必须保留主谓宾的角色，不能把“我骂他”和“他骂我”压成同一件事。
2. 保留有区分度的定语、状语、否定、情态；去掉倒装、重复、语气词和无关内容。
3. 不要只输出“开心/生气/害羞”这种心情标签；要包含事件、对象、方式和身体反应。
4. 不要写成命令，例如“请微笑”“给我摇头”“你必须害羞”。要写成第三视角或省略主语的描述，例如“他/骂/我/委屈/低头”。
5. 只能使用下面词库中的词；词库外的内容不要硬编。
6. 输出严格 JSON，不要 markdown，不要解释。
7. 如果不确定，降低 confidence，不要编造细节。

可用词库：
{allowed_tokens_text(lexicon)}

输出 JSON 结构：
{{
  "scene": {{"subject": "角色或 null", "predicate": "动作", "object": "角色或 null"}},
  "affect": ["情绪"],
  "manner": ["方式"],
  "body": ["身体动作"],
  "intensity": "强度或 null",
  "modality": ["否定/情态"],
  "descriptor": ["表演质感"],
  "confidence": 0.0
}}
"""


def build_teacher_messages(
    text: str,
    frame: CanonicalFrame | None = None,
    lexicon: Lexicon = DEFAULT_LEXICON,
) -> list[dict[str, str]]:
    context = ""
    if frame is not None:
        context = (
            "\n已规范化信息（请优先保留这些角色关系）：\n"
            f"主语={frame.subject} 谓语={frame.predicate} 宾语={frame.object} "
            f"定语={frame.attributives} 否定={frame.negated} 被动={frame.passive} "
            f"主题={frame.topic} 说话者角色={frame.speaker_role}\n"
        )
    user = f"输入文本：{text}{context}\n请只输出 JSON。"
    return [
        {"role": "system", "content": teacher_system_prompt(lexicon)},
        {"role": "user", "content": user},
    ]


def _extract_json(reply: str) -> dict[str, Any]:
    text = (reply or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        raise TeacherFormatError("回复中没有 JSON 对象")
    try:
        data = json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise TeacherFormatError(f"JSON 解析失败: {exc}") from exc
    if not isinstance(data, dict):
        raise TeacherFormatError("JSON 根节点必须是对象")
    return data


def parse_teacher_reply(
    reply: str,
    lexicon: Lexicon = DEFAULT_LEXICON,
) -> SemanticPhrase:
    phrase = SemanticPhrase.from_dict(_extract_json(reply))
    try:
        return PhraseValidator(lexicon).validate(phrase)
    except ValueError as exc:
        raise TeacherFormatError(str(exc)) from exc