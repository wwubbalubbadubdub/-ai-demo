"""Tiny numpy-only multi-label behavior model.

The demo is intentionally small: hashed character n-grams + a one-hidden-layer
MLP. It is not a language model; it maps text to a set of controlled
affect/body tokens and can run on CPU.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Iterable

import numpy as np

from .lexicon import DEFAULT_LEXICON

BEHAVIOR_LABELS: tuple[str, ...] = (
    "开心", "难过", "生气", "害羞", "委屈", "惊讶", "害怕", "安心",
    "疲惫", "得意", "尴尬", "内疚", "无奈", "期待", "失望", "烦躁",
    "温柔", "冷漠", "紧张", "放松", "心动", "心虚", "不服", "嘴硬",
    "心软", "炸毛", "满足", "寂寞", "平静",
    "低头", "抬头", "歪头", "摇头", "点头", "皱眉", "瞪眼", "移开视线",
    "抿嘴", "咬唇", "笑", "叹气", "脸红", "缩肩", "后退", "靠近",
    "伸手", "摸头", "拍肩", "抓住", "尾巴摆动", "停住", "垂下",
    "转身", "僵住", "躲开", "压笑", "盯着",
)
LABEL_INDEX = {label: index for index, label in enumerate(BEHAVIOR_LABELS)}


def normalize(text: str) -> str:
    return re.sub(r"\s+", "", text or "").strip()


class FeatureEncoder:
    """Stable hashed character n-grams plus controlled lexicon presence."""

    def __init__(self, hash_dim: int = 2048, lexicon=DEFAULT_LEXICON) -> None:
        self.hash_dim = int(hash_dim)
        self.lexicon_tokens = tuple(entry.text for entry in lexicon.entries)
        self.dim = self.hash_dim + len(self.lexicon_tokens)

    @staticmethod
    def _bucket(ngram: str, modulo: int) -> int:
        digest = hashlib.blake2b(ngram.encode("utf-8"), digest_size=4).digest()
        return int.from_bytes(digest, "little") % modulo

    def encode(self, text: str) -> np.ndarray:
        value = normalize(text)
        vector = np.zeros(self.dim, dtype=np.float32)
        for n in (1, 2, 3):
            if len(value) < n:
                continue
            for index in range(len(value) - n + 1):
                vector[self._bucket(value[index:index + n], self.hash_dim)] += 1.0
        for index, token in enumerate(self.lexicon_tokens):
            if token and token in value:
                vector[self.hash_dim + index] = 1.0
        np.log1p(vector, out=vector)
        norm = float(np.linalg.norm(vector))
        if norm > 0:
            vector /= norm
        return vector

    def encode_many(self, texts: Iterable[str]) -> np.ndarray:
        return np.vstack([self.encode(text) for text in texts])


@dataclass
class Prediction:
    label: str
    probability: float


class TinyBehaviorModel:
    def __init__(
        self,
        input_dim: int,
        labels: tuple[str, ...] = BEHAVIOR_LABELS,
        hidden: int = 48,
        seed: int = 7,
    ) -> None:
        self.input_dim = int(input_dim)
        self.labels = tuple(labels)
        self.hidden = int(hidden)
        rng = np.random.default_rng(seed)
        self.W1 = rng.normal(0.0, np.sqrt(2.0 / self.input_dim), (self.input_dim, self.hidden)).astype(np.float32)
        self.b1 = np.zeros(self.hidden, dtype=np.float32)
        self.W2 = rng.normal(0.0, np.sqrt(1.0 / self.hidden), (self.hidden, len(self.labels))).astype(np.float32)
        self.b2 = np.zeros(len(self.labels), dtype=np.float32)

    @staticmethod
    def _sigmoid(values: np.ndarray) -> np.ndarray:
        values = np.clip(values, -30.0, 30.0)
        return 1.0 / (1.0 + np.exp(-values))

    def forward(self, X: np.ndarray) -> np.ndarray:
        hidden = np.maximum(0.0, X @ self.W1 + self.b1)
        return self._sigmoid(hidden @ self.W2 + self.b2)

    def train(
        self,
        X: np.ndarray,
        Y: np.ndarray,
        *,
        epochs: int = 100,
        batch_size: int = 64,
        learning_rate: float = 0.08,
        weight_decay: float = 1e-4,
        seed: int = 7,
        verbose: bool = False,
    ) -> list[float]:
        rng = np.random.default_rng(seed)
        n = X.shape[0]
        losses: list[float] = []
        velocity = [np.zeros_like(self.W1), np.zeros_like(self.b1), np.zeros_like(self.W2), np.zeros_like(self.b2)]
        for epoch in range(epochs):
            order = rng.permutation(n)
            epoch_loss = 0.0
            for start in range(0, n, batch_size):
                batch = order[start:start + batch_size]
                xb, yb = X[batch], Y[batch]
                h_pre = xb @ self.W1 + self.b1
                h = np.maximum(0.0, h_pre)
                logits = h @ self.W2 + self.b2
                probs = self._sigmoid(logits)
                eps = 1e-7
                loss = -np.mean(yb * np.log(probs + eps) + (1.0 - yb) * np.log(1.0 - probs + eps))
                loss += weight_decay * (np.sum(self.W1 ** 2) + np.sum(self.W2 ** 2)) / max(1, n)
                epoch_loss += float(loss) * len(batch)
                d_logits = (probs - yb) / len(batch)
                dW2 = h.T @ d_logits + weight_decay * self.W2
                db2 = np.sum(d_logits, axis=0)
                d_hidden = (d_logits @ self.W2.T) * (h_pre > 0.0)
                dW1 = xb.T @ d_hidden + weight_decay * self.W1
                db1 = np.sum(d_hidden, axis=0)
                grads = [dW1, db1, dW2, db2]
                params = [self.W1, self.b1, self.W2, self.b2]
                for index, (param, grad) in enumerate(zip(params, grads)):
                    velocity[index] = 0.9 * velocity[index] - learning_rate * grad
                    param += velocity[index]
            avg = epoch_loss / max(1, n)
            losses.append(avg)
            if verbose and (epoch % 10 == 0 or epoch == epochs - 1):
                print(f"epoch {epoch:03d} loss {avg:.4f}")
        return losses

    def predict_top(self, text: str, encoder: FeatureEncoder, k: int = 6) -> list[Prediction]:
        vector = encoder.encode(text)[None, :]
        probs = self.forward(vector)[0]
        order = np.argsort(probs)[::-1][:max(1, int(k))]
        return [Prediction(self.labels[index], float(probs[index])) for index in order]

    def save(self, path: str | Path, encoder: FeatureEncoder, meta: dict | None = None) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        np.savez(
            target,
            W1=self.W1,
            b1=self.b1,
            W2=self.W2,
            b2=self.b2,
            labels=np.array(self.labels, dtype=object),
            input_dim=self.input_dim,
            hidden=self.hidden,
        )
        metadata = {
            "labels": list(self.labels),
            "input_dim": self.input_dim,
            "hidden": self.hidden,
            "hash_dim": encoder.hash_dim,
            **(meta or {}),
        }
        target.with_suffix(".json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, path: str | Path, hash_dim: int = 2048) -> tuple["TinyBehaviorModel", FeatureEncoder, dict]:
        target = Path(path)
        data = np.load(target, allow_pickle=True)
        labels = tuple(str(x) for x in data["labels"].tolist())
        model = cls(int(data["input_dim"]), labels=labels, hidden=int(data["hidden"]))
        model.W1 = data["W1"]
        model.b1 = data["b1"]
        model.W2 = data["W2"]
        model.b2 = data["b2"]
        meta_path = target.with_suffix(".json")
        metadata = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
        encoder = FeatureEncoder(int(metadata.get("hash_dim", hash_dim)))
        return model, encoder, metadata