"""Canonical Chinese SVO extraction for motion-language compression.

This is a local, free prototype. It uses spaCy's Chinese model to recover an
explicit subject / predicate / object from input such as passives, ba
constructions, topic-comment sentences, and dropped subjects. The output is a
short descriptive frame, not a command.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import re
from typing import Any

_FILLERS = ("呃", "啊", "嗯", "唉", "那个", "就是说", "然后", "所以说")
_NEGATIONS = {"不", "没", "没有", "不是", "别", "未", "无", "并非"}
_TRIM = "，。！？!?；;：:、,.…~～ \t\r\n"
_IMPERSONAL = {"下雨", "下雪", "天亮", "天黑", "打雷", "起风"}


def clean_text(text: str) -> str:
    """Remove leading fillers and sentence punctuation, keeping negation."""

    value = (text or "").strip()
    if not value:
        return ""
    pattern = r"^(?:" + "|".join(re.escape(x) for x in _FILLERS) + r")[，,、\s]*"
    value = re.sub(pattern, "", value)
    value = re.sub(r"[ \t\r\n]+", "", value)
    return value.strip(_TRIM)


@dataclass
class CanonicalFrame:
    source: str
    canonical: str
    subject: str | None = None
    predicate: str | None = None
    object: str | None = None
    attributives: list[str] = field(default_factory=list)
    complement: str | None = None
    topic: str | None = None
    negated: bool = False
    passive: bool = False
    subject_inferred: bool = False
    speaker_role: str | None = None
    parser: str = "spacy"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _subtree_text(token) -> str:
    return "".join(item.text for item in token.subtree if not item.is_punct)


def _first_child(token, deps: set[str]):
    for child in token.children:
        if child.dep_ in deps:
            return child
    return None


class ChineseCanonicalizer:
    """Dependency-based canonicalizer; intentionally small and local."""

    def __init__(self, model_name: str = "zh_core_web_sm") -> None:
        self.model_name = model_name
        self._nlp = None

    def _load(self):
        if self._nlp is None:
            try:
                import spacy
            except ImportError as exc:
                raise RuntimeError(
                    "需要先安装 spaCy 和中文模型："
                    "pip install spacy && python -m spacy download zh_core_web_sm"
                ) from exc
            try:
                self._nlp = spacy.load(self.model_name)
            except OSError as exc:
                raise RuntimeError(
                    f"找不到中文模型 {self.model_name}；"
                    "请运行 python -m spacy download zh_core_web_sm"
                ) from exc
        return self._nlp

    def canonicalize(self, text: str, speaker: str = "我") -> CanonicalFrame:
        source = (text or "").strip()
        cleaned = clean_text(source)
        if not cleaned:
            return CanonicalFrame(source=source, canonical="", parser="empty")

        # Keep the original punctuation for sentence segmentation; stripping it
        # can change spaCy's dependency tree substantially.
        doc = self._load()(source)
        root = next((t for t in doc if t.dep_ == "ROOT"), None)
        if root is None or root.pos_ in {"PUNCT", "AUX", "PART"}:
            candidates = [
                t for t in doc
                if t.pos_ in {"VERB", "ADJ"}
                and any(c.dep_ in {"nsubj", "nsubjpass", "dobj", "obj"} for c in t.children)
            ]
            if candidates:
                root = max(
                    candidates,
                    key=lambda t: sum(
                        1 for c in t.children
                        if c.dep_ in {"nsubj", "nsubjpass", "dobj", "obj"}
                    ),
                )
        if root is None:
            return CanonicalFrame(source=source, canonical=cleaned, parser="fallback")

        children = list(root.children)
        topic_token = next((t for t in doc if t.dep_ == "nmod:topic"), None)
        topic = _subtree_text(topic_token) if topic_token is not None else None

        patient_token = next((t for t in children if t.dep_ == "nsubjpass"), None)
        agent_token = next((t for t in children if t.dep_ == "nsubj" and t is not patient_token), None)
        passive = patient_token is not None

        # Ba construction: the object often has dep="dep" and sits before ROOT.
        ba_object = None
        ba_token = next((t for t in children if t.dep_ == "aux:ba"), None)
        if ba_token is not None:
            candidates = [
                t for t in doc
                if ba_token.i < t.i < root.i
                and not t.is_punct
                and t.pos_ in {"PRON", "NOUN", "PROPN"}
            ]
            if candidates:
                ba_object = candidates[0]

        subject_token = agent_token if passive else next(
            (t for t in children if t.dep_ == "nsubj"), None
        )
        object_token = patient_token if passive else (
            ba_object
            or _first_child(root, {"dobj", "obj"})
        )

        # A coerced object after 被 with no agent, e.g. 我被骂了.
        if passive and agent_token is None:
            subject_token = None

        impersonal = root.text in _IMPERSONAL
        subject_inferred = False
        if subject_token is None and not passive and not impersonal:
            subject_inferred = True

        subject = (
            _subtree_text(subject_token)
            if subject_token is not None
            else (speaker if not passive and not impersonal else None)
        )
        obj = _subtree_text(object_token) if object_token is not None else None



        mods: list[str] = []
        negated = False
        for child in children:
            if child.dep_ == "advmod":
                mods.append(_subtree_text(child))
                if child.text in _NEGATIONS or child.text.startswith("不"):
                    negated = True
            elif child.dep_ in {"nmod:prep", "amod"}:
                # e.g. "凭什么觉得"; keep short prepositional modifiers.
                text_part = _subtree_text(child)
                if len(text_part) <= 8:
                    mods.append(text_part)
        # Deduplicate while preserving order.
        mods = list(dict.fromkeys(mods))

        comp_token = _first_child(root, {"ccomp", "xcomp"})
        complement = _subtree_text(comp_token) if comp_token is not None else None

        predicate = root.text
        if passive:
            if subject:
                canonical = f"{subject}{''.join(mods)}{predicate}{obj or ''}"
            else:
                canonical = f"{obj or speaker}被{''.join(mods)}{predicate}"
        else:
            leading = subject or (speaker if not impersonal else "")
            canonical = f"{leading}{''.join(mods)}{predicate}{obj or ''}{complement or ''}"

        speaker_role = "observer"
        if subject and speaker in subject:
            speaker_role = "agent"
        elif obj and speaker in obj:
            speaker_role = "patient"
        elif passive:
            speaker_role = "patient"

        return CanonicalFrame(
            source=source,
            canonical=canonical,
            subject=subject,
            predicate=predicate,
            object=obj,
            attributives=mods,
            complement=complement,
            topic=topic,
            negated=negated or any(t.text in _NEGATIONS for t in doc),
            passive=passive,
            subject_inferred=subject_inferred,
            speaker_role=speaker_role,
        )