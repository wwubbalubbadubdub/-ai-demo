"""Continuous affect state with decay, inertia, and context-aware micro-jitter.

The idea is not to add noise to the text. It is to keep a small latent state
that changes smoothly over time:

    target  <- event input, then decays back to baseline
    current <- spring/damper follows target
    jitter  <- bounded, correlated noise, stronger during high arousal

This produces transitions such as:
    angry -> clenched/frowning/head-shaking -> idle
without hard cuts, while still allowing a new event to raise the target again.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import random


def _clamp(value: float, low: float = -1.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


@dataclass
class AffectState:
    valence: float = 0.0
    arousal: float = 0.0
    tension: float = 0.0
    attention: float = 0.0
    jitter: float = 0.0

    @property
    def motion_energy(self) -> float:
        return _clamp(0.65 * abs(self.arousal) + 0.35 * max(self.tension, 0.0), 0.0, 1.0)

    def to_dict(self) -> dict[str, float]:
        result = asdict(self)
        result["motion_energy"] = round(self.motion_energy, 4)
        return {key: round(value, 4) for key, value in result.items()}


class AffectDynamics:
    """Small deterministic-capable continuous controller, no model needed."""

    DIMENSIONS = ("valence", "arousal", "tension", "attention")

    def __init__(
        self,
        *,
        baseline: dict[str, float] | None = None,
        current: dict[str, float] | None = None,
        tau_target: float = 12.0,
        tau_current: float = 3.0,
        tau_noise: float = 1.5,
        noise_sigma: float = 0.025,
        seed: int | None = 7,
    ) -> None:
        self.baseline = {key: 0.0 for key in self.DIMENSIONS}
        if baseline:
            self.baseline.update({k: _clamp(float(v)) for k, v in baseline.items() if k in self.DIMENSIONS})
        self.target = dict(self.baseline)
        if current:
            self.target.update({k: _clamp(float(v)) for k, v in current.items() if k in self.DIMENSIONS})
        self.current = dict(self.target)
        self.tau_target = max(0.1, float(tau_target))
        self.tau_current = max(0.05, float(tau_current))
        self.tau_noise = max(0.05, float(tau_noise))
        self.noise_sigma = max(0.0, float(noise_sigma))
        self._rng = random.Random(seed)
        self._noise = 0.0
        self._state = AffectState(**self.current)

    def set_event(self, values: dict[str, float], *, hold: float = 0.0) -> None:
        """Raise/redirect the target. Hold is informational for the caller."""

        for key, value in values.items():
            if key in self.DIMENSIONS:
                self.target[key] = _clamp(float(value))
        for key in self.DIMENSIONS:
            if key in values:
                self.current[key] += (self.target[key] - self.current[key]) * 0.85
        self._state = AffectState(**self.current, jitter=self._noise)

    def step(self, dt: float) -> AffectState:
        dt = max(0.0, min(float(dt), 1.0))
        if dt == 0.0:
            return self._state

        target_alpha = 1.0 - math.exp(-dt / self.tau_target)
        current_alpha = 1.0 - math.exp(-dt / self.tau_current)
        noise_alpha = 1.0 - math.exp(-dt / self.tau_noise)

        for key in self.DIMENSIONS:
            self.target[key] += (self.baseline[key] - self.target[key]) * target_alpha
            self.current[key] += (self.target[key] - self.current[key]) * current_alpha

        self._noise += (0.0 - self._noise) * noise_alpha
        gain = self.noise_sigma * (0.35 + 0.65 * abs(self.current["arousal"]))
        self._noise += self._rng.gauss(0.0, gain * math.sqrt(dt))
        self._noise = _clamp(self._noise, -0.12, 0.12)

        values = {key: _clamp(self.current[key]) for key in self.DIMENSIONS}
        self.current.update(values)
        self._state = AffectState(**values, jitter=self._noise)
        return self._state