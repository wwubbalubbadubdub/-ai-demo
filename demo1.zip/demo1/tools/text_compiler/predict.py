"""Interactive CLI for the trained tiny demo model."""

from __future__ import annotations

import argparse
import sys

from .canonicalizer import ChineseCanonicalizer
from .model import FeatureEncoder, TinyBehaviorModel


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Tiny behavior model demo")
    parser.add_argument("text", nargs="*", help="input text; omit for an interactive prompt")
    parser.add_argument("--model", default="tools/text_compiler/artifacts/tiny_model.npz")
    args = parser.parse_args(argv)
    model, encoder, _ = TinyBehaviorModel.load(args.model)
    canonicalizer = ChineseCanonicalizer()
    texts = args.text or ["我被他狠狠骂了一顿。"]
    for text in texts:
        frame = canonicalizer.canonicalize(text)
        top = model.predict_top(text, encoder, k=8)
        print(f"输入: {text}")
        print(f"规范化: {frame.canonical}")
        print("行为:", "、".join(f"{item.label} {item.probability:.2f}" for item in top))
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())