"""Local text-to-motion language prototype."""

from .affect import AffectDynamics, AffectState
from .canonicalizer import CanonicalFrame, ChineseCanonicalizer, clean_text
from .heartbeat import BeatResult, HeartbeatCache
from .lexicon import CATEGORY_LABELS, DEFAULT_LEXICON, Lexicon, LexiconEntry
from .model import BEHAVIOR_LABELS, Prediction, TinyBehaviorModel, FeatureEncoder
from .noise_curriculum import (
    ANGER_LADDER,
    BehaviorTarget,
    SignalRatioWindow,
    build_degradation_example,
    build_mixture_example,
    distort_text,
    noise_count_for_ratio,
    ratio_schedule,
    target_for_ratio,
)
from .phrase import PhraseBuilder, PhraseValidator, SemanticPhrase
from .teacher import (
    TeacherFormatError,
    build_teacher_messages,
    parse_teacher_reply,
    teacher_system_prompt,
)

__all__ = [
    "ANGER_LADDER", "AffectDynamics", "AffectState", "BEHAVIOR_LABELS",
    "BeatResult", "BehaviorTarget", "CATEGORY_LABELS", "CanonicalFrame",
    "ChineseCanonicalizer", "DEFAULT_LEXICON", "FeatureEncoder", "HeartbeatCache",
    "Lexicon", "LexiconEntry", "PhraseBuilder", "PhraseValidator", "Prediction",
    "SemanticPhrase", "SignalRatioWindow", "TeacherFormatError",
    "TinyBehaviorModel", "build_mixture_example", "build_teacher_messages",
    "clean_text", "noise_count_for_ratio", "parse_teacher_reply",
    "ratio_schedule", "target_for_ratio", "teacher_system_prompt",
]