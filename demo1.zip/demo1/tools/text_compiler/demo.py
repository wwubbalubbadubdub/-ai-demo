"""Demo: canonicalization, noise-ratio ladder, and heartbeat cache."""

from __future__ import annotations

import json
from pathlib import Path

from .canonicalizer import ChineseCanonicalizer
from .heartbeat import HeartbeatCache
from .noise_curriculum import BehaviorTarget, build_mixture_example, ratio_schedule, target_for_ratio


def main() -> None:
    canonicalizer = ChineseCanonicalizer()
    examples = [
        "我骂了他。",
        "我被他狠狠骂了一顿。",
        "他把我骂了。",
        "这件事，我骂了他。",
        "我不是真的生他的气。",
    ]
    frames = [canonicalizer.canonicalize(text).to_dict() for text in examples]

    noise_pool = [
        "今天下午可能会下雨。",
        "这个文件已经保存了。",
        "显示器分辨率是 1920×1080。",
        "现在距离三点还有一会儿。",
        "桌面上有一支笔。",
    ]
    mixtures = [
        build_mixture_example("他骂我。", noise_pool, ratio)
        for ratio in ratio_schedule(5)
    ]

    calls: list[str] = []

    def compute(key: str, payload: object) -> dict:
        calls.append(key)
        target: BehaviorTarget = target_for_ratio(float(payload))
        return target.to_dict()

    heartbeat = HeartbeatCache(interval=4.0, ttl=30.0, compute=compute)
    beats = []
    for now, key, ratio in [
        (0.0, "event:anger:r1.0", 1.0),
        (1.0, "event:anger:r1.0", 1.0),
        (4.0, "event:anger:r1.0", 1.0),
        (8.0, "event:anger:r0.5", 0.5),
        (12.0, "event:neutral:r0.0", 0.0),
    ]:
        result = heartbeat.tick(now, key, ratio)
        beats.append({
            "t": now,
            "key": key,
            "due": result.due,
            "cache_hit": result.cache_hit,
            "computed": result.computed,
            "value": result.value,
        })

    output = {
        "canonical_frames": frames,
        "mixtures": mixtures,
        "heartbeats": beats,
        "model_calls": len(calls),
    }
    target = Path(".tmp_analysis/noise_heartbeat_demo.json")
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {target} ({len(frames)} frames, {len(mixtures)} mixtures, {len(calls)} model calls)")


if __name__ == "__main__":
    main()