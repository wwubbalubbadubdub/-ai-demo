"""Low-frequency cognition heartbeat with a bounded cache.

Rendering can stay at 30/60 FPS; the semantic model only runs when a heartbeat
is due and the context changed. If the same context is still fresh, the result
is reused. This is the cheap "wake and render emotion" loop.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class BeatResult:
    due: bool
    cache_hit: bool
    computed: bool
    value: Any


class HeartbeatCache:
    def __init__(
        self,
        *,
        interval: float = 4.0,
        ttl: float = 30.0,
        max_entries: int = 128,
        compute: Callable[[str, Any], Any] | None = None,
    ) -> None:
        self.interval = max(0.1, float(interval))
        self.ttl = max(0.0, float(ttl))
        self.max_entries = max(1, int(max_entries))
        self.compute = compute
        self._next_beat = 0.0
        self._cache: dict[str, tuple[float, Any]] = {}
        self.compute_count = 0
        self.hit_count = 0

    def tick(self, now: float, key: str, payload: Any = None) -> BeatResult:
        due = now >= self._next_beat
        if due:
            self._next_beat = now + self.interval

        cached = self._cache.get(key)
        if cached is not None:
            stored_at, value = cached
            if now - stored_at <= self.ttl:
                self.hit_count += 1
                return BeatResult(due=due, cache_hit=True, computed=False, value=value)

        if not due and cached is not None:
            # Not time to think yet, and no valid cache for this key.
            return BeatResult(due=False, cache_hit=False, computed=False, value=None)

        if self.compute is None:
            raise RuntimeError("HeartbeatCache requires a compute function")
        self.compute_count += 1
        value = self.compute(key, payload)
        self._cache[key] = (now, value)
        self._evict(now)
        return BeatResult(due=True, cache_hit=False, computed=True, value=value)

    def invalidate(self, key: str | None = None) -> None:
        if key is None:
            self._cache.clear()
        else:
            self._cache.pop(key, None)

    def _evict(self, now: float) -> None:
        expired = [key for key, (stamp, _) in self._cache.items() if now - stamp > self.ttl]
        for key in expired:
            self._cache.pop(key, None)
        while len(self._cache) > self.max_entries:
            oldest = min(self._cache, key=lambda key: self._cache[key][0])
            self._cache.pop(oldest, None)

    @property
    def size(self) -> int:
        return len(self._cache)