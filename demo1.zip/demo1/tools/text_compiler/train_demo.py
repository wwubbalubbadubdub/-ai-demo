"""Train the tiny behavior model on synthetic templates and write a demo."""

from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np

from .canonicalizer import ChineseCanonicalizer
from .model import BEHAVIOR_LABELS, LABEL_INDEX, FeatureEncoder, TinyBehaviorModel
from .phrase import PhraseBuilder

SCENARIOS: dict[str, dict[str, list[str]]] = {
    "骂": {"agent": ["生气", "皱眉", "瞪眼"], "patient": ["委屈", "难过", "低头", "移开视线"]},
    "夸": {"agent": ["开心", "温柔", "笑"], "patient": ["害羞", "开心", "脸红", "压笑"]},
    "安慰": {"agent": ["温柔", "靠近"], "patient": ["安心", "放松", "靠近"]},
    "拒绝": {"agent": ["冷漠", "平静"], "patient": ["失望", "尴尬", "后退"]},
    "忽视": {"agent": ["冷漠"], "patient": ["委屈", "寂寞", "低头"]},
    "质疑": {"agent": ["不服", "皱眉", "盯着"], "patient": ["紧张", "心虚", "移开视线"]},
    "道歉": {"agent": ["内疚", "低头"], "patient": ["平静"]},
    "感谢": {"agent": ["开心", "温柔", "点头"], "patient": ["开心", "笑"]},
    "喜欢": {"agent": ["心动", "温柔", "笑"], "patient": ["害羞", "脸红"]},
    "讨厌": {"agent": ["冷漠", "皱眉"], "patient": ["难过", "失望"]},
    "触碰": {"agent": ["惊讶", "害羞"], "patient": ["惊讶", "脸红", "缩肩"]},
    "抱": {"agent": ["安心", "温柔", "靠近"], "patient": ["安心", "害羞"]},
}

ADVERBS = ("", "狠狠地", "轻轻地", "突然", "小声地")
OBJECTS = ("他", "她")

EXTRA_SENTENCES: tuple[tuple[str, list[str]], ...] = (
    ("我今天有点难过。", ["难过", "低头"]),
    ("我有点开心。", ["开心", "笑"]),
    ("我真的很生气。", ["生气", "皱眉", "瞪眼"]),
    ("我有点害怕。", ["害怕", "缩肩"]),
    ("我觉得很累。", ["疲惫", "低头"]),
    ("这件事让我很尴尬。", ["尴尬", "移开视线"]),
    ("你别碰我尾巴。", ["炸毛", "缩肩"]),
    ("你能抱抱我吗？", ["安心", "害羞", "靠近"]),
    ("你凭什么觉得我笨？", ["委屈", "不服", "皱眉"]),
    ("我觉得他根本不在乎我。", ["难过", "失望", "低头"]),
    ("谢谢你安慰我。", ["开心", "温柔", "点头"]),
    ("我讨厌被这样看着。", ["冷漠", "移开视线"]),
    ("他刚才夸我可爱。", ["害羞", "开心", "脸红"]),
    ("我被忽视了。", ["委屈", "寂寞", "低头"]),
    ("我想靠近你一点。", ["心动", "靠近"]),
    ("别突然碰我。", ["惊讶", "缩肩"]),
    ("我不知道该怎么办。", ["无奈", "低头"]),
    ("我有一点期待。", ["期待", "笑"]),
    ("我现在很平静。", ["平静"]),
    ("今天有点烦躁。", ["烦躁", "皱眉"]),
)

NOISE = (
    "今天下午可能会下雨。",
    "这个文件已经保存了。",
    "显示器分辨率是 1920×1080。",
    "现在距离三点还有一会儿。",
    "桌上放着一支笔。",
)


def _add(bucket: dict[str, list[str]], text: str, labels: list[str]) -> None:
    text = text.strip()
    if not text:
        return
    valid = [label for label in labels if label in LABEL_INDEX]
    key = text
    if key in bucket:
        bucket[key] = sorted(set(bucket[key]) | set(valid), key=BEHAVIOR_LABELS.index)
    else:
        bucket[key] = valid


def build_synthetic() -> dict[str, list[str]]:
    rng = random.Random(42)
    bucket: dict[str, list[str]] = {}
    for verb, spec in SCENARIOS.items():
        for adv in ADVERBS:
            for obj in OBJECTS:
                _add(bucket, f"我{adv}{verb}了{obj}。", spec["agent"])
                _add(bucket, f"{obj}把我{adv}{verb}了。", spec["patient"])
                _add(bucket, f"我被他{adv}{verb}了。", spec["patient"])
                _add(bucket, f"这件事，我{adv}{verb}{obj}。", spec["agent"])
                _add(bucket, f"我没有{adv}{verb}{obj}。", spec["agent"])
                _add(bucket, f"{obj}{adv}{verb}我。", spec["patient"])
    # Noise-only examples teach the model to fall back to a quiet state.
    for sentence, labels in EXTRA_SENTENCES:
        _add(bucket, sentence, labels)
    for sentence in NOISE:
        _add(bucket, sentence, ["平静"])
    # Mix neutral context with useful context, preserving the useful target.
    base_items = list(bucket.items())
    for text, labels in base_items[:]:
        if labels != ["平静"]:
            _add(bucket, f"{text}{rng.choice(NOISE)}", labels)
            _add(bucket, f"{rng.choice(NOISE)}{text}", labels)
    return bucket


def build_arrays(bucket: dict[str, list[str]], encoder: FeatureEncoder) -> tuple[np.ndarray, np.ndarray, list[str]]:
    texts = list(bucket)
    X = encoder.encode_many(texts)
    Y = np.zeros((len(texts), len(BEHAVIOR_LABELS)), dtype=np.float32)
    for row, text in enumerate(texts):
        for label in bucket[text]:
            Y[row, LABEL_INDEX[label]] = 1.0
    return X, Y, texts


def main() -> None:
    outdir = Path("tools/text_compiler/artifacts")
    outdir.mkdir(parents=True, exist_ok=True)
    encoder = FeatureEncoder(hash_dim=2048)
    bucket = build_synthetic()
    X, Y, texts = build_arrays(bucket, encoder)
    rng = np.random.default_rng(42)
    order = rng.permutation(len(texts))
    split = int(len(texts) * 0.85)
    train_idx, val_idx = order[:split], order[split:]
    model = TinyBehaviorModel(encoder.dim, hidden=64, seed=42)
    print(f"examples={len(texts)} features={encoder.dim} labels={len(BEHAVIOR_LABELS)}")
    losses = model.train(
        X[train_idx], Y[train_idx],
        epochs=140,
        batch_size=64,
        learning_rate=0.08,
        seed=42,
        verbose=True,
    )
    val_probs = model.forward(X[val_idx])
    val_loss = -np.mean(
        Y[val_idx] * np.log(val_probs + 1e-7)
        + (1.0 - Y[val_idx]) * np.log(1.0 - val_probs + 1e-7)
    )
    model.save(
        outdir / "tiny_model.npz",
        encoder,
        {"trained_on": "synthetic templates", "examples": len(texts), "val_loss": float(val_loss)},
    )
    print(f"final_train_loss={losses[-1]:.4f} val_loss={val_loss:.4f}")

    canonicalizer = ChineseCanonicalizer()
    phrase_builder = PhraseBuilder()
    examples = [
        "我骂了他。",
        "我被他狠狠骂了一顿。",
        "她夸我可爱。",
        "你能抱抱我吗？",
        "我今天有点难过。",
        "你凭什么觉得我笨？",
        "今天下午可能下雨。",
    ]
    rows = []
    for text in examples:
        frame = canonicalizer.canonicalize(text)
        try:
            rule_phrase = phrase_builder.build(frame).to_text()
        except ValueError as exc:
            rule_phrase = f"（规则短语未生成：{exc}）"
        predictions = model.predict_top(text, encoder, k=6)
        rows.append({
            "input": text,
            "canonical": frame.canonical,
            "rule_phrase": rule_phrase,
            "top": [{"label": p.label, "probability": round(p.probability, 3)} for p in predictions],
        })

    report = [
        "# Tiny behavior model demo",
        "",
        "> Trained on synthetic Chinese templates, not on the user's video yet.",
        f"> Examples: {len(texts)}; input features: {encoder.dim}; model: 1 hidden layer, {model.hidden} units.",
        "",
        "| 输入 | 规范化 | 规则短语 | 模型 Top 6 |",
        "| --- | --- | --- | --- |",
    ]
    for row in rows:
        top = "、".join(f"{item['label']} {item['probability']:.2f}" for item in row["top"])
        display_phrase = row["rule_phrase"] if not row["rule_phrase"].startswith("（规则") else "—"
        report.append(f"| {row['input']} | {row['canonical']} | {display_phrase} | {top} |")
    report.append("")
    report.append("This is a pipeline demo, not a quality model. Real labels are needed for useful predictions.")
    (outdir / "demo.md").write_text("\n".join(report), encoding="utf-8")
    (outdir / "demo.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {outdir / 'tiny_model.npz'}")
    print(f"wrote {outdir / 'demo.md'}")


if __name__ == "__main__":
    main()