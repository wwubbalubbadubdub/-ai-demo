from __future__ import annotations

import unittest

from tools.text_compiler import AffectDynamics, ChineseCanonicalizer


class CanonicalizerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.c = ChineseCanonicalizer()

    def frame(self, text: str, speaker: str = "我"):
        return self.c.canonicalize(text, speaker=speaker)

    def test_active_svo(self) -> None:
        f = self.frame("我骂了他。")
        self.assertEqual((f.subject, f.predicate, f.object), ("我", "骂", "他"))
        self.assertEqual(f.canonical, "我骂他")
        self.assertEqual(f.speaker_role, "agent")
        self.assertFalse(f.passive)

    def test_passive_is_reordered(self) -> None:
        f = self.frame("我被他狠狠骂了一顿。")
        self.assertEqual((f.subject, f.predicate, f.object), ("他", "骂", "我"))
        self.assertEqual(f.canonical, "他狠狠骂我")
        self.assertEqual(f.speaker_role, "patient")
        self.assertTrue(f.passive)
        self.assertIn("狠狠", f.attributives)

    def test_ba_construction(self) -> None:
        f = self.frame("他把我骂了。")
        self.assertEqual((f.subject, f.predicate, f.object), ("他", "骂", "我"))
        self.assertEqual(f.canonical, "他骂我")
        self.assertEqual(f.speaker_role, "patient")

    def test_omitted_subject_uses_speaker(self) -> None:
        f = self.frame("骂了他一顿。", speaker="我")
        self.assertEqual(f.canonical, "我骂他")
        self.assertTrue(f.subject_inferred)
        self.assertEqual(f.speaker_role, "agent")

    def test_topic_is_extracted_but_not_in_canonical(self) -> None:
        f = self.frame("这件事，我骂了他。")
        self.assertEqual(f.topic, "这件事")
        self.assertEqual(f.canonical, "我骂他")

    def test_negation_and_possessive_object(self) -> None:
        f = self.frame("我不是真的生他的气。")
        self.assertTrue(f.negated)
        self.assertIn("不是", f.attributives)
        self.assertIn("真的", f.attributives)
        self.assertEqual(f.object, "他的气")
        self.assertEqual(f.canonical, "我不是真的生他的气")

    def test_complement_kept(self) -> None:
        f1 = self.frame("我夸她可爱。")
        f2 = self.frame("她夸我可爱。")
        self.assertEqual(f1.canonical, "我夸她可爱")
        self.assertEqual(f2.canonical, "她夸我可爱")
        self.assertEqual(f1.speaker_role, "agent")
        self.assertEqual(f2.speaker_role, "patient")

    def test_complex_predicate_keeps_embedded_subject(self) -> None:
        f = self.frame("我觉得他根本不在乎我。")
        self.assertEqual(f.canonical, "我觉得他根本不在乎我")
        self.assertEqual(f.subject, "我")
        self.assertEqual(f.predicate, "觉得")
        self.assertIn("他根本不在乎我", f.complement or "")

    def test_active_and_passive_are_distinguishable(self) -> None:
        active = self.frame("我骂了他。")
        passive = self.frame("我被他骂了。")
        self.assertNotEqual(active.canonical, passive.canonical)
        self.assertEqual(active.speaker_role, "agent")
        self.assertEqual(passive.speaker_role, "patient")

    def test_agentless_passive(self) -> None:
        f = self.frame("他被骂了。")
        self.assertTrue(f.passive)
        self.assertIsNone(f.subject)
        self.assertEqual(f.object, "他")
        self.assertEqual(f.canonical, "他被骂")
        self.assertEqual(f.speaker_role, "patient")


class AffectDynamicsTests(unittest.TestCase):
    def test_anger_decays_without_hard_cut(self) -> None:
        sim = AffectDynamics(seed=3)
        sim.set_event({"valence": -0.9, "arousal": 1.0, "tension": 1.0})
        start = sim.step(0.0).motion_energy
        states = [sim.step(0.1) for _ in range(100)]
        middle = states[-1].motion_energy
        for _ in range(600):
            final_state = sim.step(0.1)
        self.assertGreater(start, 0.5)
        self.assertLess(middle, start)
        self.assertLess(final_state.motion_energy, middle)
        self.assertGreaterEqual(final_state.motion_energy, 0.0)
        self.assertLessEqual(final_state.motion_energy, 1.0)

    def test_state_is_bounded(self) -> None:
        sim = AffectDynamics(seed=4, noise_sigma=0.2)
        sim.set_event({"valence": -2.0, "arousal": 2.0, "tension": 2.0})
        for _ in range(500):
            state = sim.step(0.05)
            self.assertGreaterEqual(state.valence, -1.0)
            self.assertLessEqual(state.valence, 1.0)
            self.assertGreaterEqual(state.arousal, -1.0)
            self.assertLessEqual(state.arousal, 1.0)
            self.assertLessEqual(abs(state.jitter), 0.1201)

    def test_same_seed_is_deterministic(self) -> None:
        a = AffectDynamics(seed=11)
        b = AffectDynamics(seed=11)
        a.set_event({"arousal": 0.8})
        b.set_event({"arousal": 0.8})
        for _ in range(50):
            sa = a.step(0.1)
            sb = b.step(0.1)
        self.assertEqual(sa.to_dict(), sb.to_dict())

    def test_context_switch_lowers_energy(self) -> None:
        sim = AffectDynamics(seed=5)
        sim.set_event({"arousal": 1.0, "tension": 0.9})
        for _ in range(30):
            sim.step(0.1)
        high = sim.step(0.0).motion_energy
        sim.set_event({"arousal": 0.1, "tension": 0.1, "valence": 0.4})
        for _ in range(100):
            sim.step(0.1)
        low = sim.step(0.0).motion_energy
        self.assertLess(low, high)


if __name__ == "__main__":
    unittest.main()