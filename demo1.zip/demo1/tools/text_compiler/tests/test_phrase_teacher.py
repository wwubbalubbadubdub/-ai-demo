from __future__ import annotations

import json
import unittest

from tools.text_compiler import (
    DEFAULT_LEXICON,
    ChineseCanonicalizer,
    PhraseBuilder,
    PhraseValidator,
    SemanticPhrase,
    TeacherFormatError,
    build_teacher_messages,
    parse_teacher_reply,
)


class LexiconTests(unittest.TestCase):
    def test_seed_has_enough_tokens_and_no_duplicates(self) -> None:
        self.assertGreaterEqual(len(DEFAULT_LEXICON), 180)
        texts = [entry.text for entry in DEFAULT_LEXICON.entries]
        self.assertEqual(len(texts), len(set(texts)))

    def test_categories_are_covered(self) -> None:
        report = DEFAULT_LEXICON.coverage_report()
        self.assertGreaterEqual(report["role"], 8)
        self.assertGreaterEqual(report["action"], 25)
        self.assertGreaterEqual(report["affect"], 20)
        self.assertGreaterEqual(report["motion"], 20)


class PhraseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.canonicalizer = ChineseCanonicalizer()
        cls.builder = PhraseBuilder()

    def build(self, text: str) -> SemanticPhrase:
        return self.builder.build(self.canonicalizer.canonicalize(text))

    def test_active_and_passive_keep_different_roles(self) -> None:
        active = self.build("我骂了他。")
        passive = self.build("我被他狠狠骂了一顿。")
        self.assertEqual((active.scene_subject, active.scene_object), ("我", "他"))
        self.assertEqual((passive.scene_subject, passive.scene_object), ("他", "我"))
        self.assertNotEqual(active.to_text(), passive.to_text())
        self.assertIn("生气", active.affect)
        self.assertIn("委屈", passive.affect)

    def test_phrase_is_not_a_command(self) -> None:
        phrase = self.build("我夸她可爱。")
        self.assertFalse(phrase.to_text().startswith(("请", "让", "给我")))
        self.assertEqual(PhraseValidator().errors(phrase), [])

    def test_unknown_token_is_rejected(self) -> None:
        phrase = SemanticPhrase(
            scene_subject="我",
            scene_predicate="微笑",
            affect=["开心"],
            body=["笑"],
        )
        self.assertTrue(PhraseValidator().errors(phrase))

    def test_command_marker_is_rejected(self) -> None:
        phrase = SemanticPhrase(
            scene_subject="我",
            scene_predicate="骂",
            affect=["生气"],
            body=["皱眉"],
            modality=["请"],
        )
        self.assertTrue(any("命令" in error or "词库外" in error for error in PhraseValidator().errors(phrase)))


class TeacherTests(unittest.TestCase):
    def test_prompt_contains_closed_vocabulary_and_no_command_rule(self) -> None:
        frame = ChineseCanonicalizer().canonicalize("我被他骂了。")
        messages = build_teacher_messages("我被他骂了。", frame)
        self.assertEqual(messages[0]["role"], "system")
        self.assertIn("可用词库", messages[0]["content"])
        self.assertIn("不要只输出", messages[0]["content"])
        self.assertIn("主语", messages[1]["content"])

    def test_parse_valid_teacher_json(self) -> None:
        reply = json.dumps({
            "scene": {"subject": "他", "predicate": "骂", "object": "我"},
            "affect": ["委屈"],
            "manner": ["狠狠"],
            "body": ["低头"],
            "intensity": None,
            "modality": [],
            "descriptor": [],
            "confidence": 0.8,
        }, ensure_ascii=False)
        phrase = parse_teacher_reply(reply)
        self.assertEqual(phrase.scene_subject, "他")
        self.assertEqual(phrase.scene_object, "我")
        self.assertIn("委屈", phrase.affect)

    def test_parse_rejects_unknown_token(self) -> None:
        reply = json.dumps({
            "scene": {"subject": "他", "predicate": "骂", "object": "我"},
            "affect": ["不可名状"],
            "body": ["低头"],
            "confidence": 0.2,
        }, ensure_ascii=False)
        with self.assertRaises(TeacherFormatError):
            parse_teacher_reply(reply)


if __name__ == "__main__":
    unittest.main()