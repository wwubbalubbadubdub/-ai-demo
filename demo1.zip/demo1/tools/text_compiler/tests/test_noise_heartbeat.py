from __future__ import annotations

import random
import unittest

from tools.text_compiler import (
    ANGER_LADDER,
    HeartbeatCache,
    SignalRatioWindow,
    build_degradation_example,
    distort_text,
    build_mixture_example,
    noise_count_for_ratio,
    ratio_schedule,
    target_for_ratio,
)


NOISE = [
    "今天下午可能会下雨。",
    "这个项目的依赖安装在本地虚拟环境里。",
    "显示器分辨率为 1920×1080。",
    "他在整理桌面上的文件。",
    "现在距离下午三点还有一段时间。",
]


class NoiseCurriculumTests(unittest.TestCase):
    def test_ladder_changes_the_behavior_not_only_amplitude(self) -> None:
        full = target_for_ratio(1.0)
        mid = target_for_ratio(0.5)
        low = target_for_ratio(0.25)
        idle = target_for_ratio(0.0)
        self.assertIn("head_snap", full.tokens)
        self.assertNotIn("head_snap", low.tokens)
        self.assertGreater(mid.tokens["idle"], full.tokens["idle"])
        self.assertGreater(low.tokens["idle"], mid.tokens["idle"])
        self.assertEqual(idle.tokens, {"idle": 1.0})
        self.assertNotEqual(full.tokens, {key: value * 0.25 for key, value in full.tokens.items()})

    def test_noise_count_decreases_with_signal_ratio(self) -> None:
        self.assertEqual(noise_count_for_ratio(1.0), 0)
        self.assertEqual(noise_count_for_ratio(0.5), 1)
        self.assertEqual(noise_count_for_ratio(0.25), 3)
        self.assertEqual(noise_count_for_ratio(0.0), 8)

    def test_mixture_includes_useful_and_noise_and_is_shuffled(self) -> None:
        example = build_mixture_example("他骂我。", NOISE, 0.5, rng=random.Random(2))
        self.assertEqual(example["ratio"], 0.5)
        self.assertEqual(example["noise_count"], 1)
        self.assertIn("他骂我。", example["context"])
        self.assertEqual(len(example["context"]), 2)
        self.assertEqual(example["target"]["label"], "anger_mid")

    def test_zero_useful_ratio_has_only_noise(self) -> None:
        example = build_mixture_example("他骂我。", NOISE, 0.0, rng=random.Random(2))
        self.assertNotIn("他骂我。", example["context"])
        self.assertEqual(example["target"]["label"], "neutral_idle")

    def test_ratio_schedule_ends_at_zero(self) -> None:
        schedule = ratio_schedule(5)
        self.assertEqual(schedule, [1.0, 0.75, 0.5, 0.25, 0.0])
        self.assertEqual(len(ANGER_LADDER), 5)


class HeartbeatTests(unittest.TestCase):
    def test_cache_hit_avoids_model_call(self) -> None:
        calls: list[str] = []
        def compute(key: str, payload: object) -> str:
            calls.append(key)
            return f"behavior:{key}"

        beat = HeartbeatCache(interval=4.0, ttl=30.0, compute=compute)
        first = beat.tick(0.0, "a")
        self.assertTrue(first.computed)
        self.assertEqual(first.value, "behavior:a")
        second = beat.tick(0.5, "a")
        self.assertTrue(second.cache_hit)
        self.assertFalse(second.computed)
        self.assertEqual(len(calls), 1)

    def test_due_beat_reuses_fresh_cache(self) -> None:
        calls: list[str] = []
        beat = HeartbeatCache(interval=4.0, ttl=30.0, compute=lambda key, _: calls.append(key) or key)
        beat.tick(0.0, "a")
        beat.tick(4.0, "a")
        self.assertEqual(len(calls), 1)
        beat.tick(8.0, "a")
        self.assertEqual(len(calls), 1)

    def test_expired_cache_recomputes(self) -> None:
        calls: list[str] = []
        beat = HeartbeatCache(interval=1.0, ttl=2.0, compute=lambda key, _: calls.append(key) or key)
        beat.tick(0.0, "a")
        beat.tick(1.0, "a")
        beat.tick(2.1, "a")
        self.assertEqual(len(calls), 2)

    def test_new_key_wakes_immediately_for_responsiveness(self) -> None:
        calls: list[str] = []
        beat = HeartbeatCache(interval=4.0, ttl=30.0, compute=lambda key, _: calls.append(key) or key)
        beat.tick(0.0, "a")
        result = beat.tick(1.0, "b")
        self.assertTrue(result.computed)
        self.assertEqual(result.value, "b")
        self.assertEqual(calls, ["a", "b"])

    def test_cache_is_bounded(self) -> None:
        beat = HeartbeatCache(interval=0.1, ttl=100.0, max_entries=3, compute=lambda key, _: key)
        for index in range(5):
            beat.tick(float(index), f"k{index}")
        self.assertLessEqual(beat.size, 3)


if __name__ == "__main__":
    unittest.main()

class SignalRatioWindowTests(unittest.TestCase):
    def test_useful_ratio_decreases_and_changes_ladder(self) -> None:
        window = SignalRatioWindow()
        start = window.add_useful(0.0)
        self.assertGreater(start, 0.8)
        self.assertEqual(window.target().label, "anger_full")
        after_30 = window.advance(30.0)
        self.assertLess(after_30, start)
        self.assertEqual(window.target().label, "anger_mid")
        after_90 = window.advance(90.0)
        self.assertLess(after_90, after_30)
        self.assertIn(window.target().label, {"anger_residual", "neutral_idle"})

    def test_noise_accumulation_reduces_ratio(self) -> None:
        window = SignalRatioWindow(initial_noise=0.0)
        start = window.add_useful(0.0)
        before = window.add_noise(0.0, 1.0)
        self.assertLess(before, start)
        self.assertGreaterEqual(window.ratio, 0.0)


class DegradationTests(unittest.TestCase):
    def test_zero_level_keeps_clean_sentence(self) -> None:
        text = "你干嘛老盯着我"
        self.assertEqual(distort_text(text, 0.0), text)

    def test_higher_level_degrades_same_sentence(self) -> None:
        text = "你干嘛老盯着我"
        low = distort_text(text, 0.25)
        high = distort_text(text, 0.9)
        self.assertNotEqual(low, text)
        self.assertNotEqual(high, text)
        self.assertLessEqual(len(high), len(text) + 20)

    def test_degradation_chain_has_ratio_and_context(self) -> None:
        row = build_degradation_example("你干嘛老盯着我", 0.75, steps=4)
        self.assertEqual(len(row["context"]), 4)
        self.assertAlmostEqual(row["ratio"], 0.25)
        self.assertIn("target", row)
        self.assertEqual(row["target"]["label"], "anger_residual")