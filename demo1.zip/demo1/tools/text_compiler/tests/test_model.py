from __future__ import annotations

import unittest

import numpy as np

from tools.text_compiler import (
    BEHAVIOR_LABELS,
    ChineseCanonicalizer,
    FeatureEncoder,
    TinyBehaviorModel,
)


class ModelTests(unittest.TestCase):
    def test_feature_encoder_is_deterministic(self) -> None:
        encoder = FeatureEncoder(hash_dim=128)
        a = encoder.encode("我被他骂了")
        b = encoder.encode("我被他骂了")
        self.assertEqual(a.shape, (encoder.dim,))
        np.testing.assert_allclose(a, b)
        self.assertGreater(float(np.linalg.norm(a)), 0.0)

    def test_tiny_model_can_learn_a_toy_batch(self) -> None:
        model = TinyBehaviorModel(16, labels=("生气", "害羞"), hidden=8, seed=2)
        X = np.eye(16, dtype=np.float32)
        Y = np.zeros((16, 2), dtype=np.float32)
        Y[:8, 0] = 1
        Y[8:, 1] = 1
        before = model.forward(X[:1])[0].copy()
        losses = model.train(X, Y, epochs=30, batch_size=8, learning_rate=0.2, seed=2)
        self.assertLess(losses[-1], losses[0])
        self.assertEqual(model.forward(X[:1]).shape, (1, 2))
        self.assertFalse(np.array_equal(before, model.forward(X[:1])[0]))

    def test_saved_demo_model_loads_and_predicts(self) -> None:
        model, encoder, meta = TinyBehaviorModel.load("tools/text_compiler/artifacts/tiny_model.npz")
        self.assertEqual(len(model.labels), len(BEHAVIOR_LABELS))
        self.assertEqual(meta.get("trained_on"), "synthetic templates")
        top = model.predict_top("我骂了他。", encoder, k=6)
        self.assertTrue(any(item.label == "生气" for item in top))


class CanonicalizerExtraTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.c = ChineseCanonicalizer()

    def test_question_picks_content_verb(self) -> None:
        frame = self.c.canonicalize("你能抱抱我吗？")
        self.assertEqual(frame.canonical, "你抱抱我")
        self.assertEqual((frame.subject, frame.predicate, frame.object), ("你", "抱抱", "我"))

    def test_weather_does_not_infer_speaker(self) -> None:
        frame = self.c.canonicalize("今天下午可能下雨。")
        self.assertEqual(frame.canonical, "下雨")
        self.assertIsNone(frame.subject)
        self.assertFalse(frame.subject_inferred)


if __name__ == "__main__":
    unittest.main()