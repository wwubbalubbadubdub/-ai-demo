"""Parse, validate, and deduplicate the compact semantic-tone corpus."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "语料1.txt"
OUTPUT = ROOT / "data" / "private" / "semantic_tone_corpus.txt"
REPORT = ROOT / "docs" / "语料1_处理报告.md"

SLOT_COUNT = 3
HEADS = {
    "省主", "省宾", "倒装", "被", "否", "略", "无动作",
    "问", "怨", "讽", "玩", "请", "述", "拒", "诺",
}
PREFIXES = ("题:", "方:", "场:", "时:", "语:", "标:", "称:", "重:", "错:", "填:")


def parse_line(raw: str) -> tuple[str, list[str]] | None:
    line = raw.strip()
    line = re.sub(r"^\d+\s*[:：]\s*", "", line)
    if not line:
        return None
    if "|||" not in line:
        raise ValueError(f"缺少 |||: {raw!r}")
    text, tag_text = (part.strip() for part in line.split("|||", 1))
    if not text or not tag_text:
        raise ValueError(f"空字段: {raw!r}")
    tags = [tag.strip() for tag in re.split(r"[，,]", tag_text) if tag.strip()]
    if len(tags) < SLOT_COUNT:
        raise ValueError(f"少于三个语义槽: {raw!r}")
    return text, tags


def main() -> None:
    raw_lines = SOURCE.read_text(encoding="utf-8-sig").splitlines()
    parsed = []
    errors = []
    for index, raw in enumerate(raw_lines, start=1):
        try:
            item = parse_line(raw)
            if item:
                parsed.append((index, *item))
        except ValueError as exc:
            errors.append(f"第 {index} 行: {exc}")

    seen = {}
    duplicates = []
    for index, text, tags in parsed:
        key = (text, tuple(tags))
        if key in seen:
            duplicates.append((seen[key], index, text))
        else:
            seen[key] = index
            parsed[parsed.index((index, text, tags))] = (index, text, tags)

    # Deduplicate by exact text+tags, preserving first occurrence.
    unique = []
    seen_text = set()
    for index, text, tags in parsed:
        key = (text, tuple(tags))
        if key in seen_text:
            continue
        seen_text.add(key)
        unique.append((index, text, tags))

    tag_counts = Counter()
    for _, _, tags in unique:
        for tag in tags[SLOT_COUNT:]:
            head = next((p[:-1] for p in PREFIXES if tag.startswith(p)), tag)
            tag_counts[head] += 1

    issues = []
    for index, text, tags in unique:
        slots = tags[:SLOT_COUNT]
        extra = tags[SLOT_COUNT:]
        if "省主" in extra and slots[0] not in {"∅"} and not slots[0].startswith("("):
            issues.append((index, "省主 但首槽不是 ∅ 或 (推断)"))
        if "倒装" in extra and not any(tag.startswith("题:") for tag in extra):
            issues.append((index, "倒装 但没有 题:"))
        if "无动作" in extra and any(slot != "∅" for slot in slots[:2]):
            issues.append((index, "无动作 但施事/受事非空"))
        for tag in extra:
            for prefix in PREFIXES:
                if tag.startswith(prefix):
                    value = tag[len(prefix):]
                    if value and value not in text:
                        issues.append((index, f"标签 {tag} 的值不在原文中"))
        for tag in extra:
            if tag in HEADS:
                continue
            if not any(tag.startswith(prefix) for prefix in PREFIXES):
                issues.append((index, f"未知标签 {tag}"))

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        "\n".join(f"{text} ||| {'，'.join(tags)}" for _, text, tags in unique) + "\n",
        encoding="utf-8",
    )

    report = [
        "# 语料1 处理报告",
        "",
        f"- 原始行数: {len(raw_lines)}",
        f"- 可解析行数: {len(parsed)}",
        f"- 去重后: {len(unique)}",
        f"- 重复行: {len(duplicates)}",
        f"- 解析错误: {len(errors)}",
        f"- 结构问题: {len(issues)}",
        "",
        "## 重复",
    ]
    report.extend(f"- 第 {a} 行与第 {b} 行: {text}" for a, b, text in duplicates) if duplicates else report.append("- 无")
    report.extend(["", "## 解析错误"])
    report.extend(f"- {error}" for error in errors) if errors else report.append("- 无")
    report.extend(["", "## 结构问题"])
    report.extend(f"- 第 {index} 行: {message}" for index, message in issues) if issues else report.append("- 无")
    report.extend(["", "## 标签分布", ""])
    report.extend(f"- {name}: {count}" for name, count in tag_counts.most_common())
    report.extend([
        "",
        "## 初步判断",
        "",
        "这批语料以技术/文件/接口场景为主，`述` 占比很高；",
        "`怨`、`讽`、`玩`、`称`、`重`、`方`、`场` 基本没有出现。",
        "可以用于验证格式和角色关系，但不足以训练语气模型。",
        "建议下一批增加口语、抱怨、玩笑、反问、称呼、重复、倒装和错字样本。",
    ])
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text("\n".join(report) + "\n", encoding="utf-8")
    print(f"clean={OUTPUT} lines={len(unique)} duplicates={len(duplicates)} issues={len(issues)} errors={len(errors)}")
    print(f"report={REPORT}")


if __name__ == "__main__":
    main()