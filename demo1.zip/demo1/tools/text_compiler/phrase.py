"""Controlled semantic phrase and local frame-to-phrase builder.

The phrase is descriptive, not imperative. It keeps the subject/predicate/object
from the canonical frame, then adds affect, manner, body cues, intensity, and
modality from the controlled lexicon.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

from .canonicalizer import CanonicalFrame
from .lexicon import DEFAULT_LEXICON, Lexicon


ACTION_HINTS: dict[str, tuple[list[str], list[str]]] = {
    "骂": (["生气"], ["皱眉", "瞪眼"]),
    "夸": (["开心", "温柔"], ["笑"]),
    "安慰": (["安心", "温柔"], ["靠近", "拍肩"]),
    "拒绝": (["失望", "尴尬"], ["后退", "移开视线"]),
    "忽视": (["委屈", "寂寞"], ["低头", "移开视线"]),
    "质疑": (["不服", "紧张"], ["皱眉", "移开视线"]),
    "道歉": (["内疚", "服软"], ["低头"]),
    "感谢": (["开心", "温柔"], ["笑", "点头"]),
    "嘲笑": (["尴尬", "难过"], ["低头", "缩肩"]),
    "关心": (["温柔", "紧张"], ["靠近"]),
    "触碰": (["惊讶", "害羞"], ["脸红", "缩肩"]),
    "抱": (["安心", "心动"], ["靠近"]),
    "喜欢": (["心动", "害羞"], ["脸红", "压笑"]),
    "讨厌": (["冷漠", "烦躁"], ["移开视线"]),
    "命令": (["紧张", "不服"], ["僵住"]),
    "被夸": (["害羞", "开心"], ["脸红", "压笑"]),
    "被骂": (["委屈", "难过"], ["低头", "移开视线"]),
    "被忽视": (["委屈", "寂寞"], ["低头", "停住"]),
    "被拒绝": (["失望", "尴尬"], ["后退", "移开视线"]),
    "被安慰": (["安心", "温柔"], ["靠近", "呼吸"]),
    "被触碰": (["惊讶", "害羞"], ["缩肩", "脸红"]),
    "被看着": (["紧张", "害羞"], ["移开视线", "僵住"]),
    "被误解": (["委屈", "无奈"], ["低头", "叹气"]),
    "被需要": (["开心", "心动"], ["抬头", "笑"]),
    "被喜欢": (["害羞", "开心"], ["脸红", "压笑"]),
    "被讨厌": (["难过", "失望"], ["低头", "停住"]),
    "被质疑": (["不服", "紧张"], ["皱眉", "移开视线"]),
    "被保护": (["安心", "心动"], ["靠近"]),
    "被抛下": (["寂寞", "害怕"], ["低头", "缩肩"]),
}


@dataclass
class SemanticPhrase:
    scene_subject: str | None = None
    scene_predicate: str | None = None
    scene_object: str | None = None
    affect: list[str] = field(default_factory=list)
    manner: list[str] = field(default_factory=list)
    body: list[str] = field(default_factory=list)
    intensity: str | None = None
    modality: list[str] = field(default_factory=list)
    descriptor: list[str] = field(default_factory=list)
    confidence: float = 0.0

    def tokens(self) -> list[str]:
        result: list[str] = []
        for value in (
            self.scene_subject,
            self.scene_predicate,
            self.scene_object,
        ):
            if value:
                result.append(value)
        result.extend(self.affect)
        result.extend(self.manner)
        result.extend(self.body)
        result.extend(self.descriptor)
        result.extend(self.modality)
        if self.intensity:
            result.append(self.intensity)
        return result

    def to_text(self, sep: str = "/") -> str:
        return sep.join(self.tokens())

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SemanticPhrase":
        scene = data.get("scene") or {}
        values = {
            "scene_subject": scene.get("subject") if isinstance(scene, dict) else None,
            "scene_predicate": scene.get("predicate") if isinstance(scene, dict) else None,
            "scene_object": scene.get("object") if isinstance(scene, dict) else None,
            "affect": list(data.get("affect") or []),
            "manner": list(data.get("manner") or []),
            "body": list(data.get("body") or []),
            "intensity": data.get("intensity"),
            "modality": list(data.get("modality") or []),
            "descriptor": list(data.get("descriptor") or []),
            "confidence": float(data.get("confidence", 0.0)),
        }
        return cls(**values)


class PhraseValidator:
    """Enforces closed vocabulary and descriptive (non-command) phrases."""

    REQUIRED = {
        "scene_subject": "role",
        "scene_predicate": "action",
        "scene_object": "role",
    }

    def __init__(self, lexicon: Lexicon = DEFAULT_LEXICON) -> None:
        self.lexicon = lexicon

    def errors(self, phrase: SemanticPhrase) -> list[str]:
        errors: list[str] = []
        if not phrase.scene_predicate:
            errors.append("缺少谓语/事件")
        for attr, category in self.REQUIRED.items():
            value = getattr(phrase, attr)
            if value is None:
                continue
            entry = self.lexicon.get(value)
            if entry is None:
                errors.append(f"词库外场景词: {value}")
            elif entry.category != category:
                errors.append(f"场景词类别错误: {value} ({entry.category} != {category})")
        for attr, category in (
            ("affect", "affect"),
            ("manner", "manner"),
            ("body", "motion"),
            ("modality", "modality"),
            ("descriptor", "descriptor"),
        ):
            for value in getattr(phrase, attr):
                entry = self.lexicon.get(value)
                if entry is None:
                    errors.append(f"词库外词: {value}")
                elif entry.category != category:
                    errors.append(f"类别错误: {value} ({entry.category} != {category})")
        if phrase.intensity and phrase.intensity not in self.lexicon:
            errors.append(f"词库外强度词: {phrase.intensity}")
        if not phrase.affect and not phrase.body:
            errors.append("至少需要一个情绪或身体动作")
        if any(token.startswith(("请", "让", "给我", "你必须")) for token in phrase.tokens()):
            errors.append("不接受命令式短语")
        return errors

    def validate(self, phrase: SemanticPhrase) -> SemanticPhrase:
        errors = self.errors(phrase)
        if errors:
            raise ValueError("；".join(errors))
        return phrase


class PhraseBuilder:
    def __init__(self, lexicon: Lexicon = DEFAULT_LEXICON) -> None:
        self.lexicon = lexicon
        self.validator = PhraseValidator(lexicon)

    def build(self, frame: CanonicalFrame, *, confidence: float = 0.35) -> SemanticPhrase:
        predicate = frame.predicate or ""

        if predicate not in self.lexicon or self.lexicon.category(predicate) != "action":
            raise ValueError(f"谓语不在动作词库中: {predicate}")

        affect, body = ACTION_HINTS.get(predicate, (["平静"], ["呼吸"]))
        if predicate in {"骂", "质疑"} and frame.speaker_role == "patient":
            affect, body = ["委屈", "难过"], ["低头", "移开视线"]
        if predicate == "夸" and frame.speaker_role == "patient":
            affect, body = ["害羞", "开心"], ["脸红", "压笑"]

        manner = [
            token for token in frame.attributives
            if self.lexicon.category(token) == "manner"
        ]
        intensity = next(
            (token for token in frame.attributives if self.lexicon.category(token) == "intensity"),
            None,
        )
        modality = [token for token in frame.attributives if self.lexicon.category(token) == "modality"]
        if frame.negated and "不" in self.lexicon and "不" not in modality:
            modality.insert(0, "不")
        descriptor = [
            token for token in frame.attributives
            if self.lexicon.category(token) == "descriptor"
        ]

        phrase = SemanticPhrase(
            scene_subject=frame.subject,
            scene_predicate=predicate,
            scene_object=frame.object,
            affect=affect,
            manner=manner,
            body=body,
            intensity=intensity,
            modality=modality,
            descriptor=descriptor,
            confidence=max(0.0, min(1.0, float(confidence))),
        )
        return self.validator.validate(phrase)