"""Controlled seed vocabulary for motion-relevant semantic compression.

The seed is intentionally smaller than the final 800-1000 word lexicon. It
defines categories, IDs, and the format; corpus-driven expansion can add more
words without changing the runtime contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

CATEGORY_LABELS = {
    "role": "角色/对象",
    "action": "动作/事件",
    "affect": "情绪/状态",
    "manner": "方式/语气",
    "body": "身体部位",
    "motion": "身体动作",
    "social": "被施加的事件",
    "intensity": "强度",
    "modality": "否定/情态",
    "time": "时间/节奏",
    "descriptor": "性格/表演质感",
}

SEED: dict[str, tuple[str, ...]] = {
    "role": ("我", "你", "他", "她", "它", "我们", "你们", "他们", "对方", "自己", "大家"),
    "action": ("骂", "夸", "安慰", "拒绝", "忽视", "质疑", "道歉", "感谢", "嘲笑", "关心", "触碰", "抱", "拉", "推", "追", "离开", "回来", "看着", "沉默", "忍耐", "撒娇", "吐槽", "解释", "责怪", "喜欢", "讨厌", "需要", "误解", "挑衅", "原谅", "保护", "命令", "请求", "告诉", "问", "回答"),
    "affect": ("开心", "难过", "生气", "害羞", "委屈", "惊讶", "害怕", "安心", "疲惫", "得意", "嫉妒", "尴尬", "内疚", "无奈", "期待", "失望", "烦躁", "温柔", "冷漠", "紧张", "放松", "心动", "心虚", "不服", "嘴硬", "心软", "崩溃", "炸毛", "满足", "寂寞", "平静"),
    "manner": ("轻轻", "狠狠", "慢慢", "突然", "小声", "大声", "勉强", "假装", "忍不住", "反复", "犹豫", "果断", "冷淡", "热情", "试探", "克制", "夸张", "认真", "敷衍", "颤抖", "平稳", "急切", "缓慢", "亲昵", "疏离"),
    "body": ("头", "眼睛", "视线", "嘴", "嘴角", "眉毛", "脸", "耳朵", "尾巴", "手", "肩膀", "身体", "呼吸"),
    "motion": ("低头", "抬头", "歪头", "摇头", "点头", "皱眉", "瞪眼", "移开视线", "抿嘴", "咬唇", "笑", "叹气", "哭", "脸红", "缩肩", "后退", "靠近", "伸手", "摸头", "拍肩", "抓住", "尾巴摆动", "停住", "垂下", "转身", "僵住", "躲开", "压笑", "盯着"),
    "social": ("被夸", "被骂", "被忽视", "被拒绝", "被安慰", "被触碰", "被看着", "被误解", "被需要", "被喜欢", "被讨厌", "被质疑", "被保护", "被抛下"),
    "intensity": ("很", "有点", "非常", "稍微", "几乎", "完全", "越来越", "特别", "不太", "过于"),
    "modality": ("不", "没", "不是", "别", "差点", "想要", "必须", "可能", "反而", "还是"),
    "time": ("一开始", "然后", "一直", "又", "还", "最后", "渐渐"),
    "descriptor": ("傲娇", "强撑", "破防", "服软", "装作没事", "失控", "依赖", "可爱", "可靠", "笨"),
}


@dataclass(frozen=True)
class LexiconEntry:
    entry_id: str
    text: str
    category: str


class Lexicon:
    def __init__(self, categories: dict[str, Iterable[str]] | None = None) -> None:
        source = categories or SEED
        entries: list[LexiconEntry] = []
        seen: set[str] = set()
        for category, words in source.items():
            if category not in CATEGORY_LABELS:
                raise ValueError(f"unknown category: {category}")
            for index, word in enumerate(words):
                token = str(word).strip()
                if not token:
                    continue
                if token in seen:
                    raise ValueError(f"duplicate token: {token}")
                seen.add(token)
                entries.append(LexiconEntry(f"{category}.{index}", token, category))
        self.entries = tuple(entries)
        self._by_text = {entry.text: entry for entry in entries}

    def __len__(self) -> int:
        return len(self.entries)

    def __contains__(self, token: str) -> bool:
        return token in self._by_text

    def get(self, token: str) -> LexiconEntry | None:
        return self._by_text.get(token)

    def category(self, token: str) -> str | None:
        entry = self.get(token)
        return entry.category if entry else None

    def by_category(self, category: str) -> tuple[str, ...]:
        return tuple(entry.text for entry in self.entries if entry.category == category)

    def validate_token(self, token: str, category: str | None = None) -> None:
        entry = self.get(token)
        if entry is None:
            raise ValueError(f"token not in lexicon: {token}")
        if category is not None and entry.category != category:
            raise ValueError(f"token {token} is {entry.category}, expected {category}")

    def coverage_report(self) -> dict[str, int]:
        return {category: len(self.by_category(category)) for category in CATEGORY_LABELS}


DEFAULT_LEXICON = Lexicon()