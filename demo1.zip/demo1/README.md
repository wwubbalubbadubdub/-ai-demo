# demo1 — Haru 桌宠整合 Demo

这是一个独立放在 `demo1/` 里的可运行副本，不改动工作区其他位置。

## 启动

```powershell
.\run.bat
```

或：

```powershell
..\.venv\Scripts\python.exe app.py
```

当前默认外观是 **Haru**；设置里仍可切换到鲸鱼娘或大肥鱼。

## API Key

Demo 的 `config.json` 没有写入 Key。二选一：

```powershell
$env:DEEPSEEK_API_KEY="sk-..."
.\run.bat
```

或在 `demo1` 下创建 `.env`：

```text
DEEPSEEK_API_KEY=sk-...
```

没有 Key 时会使用本地演示回复，不会访问 API。

## 面部捕捉 Demo

```powershell
.\run_capture.bat
```

它默认使用 Haru，播放 `analysis/human_motion_20s.json` 里的预计算真人面部动作，不是实时 28 点驱动。

## 已包含

- `desktop_pet/`：主程序
- `tools/text_compiler/`：文本压缩、语气标签
- `assets/live2d/editable/haru/`：官方 Haru 模型（runtime + `.cmo3`）
- `assets/live2d/whale/`：鲸鱼娘模型
- `analysis/reaction_index.json`：字幕/动作检索索引
- `analysis/human_motion_20s.json`：真人捕捉参数
- `analysis/calibration_profile.json`：逐通道校准
- `THIRD_PARTY_NOTICES.md`：素材许可

## 依赖

使用工作区已有的 `..\.venv`：

- PySide6-Essentials
- live2d-py
- spaCy + `zh_core_web_sm`

如果要搬到别处，需要先安装 `requirements.txt` 并准备中文 spaCy 模型。

## 已知限制

- Haru 为官方 PRO 示例；改图层并导出需要能保存 PRO 数据的 Cubism Editor。
- 28 点动漫脸实时驱动尚未接入主程序。
- 面部动作来自预录片段和语义检索，不是实时摄像头/视频输入。
- Haru 的头部/身体动作受原模型参数范围限制。