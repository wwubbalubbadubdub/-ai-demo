"""Play captured human face motion on the whale Live2D model.

Retargeting is per-channel calibration: source min / neutral / max are mapped
piecewise to target min / neutral / max. This avoids raw MediaPipe values being
dumped into a differently-shaped Live2D rig.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from desktop_pet.live2d_whale import HaruLive2DStage, WhaleLive2DStage, shutdown_live2d

MOTION = ROOT / "analysis" / "human_motion_20s.json"
PROFILE = ROOT / "analysis" / "calibration_profile.json"

CHANNELS = ("eye_l", "eye_r", "jaw", "smile", "brow", "gaze_x", "gaze_y", "yaw", "pitch", "roll")


def clamp(v, lo, hi):
    return max(lo, min(hi, float(v)))


def channels(frame):
    b = frame["blendshapes"]
    g = lambda k: float(b.get(k, 0.0))
    return {
        "eye_l": 1.0 - g("eyeBlinkLeft"),
        "eye_r": 1.0 - g("eyeBlinkRight"),
        "jaw": g("jawOpen"),
        "smile": (g("mouthSmileLeft") + g("mouthSmileRight")) / 2,
        "brow": g("browInnerUp") - (g("browDownLeft") + g("browDownRight")) / 2,
        "gaze_x": (g("eyeLookOutLeft") + g("eyeLookInRight")) - (g("eyeLookInLeft") + g("eyeLookOutRight")),
        "gaze_y": (g("eyeLookUpLeft") + g("eyeLookUpRight")) - (g("eyeLookDownLeft") + g("eyeLookDownRight")),
        "yaw": float(frame["head"][0]),
        "pitch": float(frame["head"][1]),
        "roll": float(frame["head"][2]),
    }


def fit_profile(frames):
    rows = [channels(f) for f in frames]
    profile = {}
    for key in CHANNELS:
        values = np.array([r[key] for r in rows], dtype=np.float64)
        lo, mid, hi = np.percentile(values, [2, 50, 98])
        if hi - lo < 1e-5:
            lo, mid, hi = float(values.min()), float(np.median(values)), float(values.max())
        profile[key] = {"min": float(lo), "neutral": float(mid), "max": float(hi)}
    return profile


def map_piecewise(value, spec, target_min, target_neutral, target_max):
    lo, mid, hi = spec["min"], spec["neutral"], spec["max"]
    if value <= mid:
        u = 0.0 if mid <= lo else (value - lo) / (mid - lo)
        out = target_neutral + clamp(u, 0, 1) * (target_min - target_neutral)
    else:
        u = 0.0 if hi <= mid else (value - mid) / (hi - mid)
        out = target_neutral + clamp(u, 0, 1) * (target_max - target_neutral)
    return float(out)


def to_params(frame, profile):
    c = channels(frame)
    eye_l = map_piecewise(c["eye_l"], profile["eye_l"], 0.0, 0.85, 1.0)
    eye_r = map_piecewise(c["eye_r"], profile["eye_r"], 0.0, 0.85, 1.0)
    jaw = map_piecewise(c["jaw"], profile["jaw"], 0.0, 0.1, 1.0)
    smile = map_piecewise(c["smile"], profile["smile"], -0.2, 0.0, 0.8)
    brow = map_piecewise(c["brow"], profile["brow"], -0.6, 0.0, 0.6)
    gaze_x = map_piecewise(c["gaze_x"], profile["gaze_x"], -0.8, 0.0, 0.8)
    gaze_y = map_piecewise(c["gaze_y"], profile["gaze_y"], -0.8, 0.0, 0.8)
    yaw = map_piecewise(c["yaw"], profile["yaw"], -12.0, 0.0, 12.0)
    pitch = map_piecewise(c["pitch"], profile["pitch"], -10.0, 0.0, 10.0)
    roll = map_piecewise(c["roll"], profile["roll"], -8.0, 0.0, 8.0)
    return {
        "ParamAngleX": yaw,
        "ParamAngleY": -pitch,
        "ParamAngleZ": roll,
        "ParamBodyAngleX": yaw * 0.4,
        "ParamEyeLOpen": clamp(eye_l, 0, 1),
        "ParamEyeROpen": clamp(eye_r, 0, 1),
        "ParamEyeBallX": clamp(gaze_x, -1, 1),
        "ParamEyeBallY": clamp(gaze_y, -1, 1),
        "ParamMouthOpenY": clamp(jaw, 0, 1),
        "ParamMouthForm": clamp(smile, -1, 1),
        "ParamBrowLY": clamp(brow, -1, 1),
        "ParamBrowRY": clamp(brow, -1, 1),
        "ParamCheek": clamp(smile * 0.65, 0, 1),
    }


def load_sequence():
    data = json.loads(MOTION.read_text(encoding="utf-8"))
    frames = data["frames"]
    profile = fit_profile(frames)
    PROFILE.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = [to_params(f, profile) for f in frames]
    # EMA on each target parameter
    out = []
    current = dict(rows[0])
    alpha = 0.32
    for row in rows:
        for key, value in row.items():
            current[key] = current[key] * (1 - alpha) + value * alpha
        out.append(dict(current))
    return out


class CaptureStage(WhaleLive2DStage):
    model_json = HaruLive2DStage.model_json
    scale = HaruLive2DStage.scale
    offset_y = HaruLive2DStage.offset_y

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(600, 600)
        self.setMaximumSize(600, 600)
        self.capture_params: dict[str, float] | None = None

    def initializeGL(self):
        super().initializeGL()
        if self._model is not None:
            try:
                self._model.SetAutoBlink(False)
                self._model.SetAutoBreath(False)
                self._model.StopAllMotions()
            except Exception:
                pass

    def _apply_parameters(self):
        if self.capture_params is None:
            return super()._apply_parameters()
        for param_id, value in self.capture_params.items():
            self._set_param(param_id, value, 1.0)


def wait_loaded(stage, app, timeout=8.0):
    start = time.time()
    while time.time() - start < timeout:
        app.processEvents()
        if stage._loaded or stage._failed:
            break
        time.sleep(0.02)
    return stage._loaded


def render_frames(outdir: Path, limit: int | None = None):
    app = QApplication.instance() or QApplication(sys.argv)
    stage = CaptureStage()
    stage.resize(600, 600)
    stage.show()
    if not wait_loaded(stage, app):
        print("Live2D load failed", file=sys.stderr)
        return 2
    rows = load_sequence()
    if limit is not None:
        rows = rows[:limit]
    outdir.mkdir(parents=True, exist_ok=True)
    for index, row in enumerate(rows):
        stage.capture_params = row
        stage.update()
        stage.repaint()
        app.processEvents()
        image = stage.grabFramebuffer()
        if image.isNull():
            print("null framebuffer at", index, file=sys.stderr)
            break
        image.save(str(outdir / f"frame_{index:04d}.png"))
        if index % 60 == 0:
            print("rendered", index, "/", len(rows))
    stage.shutdown()
    shutdown_live2d()
    return 0


def play():
    app = QApplication.instance() or QApplication(sys.argv)
    rows = load_sequence()
    window = QWidget()
    window.setWindowTitle("Human face capture -> Live2D")
    layout = QVBoxLayout(window)
    stage = CaptureStage(window)
    info = QLabel("真人切片 72–92s / 30fps / 每通道 min-neutral-max 校准")
    info.setStyleSheet("color:#555; padding:6px;")
    layout.addWidget(info)
    layout.addWidget(stage)
    window.resize(620, 680)
    window.show()
    if not wait_loaded(stage, app):
        print("Live2D load failed", file=sys.stderr)
        return 2
    index = 0
    timer = QTimer()

    def tick():
        nonlocal index
        if index >= len(rows):
            index = 0
        stage.capture_params = rows[index]
        stage.update()
        index += 1

    timer.timeout.connect(tick)
    timer.start(33)
    return app.exec()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--render", type=Path, help="render PNG frames into this directory")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    if args.render:
        return render_frames(args.render, args.limit)
    return play()


if __name__ == "__main__":
    raise SystemExit(main())