# Haru sample provenance

- Official source: https://cubism.live2d.com/sample-data/bin/haru/haru_ja.zip
- Official sample page: https://www.live2d.com/zh-CHS/learn/sample/
- Local zip: `assets/live2d/editable/haru/haru.zip`
- SHA-256: `3686daa9ed014d0d56c623ef66ba85132fbee3558d2e3e34a154d833c86cebdd`
- License: Live2D free material license / sample model terms; see the official `ReadMe.txt` and the sample model terms.
- This copy is kept locally for a personal, non-commercial desktop-pet demo. Model files are not redistributed.
- For Haru: the ReadMe identifies it as the PRO sample; editing and re-exporting requires an editor edition that can save the file.
