# 第三方组件与素材许可

本项目的代码和第三方素材分开授权。**鲸鱼娘 Live2D 模型不是 MIT 素材，且仅限非商业使用。**

## 1. 鲸鱼娘 Live2D 模型（重要）

- 文件位置：`assets/live2d/whale/`
- 模型：`c_0120.moc3`、`c_0120.model3.json`、贴图、动作、物理和显示信息
- 来源：<https://github.com/Andersen216/dsh-whale-girl-live2d>
- 许可：**CC BY-NC-SA 4.0**（署名—非商业性使用—相同方式共享）
- 许可全文：<https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh>

角色形象与模型署名（必须保留）：

| 署名 | 贡献 | 主页 |
| --- | --- | --- |
| **上善无形** | 鲸鱼娘角色形象原作，原创 OC「溟月」 | <https://space.bilibili.com/4456176> |
| **ZipZipPipe** | 加入 DeepSeek 元素的「女仆鲸鱼娘」二次设计 | <https://space.bilibili.com/4168597> |
| **氵六青** | 本模型所用 Live2D 模型（绑定、动作、表情） | <https://space.bilibili.com/11272072> |

说明：

1. **非商业限制**：不得将本模型或其衍生作品用于收费产品、付费服务、广告变现、带货等商业用途。个人、免费的桌宠使用属于非商业用途。
2. **相同方式共享**：如果修改并再分发模型素材，需要继续使用 CC BY-NC-SA 4.0，并说明修改内容。
3. 本项目只对下载的动作文件名做了 URL 解码（例如 `%E5%96%B7%E6%B0%B4` → `喷水`），没有修改模型、贴图或动作内容。
4. 模型作者的使用须知允许自定义桌宠改造，但不解除角色形象的 CC BY-NC-SA 条件；不得盗用或出售模型。
5. 如果要把本项目用于商业用途，请**替换成你有权商用的模型**，或直接联系上述权利人取得授权。

完整的来源说明保留在 `assets/live2d/whale/PROVENANCE.md` 和 `assets/live2d/whale/AUTHORS.md`。

## 2. live2d-py

- 项目：<https://github.com/EasyLive2D/live2d-py>
- 用途：在 Python 中加载并绘制 Cubism 3+ 模型
- 许可：MIT（见上游仓库 LICENSE）

## 3. Live2D Cubism Core / Native SDK

- 版权：Live2D Inc.
- live2d-py 的安装包中包含/依赖 Live2D Cubism Core 的可再分发组件
- 使用时需遵守 Live2D 的 SDK 许可：<https://www.live2d.com/en/sdk/license/>

本项目不是 Live2D Inc. 官方产品。

## 4. PySide6 / Qt

- 项目：<https://doc.qt.io/qtforpython-6/>
- 许可：LGPLv3 / GPLv3 / Qt 商业许可（按发行方式选择）
- 本项目的依赖为 `PySide6-Essentials`

## 5. 其他 Python 依赖

- NumPy：BSD 3-Clause
- Pillow：HPND
- PyOpenGL：BSD
- pytest（仅开发测试）：MIT

## 6. 用户提供的参考图

用户提供的参考图仅用于确定形象方向，没有作为程序资源打包进项目。项目中的 Live2D 模型来自上述上游仓库，并按该仓库的 CC BY-NC-SA 条件使用。

## 1A. Haru / Simple 官方示例模型（本地 Demo 底模）

- 来源：Live2D 官方示例数据
  - <https://www.live2d.com/zh-CHS/learn/sample/>
  - <https://cubism.live2d.com/sample-data/bin/haru/haru_ja.zip>
  - <https://cubism.live2d.com/sample-data/bin/simple/simple_ja.zip>
- 本地位置：
  - `assets/live2d/editable/haru/`
  - `assets/live2d/editable/simple/`
- 许可：Live2D 免费素材许可 / 示例数据使用条件；具体见各目录的 `ReadMe.txt` 和 `PROVENANCE.md`。
- 仅用于个人、非商业桌宠 Demo；不对外再分发官方模型压缩包或原始素材。
- Haru 的 ReadMe 标注为 **PRO 版模型**；编辑并导出修改后的 `.cmo3` 需要能保存 PRO 数据的 Cubism Editor 版本。
- Simple 的 ReadMe 说明只有颈部倾斜、眼睛开闭、嘴巴开闭；它只作为免费可编辑替代方案保留，不作为当前主底模。