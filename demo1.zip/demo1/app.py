"""Convenience launcher for `python app.py`."""

from __future__ import annotations

import sys

from desktop_pet.app import main

if __name__ == "__main__":
    sys.exit(main())