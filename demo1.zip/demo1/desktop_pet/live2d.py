"""The character stage.

This file is the Live2D seam.  The desktop pet currently draws an animated
placeholder fish with QPainter; later a real Live2D renderer can replace this
widget as long as it keeps the small public API at the bottom of the class:

    set_state(state), set_speaking(bool), set_expression(name), play_motion(name)
"""

from __future__ import annotations

import logging
import math
import random

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QLinearGradient,
    QMouseEvent,
    QPainter,
    QPainterPath,
    QPen,
    QRadialGradient,
    QBrush,
)
from PySide6.QtWidgets import QWidget

logger = logging.getLogger(__name__)

IDLE = "idle"
THINKING = "thinking"
SPEAKING = "speaking"
HAPPY = "happy"
ERROR = "error"


def _heart_path(x: float, y: float, size: float) -> QPainterPath:
    path = QPainterPath()
    path.moveTo(x, y + size * 0.3)
    path.cubicTo(x, y, x + size * 0.5, y, x + size * 0.5, y + size * 0.3)
    path.cubicTo(x + size * 0.5, y + size * 0.62, x, y + size * 0.82, x, y + size)
    path.cubicTo(x, y + size * 0.82, x - size * 0.5, y + size * 0.62, x - size * 0.5, y + size * 0.3)
    path.cubicTo(x - size * 0.5, y, x, y, x, y + size * 0.3)
    path.closeSubpath()
    return path


class Live2DStage(QWidget):
    """Animated fish placeholder; click/drag support is built in."""

    double_clicked = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedHeight(270)
        self.setMinimumWidth(320)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setToolTip("按住拖动桌宠，双击开始聊天")

        self._state = IDLE
        self._time = 0.0
        self._blink = 0.0
        self._next_blink = random.uniform(2.5, 4.5)
        self._bubbles: list[dict[str, float]] = []
        self._hearts: list[dict[str, float]] = []
        self._bubble_timer = 0.8
        self._hover = False
        self._pressed = False
        self._drag_offset = QPoint()

        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._tick)

    # ------------------------------------------------------------------ state
    def set_state(self, state: str) -> None:
        if state not in {IDLE, THINKING, SPEAKING, HAPPY, ERROR}:
            state = IDLE
        previous = self._state
        self._state = state
        if state == HAPPY and previous != HAPPY:
            self._spawn_hearts()
        self.update()

    def set_speaking(self, speaking: bool) -> None:
        self.set_state(SPEAKING if speaking else IDLE)

    def set_expression(self, name: str) -> None:
        """Compatibility hook for a future Live2D expression controller."""

        mapping = {
            "happy": HAPPY,
            "thinking": THINKING,
            "sad": ERROR,
            "neutral": IDLE,
        }
        self.set_state(mapping.get(name, IDLE))

    def play_motion(self, name: str) -> None:
        """Compatibility hook for a future Live2D motion controller."""

        if name in {"tap", "happy", "wave"}:
            self.set_state(HAPPY)

    # --------------------------------------------------------------- animation
    def _tick(self) -> None:
        self._time += 0.033
        if self._blink > 0:
            self._blink = max(0.0, self._blink - 0.033)
        else:
            self._next_blink -= 0.033
            if self._next_blink <= 0:
                self._blink = 0.16
                self._next_blink = random.uniform(2.8, 5.4)

        self._bubble_timer -= 0.033
        interval = 0.55 if self._state == SPEAKING else 2.1
        if self._bubble_timer <= 0:
            self._bubble_timer = interval + random.uniform(-0.2, 0.4)
            self._spawn_bubble()

        for bubble in self._bubbles:
            bubble["y"] -= bubble["speed"] * 0.033
            bubble["x"] += math.sin(self._time * 2.0 + bubble["phase"]) * 0.18
            bubble["life"] -= 0.033
        self._bubbles = [b for b in self._bubbles if b["life"] > 0 and b["y"] > 42]

        for heart in self._hearts:
            heart["y"] -= 22 * 0.033
            heart["x"] += math.sin(self._time * 3.0 + heart["phase"]) * 0.25
            heart["life"] -= 0.033
        self._hearts = [h for h in self._hearts if h["life"] > 0]

        self.update()

    def _spawn_bubble(self, x: float | None = None, y: float | None = None) -> None:
        self._bubbles.append(
            {
                "x": (300.0 if x is None else x) + random.uniform(-6, 8),
                "y": (168.0 if y is None else y) + random.uniform(-4, 4),
                "r": random.uniform(2.2, 5.8),
                "speed": random.uniform(12, 28),
                "phase": random.uniform(0, math.tau),
                "life": random.uniform(2.6, 4.2),
            }
        )

    def _spawn_hearts(self) -> None:
        for _ in range(6):
            self._hearts.append(
                {
                    "x": random.uniform(185, 285),
                    "y": random.uniform(95, 145),
                    "size": random.uniform(7, 12),
                    "phase": random.uniform(0, math.tau),
                    "life": random.uniform(1.1, 1.8),
                }
            )

    # ------------------------------------------------------------------ paint
    def paintEvent(self, event) -> None:  # noqa: N802 (Qt API)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

        w, h = self.width(), self.height()
        scale = min(w / 400.0, h / 270.0)
        painter.translate((w - 400 * scale) / 2, (h - 270 * scale) / 2)
        painter.scale(scale, scale)

        self._paint_glow(painter)
        self._paint_bubbles(painter, behind=True)
        self._paint_shadow(painter)
        self._paint_fish(painter)
        self._paint_bubbles(painter, behind=False)
        self._paint_hearts(painter)
        self._paint_thought(painter)
        if self._hover:
            self._paint_hint(painter)
        painter.end()

    def _paint_glow(self, painter: QPainter) -> None:
        gradient = QRadialGradient(205, 142, 150)
        gradient.setColorAt(0.0, QColor(124, 214, 255, 46))
        gradient.setColorAt(0.62, QColor(124, 214, 255, 18))
        gradient.setColorAt(1.0, QColor(124, 214, 255, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(gradient)
        painter.drawEllipse(QRectF(35, 0, 340, 275))

    def _paint_shadow(self, painter: QPainter) -> None:
        bob = math.sin(self._time * 1.7) * 5.0
        shadow = QRadialGradient(212, 227, 82)
        shadow.setColorAt(0.0, QColor(16, 56, 92, 65))
        shadow.setColorAt(0.75, QColor(16, 56, 92, 18))
        shadow.setColorAt(1.0, QColor(16, 56, 92, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(shadow)
        width = 148 - abs(bob) * 1.6
        painter.drawEllipse(QRectF(212 - width / 2, 220, width, 20))

    def _paint_fish(self, painter: QPainter) -> None:
        bob = math.sin(self._time * 1.7) * 5.0
        painter.save()
        painter.translate(0, bob)

        # tail, with a gentle wag
        painter.save()
        painter.translate(126, 148)
        painter.rotate(math.sin(self._time * 2.1) * 5.0)
        painter.translate(-126, -148)
        tail = QPainterPath()
        tail.moveTo(130, 145)
        tail.cubicTo(105, 120, 84, 94, 56, 82)
        tail.cubicTo(67, 116, 74, 131, 52, 146)
        tail.cubicTo(73, 154, 86, 168, 58, 192)
        tail.cubicTo(92, 183, 113, 166, 131, 154)
        tail.closeSubpath()
        tail_gradient = QLinearGradient(56, 0, 140, 0)
        tail_gradient.setColorAt(0.0, QColor(255, 159, 135))
        tail_gradient.setColorAt(1.0, QColor(255, 118, 118))
        painter.setBrush(tail_gradient)
        painter.setPen(QPen(QColor(227, 92, 92, 90), 1.5))
        painter.drawPath(tail)
        painter.restore()

        # top fin
        top_fin = QPainterPath()
        top_fin.moveTo(185, 96)
        top_fin.cubicTo(194, 61, 232, 54, 252, 81)
        top_fin.cubicTo(232, 80, 212, 88, 199, 101)
        top_fin.closeSubpath()
        fin_gradient = QLinearGradient(0, 58, 0, 102)
        fin_gradient.setColorAt(0.0, QColor(255, 168, 143))
        fin_gradient.setColorAt(1.0, QColor(255, 118, 118))
        painter.setBrush(fin_gradient)
        painter.setPen(QPen(QColor(227, 92, 92, 80), 1.2))
        painter.drawPath(top_fin)

        # body
        body = QPainterPath()
        body.moveTo(117, 151)
        body.cubicTo(124, 108, 165, 84, 222, 85)
        body.cubicTo(276, 86, 306, 111, 306, 147)
        body.cubicTo(306, 183, 276, 209, 228, 211)
        body.cubicTo(176, 213, 128, 191, 117, 151)
        body.closeSubpath()
        body_gradient = QLinearGradient(0, 84, 0, 212)
        body_gradient.setColorAt(0.0, QColor(141, 222, 249))
        body_gradient.setColorAt(0.48, QColor(84, 178, 235))
        body_gradient.setColorAt(1.0, QColor(45, 130, 204))
        painter.setBrush(body_gradient)
        painter.setPen(QPen(QColor(255, 255, 255, 92), 2.0))
        painter.drawPath(body)

        # belly
        belly = QPainterPath()
        belly.moveTo(151, 187)
        belly.cubicTo(177, 208, 235, 210, 280, 183)
        belly.cubicTo(267, 207, 231, 218, 195, 214)
        belly.cubicTo(171, 211, 156, 201, 151, 187)
        belly.closeSubpath()
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(240, 253, 255, 155))
        painter.drawPath(belly)

        # gloss
        painter.setBrush(QColor(255, 255, 255, 56))
        painter.drawEllipse(QRectF(169, 101, 72, 24))

        # side fin
        painter.save()
        painter.translate(208, 166)
        painter.rotate(22)
        painter.setBrush(QColor(255, 255, 255, 64))
        painter.setPen(QPen(QColor(255, 255, 255, 90), 1.0))
        painter.drawEllipse(QRectF(-29, -15, 58, 30))
        painter.restore()

        # cheek
        cheek = QRadialGradient(276, 168, 13)
        cheek.setColorAt(0.0, QColor(255, 134, 151, 120))
        cheek.setColorAt(1.0, QColor(255, 134, 151, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(cheek)
        painter.drawEllipse(QRectF(263, 155, 28, 25))

        # eye
        if self._blink > 0:
            painter.setPen(
                QPen(QColor(30, 52, 82), 3.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            )
            painter.drawLine(QPointF(245, 136), QPointF(272, 136))
        else:
            painter.setPen(QPen(QColor(255, 255, 255, 175), 1.2))
            painter.setBrush(QColor(255, 255, 255))
            painter.drawEllipse(QRectF(243, 117, 29, 34))
            painter.setPen(Qt.PenStyle.NoPen)
            pupil_y = 131 + math.sin(self._time * 0.7) * 1.2
            painter.setBrush(QColor(28, 49, 79))
            painter.drawEllipse(QRectF(250, pupil_y, 15, 18))
            painter.setBrush(QColor(255, 255, 255))
            painter.drawEllipse(QRectF(254, pupil_y + 3, 5.5, 6.5))

        # eyebrow-ish little highlight above the eye
        painter.setPen(QPen(QColor(255, 255, 255, 125), 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(QRectF(244, 104, 25, 14), 20 * 16, 140 * 16)

        # mouth
        speaking = self._state == SPEAKING
        if speaking:
            open_amount = 3.0 + (math.sin(self._time * 18) + 1) * 3.2
            painter.setPen(QPen(QColor(148, 55, 74), 1.5))
            painter.setBrush(QColor(124, 48, 68))
            painter.drawEllipse(QRectF(287, 165 - open_amount / 2, 13, open_amount))
        else:
            painter.setPen(
                QPen(QColor(148, 55, 74), 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            )
            painter.setBrush(Qt.BrushStyle.NoBrush)
            smile = QPainterPath()
            smile.moveTo(285, 167)
            smile.cubicTo(291, 174, 299, 174, 304, 166)
            painter.drawPath(smile)

        painter.restore()

    def _paint_bubbles(self, painter: QPainter, *, behind: bool) -> None:
        for bubble in self._bubbles:
            if behind != (bubble["x"] < 230):
                continue
            alpha = int(160 * min(1.0, bubble["life"] / 1.2))
            painter.setPen(QPen(QColor(255, 255, 255, alpha), 1.2))
            painter.setBrush(QColor(198, 242, 255, max(0, alpha // 10)))
            rect = QRectF(
                bubble["x"] - bubble["r"],
                bubble["y"] - bubble["r"],
                bubble["r"] * 2,
                bubble["r"] * 2,
            )
            painter.drawEllipse(rect)
            painter.setBrush(QColor(255, 255, 255, max(0, alpha // 2)))
            painter.drawEllipse(
                QRectF(bubble["x"] - bubble["r"] * 0.45, bubble["y"] - bubble["r"] * 0.5,
                       bubble["r"] * 0.45, bubble["r"] * 0.45)
            )

    def _paint_hearts(self, painter: QPainter) -> None:
        for heart in self._hearts:
            alpha = int(200 * min(1.0, heart["life"] / 0.5))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(255, 117, 150, max(0, alpha)))
            painter.drawPath(_heart_path(heart["x"], heart["y"], heart["size"]))

    def _paint_thought(self, painter: QPainter) -> None:
        if self._state not in {THINKING, ERROR}:
            return
        base_x, base_y = 323, 72
        painter.setPen(QPen(QColor(255, 255, 255, 170), 1.0))
        painter.setBrush(QColor(255, 255, 255, 225))
        painter.drawEllipse(QRectF(base_x - 27, base_y - 17, 55, 34))
        painter.drawEllipse(QRectF(base_x - 15, base_y + 11, 9, 8))
        painter.drawEllipse(QRectF(base_x - 25, base_y + 17, 6, 5))
        if self._state == ERROR:
            painter.setPen(QPen(QColor(220, 70, 90), 2.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawLine(QPointF(base_x, base_y - 7), QPointF(base_x, base_y + 3))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(220, 70, 90))
            painter.drawEllipse(QRectF(base_x - 1.8, base_y + 6, 3.6, 3.6))
        else:
            for index in range(3):
                pulse = 0.45 + 0.55 * (0.5 + 0.5 * math.sin(self._time * 5 - index * 0.7))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(80, 142, 196, int(210 * pulse)))
                painter.drawEllipse(QRectF(base_x - 16 + index * 11, base_y - 2, 5, 5))

    def _paint_hint(self, painter: QPainter) -> None:
        rect = QRectF(130, 239, 140, 21)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(20, 44, 72, 145))
        painter.drawRoundedRect(rect, 10.5, 10.5)
        painter.setPen(QColor(255, 255, 255, 225))
        font = QFont("Microsoft YaHei UI", 8)
        painter.setFont(font)
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "按住拖动 · 双击聊天")

    # ------------------------------------------------------------------ mouse
    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed = True
            self._drag_offset = (
                event.globalPosition().toPoint() - self.window().frameGeometry().topLeft()
            )
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._pressed and event.buttons() & Qt.MouseButton.LeftButton:
            self.window().move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed = False
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def enterEvent(self, event) -> None:  # noqa: N802
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._hover = False
        self.update()
        super().leaveEvent(event)

    # --------------------------------------------------------------- lifecycle
    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()

    def hideEvent(self, event) -> None:  # noqa: N802
        self._timer.stop()
        super().hideEvent(event)
def create_stage(appearance: str, parent: QWidget) -> tuple[QWidget, str]:
    """Return the requested stage, falling back to the fish if Live2D is absent."""

    if appearance == "haru":
        try:
            from .live2d_whale import HaruLive2DStage

            if HaruLive2DStage.is_available():
                return HaruLive2DStage(parent), "haru"
            logger.warning("Haru 模型缺失，尝试回退到鲸鱼娘")
        except Exception:
            logger.exception("无法创建 Haru 舞台")
    if appearance in {"haru", "live2d"}:
        try:
            from .live2d_whale import WhaleLive2DStage

            if WhaleLive2DStage.is_available():
                return WhaleLive2DStage(parent), "live2d"
            logger.warning("Live2D 模型或运行时缺失，回退到大肥鱼外观")
        except Exception:
            logger.exception("无法创建 Live2D 舞台，回退到大肥鱼外观")
    return Live2DStage(parent), "fish"