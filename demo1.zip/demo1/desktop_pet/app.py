"""Application bootstrap, logging, and developer screenshot mode."""

from __future__ import annotations

import argparse
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QFont, QGuiApplication, QSurfaceFormat
from PySide6.QtWidgets import QApplication, QMessageBox

from .config import (
    PROJECT_ROOT,
    config_path_from_env,
    load_config,
    load_dotenv,
)
from .theme import APP_STYLE, make_app_icon
from .window import PetWindow

logger = logging.getLogger(__name__)


def setup_logging(*, verbose: bool = False) -> Path:
    log_dir = PROJECT_ROOT / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "desktop_pet.log"

    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    if root.handlers:
        return log_path

    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=1_000_000,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    if verbose:
        console = logging.StreamHandler()
        console.setFormatter(formatter)
        root.addHandler(console)
    return log_path


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="dafeiyu-pet",
        description="大肥鱼桌宠：Live2D 占位角色 + DeepSeek 对话",
    )
    parser.add_argument("--demo", action="store_true", help="强制使用本地演示模式")
    parser.add_argument("--config", type=Path, help="指定配置文件路径")
    parser.add_argument("--screenshot", type=Path, help="渲染窗口截图后退出（开发用）")
    parser.add_argument("--smoke-test", action="store_true", help="启动后自动退出（开发用）")
    parser.add_argument("--verbose", action="store_true", help="在控制台输出调试日志")
    parser.add_argument("--version", action="version", version="大肥鱼桌宠 0.2.0")
    return parser.parse_args(argv)


def _capture(window: PetWindow, path: Path) -> None:
    try:
        path = path.expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        if window.grab().save(str(path)):
            logger.info("截图已保存: %s", path)
        else:
            logger.error("截图保存失败: %s", path)
    except OSError:
        logger.exception("截图失败")
    finally:
        window.quit_app()


def _install_exception_hook() -> None:
    def hook(exc_type, exc_value, exc_traceback):
        logger.critical(
            "未捕获异常",
            exc_info=(exc_type, exc_value, exc_traceback),
        )
        QMessageBox.critical(
            None,
            "桌宠出了点问题",
            f"{exc_type.__name__}: {exc_value}\n\n详细日志在 logs/desktop_pet.log",
        )

    sys.excepthook = hook


def main(argv: list[str] | None = None) -> int:
    args = parse_args(list(argv if argv is not None else sys.argv[1:]))
    if args.config:
        args.config = args.config.expanduser()
        os.environ["PET_CONFIG_PATH"] = str(args.config)
    load_dotenv()
    log_path = setup_logging(verbose=args.verbose)
    _install_exception_hook()

    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    surface = QSurfaceFormat.defaultFormat()
    surface.setAlphaBufferSize(8)
    surface.setSamples(4)
    surface.setSwapInterval(1)
    QSurfaceFormat.setDefaultFormat(surface)

    app = QApplication([sys.argv[0]])
    app.setApplicationName("DafeiyuPet")
    app.setApplicationDisplayName("大肥鱼桌宠")
    app.setOrganizationName("Dafeiyu")
    app.setQuitOnLastWindowClosed(False)
    app.setWindowIcon(make_app_icon(64))
    app.setStyle("Fusion")
    app.setStyleSheet(APP_STYLE)
    app.setFont(QFont("Microsoft YaHei UI", 10))

    config_path = (args.config or config_path_from_env()).expanduser()
    config = load_config(config_path)
    logger.info("启动桌宠，配置: %s，日志: %s", config_path, log_path)

    window = PetWindow(config, config_path=config_path, demo_override=args.demo)
    window.show()

    if args.screenshot:
        QTimer.singleShot(1300, lambda: _capture(window, args.screenshot))
    elif args.smoke_test:
        QTimer.singleShot(1800, window.quit_app)

    exit_code = app.exec()
    try:
        from .live2d_whale import shutdown_live2d

        shutdown_live2d()
    except Exception:
        logger.exception("释放 Live2D 运行时失败")
    return exit_code