"""Real Live2D rendering for the whale-girl appearance.

The model is a Cubism 3+ model loaded through live2d-py's native runtime and
painted into a transparent QOpenGLWidget.  The non-commercial model licence is
documented in THIRD_PARTY_NOTICES.md and assets/live2d/whale/PROVENANCE.md.
"""

from __future__ import annotations

import importlib.util
import logging
import math
import random
from pathlib import Path

from PySide6.QtCore import QPoint, QTimer, Qt, Signal
from PySide6.QtGui import QCursor, QMouseEvent
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import QSizePolicy, QWidget

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MODEL_JSON = PROJECT_ROOT / "assets" / "live2d" / "whale" / "c_0120.model3.json"

IDLE = "idle"
THINKING = "thinking"
SPEAKING = "speaking"
HAPPY = "happy"
ERROR = "error"

_SCALE = 1.30
_RUNTIME_READY = False
_RUNTIME = None


def _runtime():
    """Import and initialize live2d-py lazily, once per process."""

    global _RUNTIME_READY, _RUNTIME
    if _RUNTIME is None:
        import live2d

        _RUNTIME = live2d
    if not _RUNTIME_READY:
        _RUNTIME.init()
        try:
            _RUNTIME.setLogLevel(_RUNTIME.LogLevels.LV_WARN)
        except Exception:
            pass
        _RUNTIME_READY = True
    return _RUNTIME


def shutdown_live2d() -> None:
    global _RUNTIME_READY
    if _RUNTIME_READY and _RUNTIME is not None:
        try:
            _RUNTIME.dispose()
        except Exception:
            logger.exception("释放 Live2D 运行时失败")
        _RUNTIME_READY = False


class WhaleLive2DStage(QOpenGLWidget):
    model_json = MODEL_JSON
    scale = _SCALE
    offset_y = 0.0
    """Transparent, interactive Live2D stage with the same API as the fish."""

    double_clicked = Signal()
    load_failed = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedHeight(270)
        self.setMinimumWidth(320)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAutoFillBackground(False)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setToolTip("按住拖动桌宠，双击开始聊天，单击摸摸头")

        self._model = None
        self._param_ids: set[str] = set()
        self._state = IDLE
        self._failed = False
        self._loaded = False
        self._speaking = False
        self._pending_motion: str | None = None
        self._drag_offset = QPoint()
        self._pressed = False
        self._drag_moved = False
        self._idle_generation = 0
        self._mouth_phase = 0.0

        self._reaction_frames: list[dict[str, float]] = []
        self._reaction_index = 0
        self._reaction_params: dict[str, float] | None = None
        self._reaction_weight = 0.0
        self._reaction_target = 0.0
        self._reaction_loop = False
        self._reaction_timer = QTimer(self)
        self._reaction_timer.setInterval(66)
        self._reaction_timer.timeout.connect(self._reaction_tick)

        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self.update)

    # ------------------------------------------------------------- capability
    @classmethod
    def is_available(cls) -> bool:
        try:
            if importlib.util.find_spec("live2d") is None:
                return False
        except (ImportError, ValueError):
            return False
        stem = cls.model_json.name.removesuffix(".model3.json")
        required = [cls.model_json, cls.model_json.with_name(stem + ".moc3")]
        return all(path.is_file() for path in required)

    # ------------------------------------------------------------------- GL
    def initializeGL(self) -> None:
        try:
            live2d = _runtime()
            live2d.glInit()
            model = live2d.Model()
            model.LoadModelJson(str(self.model_json))
            model.Resize(self.width(), self.height())
            model.SetScale(self.scale)
            model.SetOffsetY(self.offset_y)
            model.SetAutoBreath(True)
            model.SetAutoBlink(True)
            self._model = model
            self._param_ids = set(model.GetParamIds())
            self._param_lookup = {p.replace("_", "").lower(): p for p in self._param_ids}
            self._loaded = True
            logger.info(
                "Live2D 模型已加载: %s，参数 %d 个",
                self.model_json.name,
                len(self._param_ids),
            )
            self._start_idle(force=True)
            if self._pending_motion:
                motion, self._pending_motion = self._pending_motion, None
                self.play_motion(motion)
            if self.isVisible():
                self._timer.start()
        except Exception as exc:
            logger.exception("Live2D 初始化失败")
            self._failed = True
            self.load_failed.emit(f"Live2D 初始化失败：{exc}")

    def resizeGL(self, width: int, height: int) -> None:
        if self._model is not None:
            self._model.Resize(width, height)
            self._model.SetScale(self.scale)
            self._model.SetOffsetY(self.offset_y)

    def paintGL(self) -> None:
        live2d = _runtime()
        live2d.clearBuffer(0.0, 0.0, 0.0, 0.0)
        if self._model is None:
            return
        self._model.Update()
        self._apply_parameters()
        self._model.Draw()

    # ---------------------------------------------------------------- state
    def set_state(self, state: str) -> None:
        if state not in {IDLE, THINKING, SPEAKING, HAPPY, ERROR}:
            state = IDLE
        previous = self._state
        self._state = state
        self._speaking = state == SPEAKING
        if state == HAPPY and previous != HAPPY:
            self.play_motion("bubble")
        self.update()

    def set_speaking(self, speaking: bool) -> None:
        self.set_state(SPEAKING if speaking else IDLE)

    def set_expression(self, name: str) -> None:
        mapping = {
            "happy": HAPPY,
            "thinking": THINKING,
            "sad": ERROR,
            "neutral": IDLE,
        }
        self.set_state(mapping.get(name, IDLE))

    def play_motion(self, name: str) -> None:
        if not self._loaded or self._model is None:
            self._pending_motion = name
            return
        groups = {
            "tap": ("bubble", "openLid", "ketchup"),
            "happy": ("bubble", "selfieQuick"),
            "wave": ("selfieQuick", "selfie"),
            "bubble": ("bubble",),
            "splash": ("splash",),
        }
        choices = groups.get(name, groups.get("tap", ()))
        if not choices:
            return
        group = random.choice(choices)
        try:
            if group in self._model.GetMotionGroups():
                self._idle_generation += 1
                self._model.StartRandomMotion(
                    group,
                    _runtime().MotionPriority.NORMAL,
                    onFinish=lambda *_args: QTimer.singleShot(800, self._start_idle),
                )
        except Exception:
            logger.exception("播放 Live2D 动作失败: %s", group)

    # -------------------------------------------------------------- drawing
    def _apply_parameters(self) -> None:
        model = self._model
        if model is None or not self._param_ids:
            return

        angle_z = 0.0
        brow = 0.0
        mouth_form = 0.0
        cheek = 0.0
        mouth_open = 0.0

        if self._state == THINKING:
            angle_z = 3.5
            brow = 0.35
            mouth_form = -0.1
        elif self._state == HAPPY:
            brow = 0.2
            mouth_form = 0.85
            cheek = 0.7
        elif self._state == ERROR:
            angle_z = -2.5
            brow = -0.55
            mouth_form = -0.55
        elif self._state == SPEAKING:
            self._mouth_phase += 0.55
            mouth_open = 0.12 + 0.42 * (0.5 + 0.5 * math.sin(self._mouth_phase))

        # Mouse gaze: only when the cursor is over the stage.
        pos = self.mapFromGlobal(QCursor.pos())
        inside = self.rect().contains(pos)
        if inside and self.width() > 0 and self.height() > 0:
            nx = max(-1.0, min(1.0, (pos.x() / self.width() - 0.5) * 2.0))
            ny = max(-1.0, min(1.0, (pos.y() / self.height() - 0.5) * 2.0))
            self._set_param("ParamEyeBallX", nx * 0.75, 0.75)
            self._set_param("ParamEyeBallY", -ny * 0.55, 0.75)
            self._set_param("ParamAngleX", nx * 8.0, 0.45)
            self._set_param("ParamAngleY", -ny * 6.0, 0.45)
        else:
            self._set_param("ParamEyeBallX", 0.0, 0.15)
            self._set_param("ParamEyeBallY", 0.0, 0.15)

        self._set_param("ParamMouthOpenY", mouth_open, 1.0)
        self._set_param("ParamMouthForm", mouth_form, 0.8)
        self._set_param("ParamAngleZ", angle_z, 0.5)
        self._set_param("ParamBrowLY", brow, 0.7)
        self._set_param("ParamBrowRY", brow, 0.7)
        self._set_param("ParamCheek", cheek, 0.8)
        if self._reaction_params:
            self._reaction_weight += (self._reaction_target - self._reaction_weight) * 0.35
            if self._reaction_weight < 0.01 and self._reaction_target <= 0.0:
                self._reaction_params = None
                self._reaction_weight = 0.0
            else:
                for param_id, value in self._reaction_params.items():
                    self._set_param(param_id, value, self._reaction_weight)

    def play_reaction(self, frames: list[dict[str, float]], fps: int = 12, *, weight: float = 0.85, loop: bool = False) -> None:
        if not frames:
            return
        self._reaction_frames = list(frames)
        self._reaction_index = 0
        self._reaction_params = dict(frames[0])
        self._reaction_target = max(0.0, min(1.0, float(weight)))
        self._reaction_loop = bool(loop)
        self._reaction_timer.setInterval(max(30, int(1000 / max(1, fps))))
        self._reaction_timer.start()

    def play_idle(self, frames: list[dict[str, float]], fps: int = 12) -> None:
        self.play_reaction(frames, fps=fps, weight=0.28, loop=True)

    def _reaction_tick(self) -> None:
        if not self._reaction_frames:
            self._reaction_timer.stop()
            self._reaction_target = 0.0
            return
        self._reaction_params = dict(self._reaction_frames[self._reaction_index])
        self._reaction_index += 1
        if self._reaction_index >= len(self._reaction_frames):
            if self._reaction_loop:
                self._reaction_index = 0
            else:
                self._reaction_timer.stop()
                self._reaction_frames = []
                self._reaction_target = 0.0

    def _set_param(self, param_id: str, value: float, weight: float = 1.0) -> None:
        if self._model is None:
            return
        actual = param_id if param_id in self._param_ids else self._param_lookup.get(param_id.replace("_", "").lower())
        if actual is None:
            return
        try:
            self._model.SetParamById(actual, float(value), float(weight))
        except Exception:
            logger.debug("设置参数失败: %s (%s)", param_id, actual, exc_info=True)

    # --------------------------------------------------------------- idle
    def _start_idle(self, *, force: bool = False) -> None:
        if self._model is None or not self.isVisible():
            return
        self._idle_generation += 1
        generation = self._idle_generation
        groups = list(self._model.GetMotionGroups())
        idle_group = next((group for group in groups if group.lower() == "idle"), None)
        try:
            if idle_group:
                self._model.StartRandomMotion(
                    idle_group,
                    _runtime().MotionPriority.IDLE,
                    onFinish=lambda *_args: self._after_idle(generation),
                )
        except Exception:
            logger.exception("播放 Live2D idle 动作失败")

    def _after_idle(self, generation: int) -> None:
        if generation != self._idle_generation or not self.isVisible():
            return
        QTimer.singleShot(900, self._start_idle)

    # -------------------------------------------------------------- pointer
    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed = True
            self._drag_moved = False
            self._drag_offset = (
                event.globalPosition().toPoint() - self.window().frameGeometry().topLeft()
            )
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._pressed and event.buttons() & Qt.MouseButton.LeftButton:
            if (event.globalPosition().toPoint() - self._drag_offset - self.window().pos()).manhattanLength() > 4:
                self._drag_moved = True
            self.window().move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            if not self._drag_moved:
                self.play_motion("tap")
            self._pressed = False
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed = False
            self.double_clicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    # ------------------------------------------------------------ lifecycle
    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        if self._loaded:
            self._timer.start()
            self._start_idle(force=True)

    def hideEvent(self, event) -> None:  # noqa: N802
        self._timer.stop()
        self._idle_generation += 1
        super().hideEvent(event)

    def shutdown(self) -> None:
        self._reaction_timer.stop()
        self._timer.stop()
        self._idle_generation += 1
        model, self._model = self._model, None
        self._loaded = False
        if model is None:
            return
        try:
            self.makeCurrent()
            model.StopAllMotions()
            model.DestroyRenderer()
        except Exception:
            logger.exception("清理 Live2D 模型失败")
        finally:
            try:
                self.doneCurrent()
            except Exception:
                pass

HARU_MODEL_JSON = PROJECT_ROOT / "assets" / "live2d" / "editable" / "haru" / "extract" / "runtime" / "haru.model3.json"


class HaruLive2DStage(WhaleLive2DStage):
    """Editable official Haru sample, framed as a half-body stage."""

    model_json = HARU_MODEL_JSON
    scale = 1.6
    offset_y = -0.35

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setToolTip("Haru 可编辑底模：按住拖动，双击聊天")