"""The settings dialog for API, model, and character preferences."""

from __future__ import annotations

import logging
import os
from dataclasses import replace
from urllib.parse import urlparse

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .api import DeepSeekClient
from .config import (
    MODEL_OPTIONS,
    AppConfig,
    default_persona,
    effective_api_key,
)
from .theme import make_app_icon
from .workers import ConnectionTestWorker

logger = logging.getLogger(__name__)


class SettingsDialog(QDialog):
    def __init__(self, config: AppConfig, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self.result_config: AppConfig | None = None
        self._test_worker: ConnectionTestWorker | None = None
        self._testing = False

        self.setWindowTitle(f"{config.pet_name} · 设置")
        self.setWindowIcon(make_app_icon(32))
        self.setModal(True)
        screen = QGuiApplication.primaryScreen()
        available_height = screen.availableGeometry().height() if screen else 1080
        self.resize(520, max(560, min(700, available_height - 70)))
        self.setMinimumSize(480, 560)
        self._build_ui()
        self._apply_values()

    # ------------------------------------------------------------------- UI
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 18)
        outer.setSpacing(10)

        title = QLabel("桌宠设置")
        title.setObjectName("dialogTitle")
        outer.addWidget(title)

        subtitle = QLabel("API Key 只保存在这台电脑上，不会上传到其他地方。")
        subtitle.setObjectName("dialogSubtitle")
        subtitle.setWordWrap(True)
        outer.addWidget(subtitle)

        scroll = QScrollArea()
        scroll.setObjectName("settingsScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background: #F7F9FE; border: none; }")
        body = QWidget()
        body.setObjectName("settingsBody")
        body.setAutoFillBackground(False)
        body.setStyleSheet("QWidget#settingsBody { background: #F7F9FE; }")
        form = QFormLayout(body)
        form.setContentsMargins(2, 8, 8, 8)
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(10)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)

        self.name_edit = QLineEdit()
        self.name_edit.setMaxLength(24)
        form.addRow(self._label("桌宠名字"), self.name_edit)

        self.appearance_combo = QComboBox()
        self.appearance_combo.addItem("Haru（官方可编辑底模）", "haru")
        self.appearance_combo.addItem("鲸鱼娘（Live2D）", "live2d")
        self.appearance_combo.addItem("大肥鱼（自绘动画）", "fish")
        form.addRow(self._label("角色外观"), self.appearance_combo)
        appearance_hint = QLabel("Haru 为 Live2D 官方示例模型，使用前请遵守其素材许可；鲸鱼娘为 CC BY-NC-SA 4.0。素材署名见 THIRD_PARTY_NOTICES.md。")
        appearance_hint.setObjectName("fieldHint")
        appearance_hint.setWordWrap(True)
        form.addRow("", appearance_hint)

        key_holder = QWidget()
        key_layout = QHBoxLayout(key_holder)
        key_layout.setContentsMargins(0, 0, 0, 0)
        key_layout.setSpacing(6)
        self.key_edit = QLineEdit()
        self.key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_edit.setPlaceholderText("sk-...")
        self.key_edit.setClearButtonEnabled(True)
        self.toggle_key = QPushButton("显示")
        self.toggle_key.setObjectName("linkButton")
        self.toggle_key.setCheckable(True)
        self.toggle_key.setFixedWidth(34)
        self.toggle_key.toggled.connect(self._toggle_key_visibility)
        key_layout.addWidget(self.key_edit, 1)
        key_layout.addWidget(self.toggle_key)
        form.addRow(self._label("DeepSeek API Key"), key_holder)

        self.key_hint = QLabel()
        self.key_hint.setObjectName("fieldHint")
        self.key_hint.setWordWrap(True)
        if os.environ.get("DEEPSEEK_API_KEY", "").strip():
            self.key_hint.setText("已检测到环境变量 DEEPSEEK_API_KEY，它的优先级高于这里填写的 Key。")
        else:
            self.key_hint.setText(
                "没有 Key 也可以先使用演示模式。"
                '<a href="https://platform.deepseek.com/api_keys" style="color:#4D6BFE;">获取 API Key</a>'
            )
            self.key_hint.setOpenExternalLinks(True)
        form.addRow("", self.key_hint)

        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText("https://api.deepseek.com")
        form.addRow(self._label("Base URL"), self.url_edit)

        self.model_combo = QComboBox()
        self.model_combo.setEditable(True)
        self.model_combo.addItems(MODEL_OPTIONS)
        form.addRow(self._label("模型"), self.model_combo)

        self.persona_edit = QPlainTextEdit()
        self.persona_edit.setObjectName("personaEdit")
        self.persona_edit.setPlaceholderText("描述桌宠的性格和说话方式…")
        self.persona_edit.setFixedHeight(112)
        form.addRow(self._label("人设提示词"), self.persona_edit)

        persona_hint = QLabel("提示：用 {name} 代表桌宠名字，发送时会自动替换。")
        persona_hint.setObjectName("fieldHint")
        form.addRow("", persona_hint)

        spin_row = QWidget()
        spin_layout = QHBoxLayout(spin_row)
        spin_layout.setContentsMargins(0, 0, 0, 0)
        spin_layout.setSpacing(14)
        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0.0, 2.0)
        self.temp_spin.setSingleStep(0.1)
        self.temp_spin.setDecimals(1)
        self.temp_spin.setToolTip("越高越活泼发散，越低越稳定")
        self.history_spin = QSpinBox()
        self.history_spin.setRange(4, 100)
        self.history_spin.setSingleStep(2)
        self.history_spin.setSuffix(" 条")
        self.history_spin.setToolTip("每次请求最多携带的上下文消息数")
        spin_layout.addWidget(QLabel("温度"))
        spin_layout.addWidget(self.temp_spin)
        spin_layout.addSpacing(10)
        spin_layout.addWidget(QLabel("上下文"))
        spin_layout.addWidget(self.history_spin)
        spin_layout.addStretch(1)
        form.addRow(self._label("生成参数"), spin_row)

        self.top_check = QCheckBox("窗口始终置顶")
        form.addRow("", self.top_check)

        scroll.setWidget(body)
        outer.addWidget(scroll, 1)

        test_row = QHBoxLayout()
        test_row.setSpacing(10)
        self.test_button = QPushButton("测试连接")
        self.test_button.setObjectName("secondaryButton")
        self.test_button.clicked.connect(self._test_connection)
        self.test_result = QLabel("保存前可以先测一下 API 是否可用")
        self.test_result.setObjectName("testResult")
        self.test_result.setWordWrap(True)
        self.test_result.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        test_row.addWidget(self.test_button)
        test_row.addWidget(self.test_result, 1)
        outer.addLayout(test_row)

        footer = QHBoxLayout()
        footer.addStretch(1)
        cancel = QPushButton("取消")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        save = QPushButton("保存")
        save.setObjectName("primaryButton")
        save.setDefault(True)
        save.clicked.connect(self._save)
        footer.addWidget(cancel)
        footer.addWidget(save)
        outer.addLayout(footer)

    @staticmethod
    def _label(text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("fieldLabel")
        return label

    def _apply_values(self) -> None:
        config = self._config
        self.name_edit.setText(config.pet_name)
        index = self.appearance_combo.findData(config.appearance)
        self.appearance_combo.setCurrentIndex(index if index >= 0 else 0)
        self.key_edit.setText(config.api_key)
        self.url_edit.setText(config.base_url)
        self.model_combo.setCurrentText(config.model)
        self.persona_edit.setPlainText(config.persona)
        self.temp_spin.setValue(config.temperature)
        self.history_spin.setValue(config.max_history)
        self.top_check.setChecked(config.always_on_top)

    def _toggle_key_visibility(self, shown: bool) -> None:
        self.key_edit.setEchoMode(
            QLineEdit.EchoMode.Normal if shown else QLineEdit.EchoMode.Password
        )
        self.toggle_key.setText("隐藏" if shown else "显示")

    # --------------------------------------------------------------- actions
    def _build_config(self) -> AppConfig:
        persona = self.persona_edit.toPlainText().strip() or default_persona(
            self.name_edit.text().strip()
        )
        model = self.model_combo.currentText().strip() or "deepseek-chat"
        return replace(
            self._config,
            pet_name=self.name_edit.text().strip() or "大肥鱼",
            appearance=self.appearance_combo.currentData() or "fish",
            api_key=self.key_edit.text().strip(),
            base_url=self.url_edit.text().strip().rstrip("/") or "https://api.deepseek.com",
            model=model,
            persona=persona,
            temperature=round(self.temp_spin.value(), 1),
            max_history=self.history_spin.value(),
            always_on_top=self.top_check.isChecked(),
        )

    def _validate(self, config: AppConfig) -> bool:
        if not config.pet_name:
            QMessageBox.warning(self, "设置", "桌宠名字不能为空。")
            return False
        parsed = urlparse(config.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            QMessageBox.warning(
                self,
                "设置",
                "Base URL 需要是完整地址，例如 https://api.deepseek.com",
            )
            return False
        return True

    def _save(self) -> None:
        if self._testing:
            QMessageBox.information(self, "设置", "连接测试还在进行，请稍等一下。")
            return
        config = self._build_config()
        if not self._validate(config):
            return
        self.result_config = config
        self.accept()

    def _test_connection(self) -> None:
        if self._testing:
            return
        config = self._build_config()
        if not self._validate(config):
            return
        api_key = effective_api_key(config)
        if not api_key:
            QMessageBox.information(self, "测试连接", "请先填写 DeepSeek API Key。")
            return
        self._testing = True
        self.test_button.setEnabled(False)
        self.test_result.setStyleSheet("color:#8B6A2A;")
        self.test_result.setText("正在连接 DeepSeek…")
        client = DeepSeekClient(
            api_key,
            config.base_url,
            config.model,
            timeout=25,
        )
        worker = ConnectionTestWorker(client, self)
        self._test_worker = worker
        worker.success.connect(self._test_ok)
        worker.failure.connect(self._test_failed)
        worker.finished.connect(self._test_finished)
        worker.start()

    def _test_ok(self, reply: str) -> None:
        self.test_result.setStyleSheet("color:#1E9B6C;")
        short = reply.replace("\n", " ")[:80]
        self.test_result.setText(f"连接成功：{short}")

    def _test_failed(self, message: str) -> None:
        self.test_result.setStyleSheet("color:#C9485C;")
        self.test_result.setText(message.replace("\n", " "))

    def _test_finished(self) -> None:
        self._testing = False
        self.test_button.setEnabled(True)
        worker = self._test_worker
        self._test_worker = None
        if worker is not None:
            worker.deleteLater()

    def reject(self) -> None:  # noqa: N802
        if self._testing:
            QMessageBox.information(self, "设置", "连接测试还在进行，请稍等一下。")
            return
        super().reject()

    def closeEvent(self, event) -> None:  # noqa: N802
        if self._testing:
            QMessageBox.information(self, "设置", "连接测试还在进行，请稍等一下。")
            event.ignore()
            return
        super().closeEvent(event)
