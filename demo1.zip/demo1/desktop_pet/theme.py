"""Colors, Qt style sheet, and the programmatically drawn app icon."""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QRadialGradient,
)

INK = "#1D2B45"
MUTED = "#6F7F97"
ACCENT = "#4D6BFE"
ACCENT_DARK = "#3C56D9"
PANEL = "rgba(255, 252, 249, 250)"
BORDER = "rgba(38, 73, 122, 26)"
DANGER = "#E0566B"
SUCCESS = "#1E9B6C"
WARNING = "#D58A2A"

APP_STYLE = """
* {
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    outline: none;
}
QWidget#petRoot {
    background: transparent;
}
QFrame#chatPanel {
    background: rgba(255, 252, 249, 250);
    border: 1px solid rgba(38, 73, 122, 24);
    border-radius: 24px;
}
QLabel#petName {
    color: #1D2B45;
    font-size: 16px;
    font-weight: 700;
}
QLabel#statusText {
    color: #7B8AA0;
    font-size: 10.5px;
}
QToolButton#headerButton {
    background: transparent;
    border: none;
    border-radius: 13px;
    color: #5E6E86;
    font-size: 16px;
    padding: 0;
}
QToolButton#headerButton:hover {
    background: rgba(77, 107, 254, 18);
    color: #3C56D9;
}
QToolButton#headerButton:pressed {
    background: rgba(77, 107, 254, 32);
}
QToolButton#headerButton:disabled {
    color: #C2CAD7;
}
QScrollArea#chatScroll {
    background: transparent;
    border: none;
}
QScrollArea#chatScroll > QWidget > QWidget {
    background: transparent;
}
QScrollBar:vertical {
    background: transparent;
    width: 5px;
    margin: 2px 0;
}
QScrollBar::handle:vertical {
    background: rgba(90, 112, 145, 62);
    border-radius: 2px;
    min-height: 24px;
}
QScrollBar::handle:vertical:hover {
    background: rgba(90, 112, 145, 105);
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: transparent;
    height: 0;
}
QLabel#bubbleAssistant {
    background: #FFFFFF;
    border: 1px solid rgba(38, 73, 122, 22);
    border-top-left-radius: 5px;
    border-top-right-radius: 17px;
    border-bottom-left-radius: 17px;
    border-bottom-right-radius: 17px;
    padding: 9px 12px;
    color: #23334D;
    font-size: 12.5px;
}
QLabel#bubbleUser {
    background: #4D6BFE;
    border: 1px solid rgba(255, 255, 255, 30);
    border-top-left-radius: 17px;
    border-top-right-radius: 5px;
    border-bottom-left-radius: 17px;
    border-bottom-right-radius: 17px;
    padding: 9px 12px;
    color: #FFFFFF;
    font-size: 12.5px;
}
QLabel#bubbleError {
    background: rgba(224, 86, 107, 15);
    border: 1px solid rgba(224, 86, 107, 60);
    border-radius: 13px;
    padding: 8px 11px;
    color: #B13F52;
    font-size: 11.5px;
}
QPlainTextEdit#chatInput {
    background: #F3F6FD;
    border: 1.5px solid rgba(77, 107, 254, 12);
    border-radius: 18px;
    padding: 8px 11px;
    color: #22324B;
    font-size: 12.5px;
    selection-background-color: #B9C8FF;
    selection-color: #17233A;
}
QPlainTextEdit#chatInput:focus {
    background: #FFFFFF;
    border: 1.5px solid #7C92FF;
}
QPushButton#sendButton {
    background: #4D6BFE;
    border: none;
    border-radius: 18px;
    color: #FFFFFF;
    font-size: 12.5px;
    font-weight: 600;
    padding: 0 18px;
    min-height: 36px;
}
QPushButton#sendButton:hover {
    background: #3C56D9;
}
QPushButton#sendButton:pressed {
    background: #3149C4;
}
QPushButton#sendButton[streaming="true"] {
    background: #E0566B;
}
QPushButton#sendButton[streaming="true"]:hover {
    background: #C9485C;
}
QLabel#inputHint {
    color: #A0ABBC;
    font-size: 9.5px;
}
QDialog {
    background: #F7F9FE;
}
QLabel#dialogTitle {
    color: #1D2B45;
    font-size: 19px;
    font-weight: 700;
}
QLabel#dialogSubtitle {
    color: #7B8AA0;
    font-size: 11px;
}
QLabel#fieldLabel {
    color: #3A4A63;
    font-size: 11.5px;
    font-weight: 600;
}
QLabel#fieldHint {
    color: #8B98AB;
    font-size: 10px;
}
QLabel#testResult {
    color: #6E7E96;
    font-size: 10.5px;
}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit#personaEdit {
    background: #FFFFFF;
    border: 1px solid #DCE4F2;
    border-radius: 9px;
    padding: 6px 9px;
    color: #21324B;
    font-size: 11.5px;
    selection-background-color: #B9C8FF;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QPlainTextEdit#personaEdit:focus {
    border: 1px solid #7C92FF;
}
QComboBox::drop-down {
    border: none;
    width: 22px;
}
QPushButton#primaryButton {
    background: #4D6BFE;
    border: none;
    border-radius: 9px;
    color: #FFFFFF;
    font-size: 12px;
    font-weight: 600;
    padding: 8px 20px;
}
QPushButton#primaryButton:hover {
    background: #3C56D9;
}
QPushButton#secondaryButton {
    background: #FFFFFF;
    border: 1px solid #D9E1EF;
    border-radius: 9px;
    color: #475870;
    font-size: 12px;
    padding: 8px 16px;
}
QPushButton#secondaryButton:hover {
    border-color: #9DB0D4;
    background: #F8FAFF;
}
QPushButton#linkButton {
    background: transparent;
    border: none;
    color: #4D6BFE;
    font-size: 10.5px;
    padding: 0;
    text-align: left;
}
QPushButton#linkButton:hover {
    color: #3049C7;
    text-decoration: underline;
}
QCheckBox {
    color: #3A4A63;
    font-size: 11.5px;
    spacing: 7px;
}
QMenu {
    background: #FFFCF9;
    border: 1px solid rgba(38, 73, 122, 35);
    border-radius: 10px;
    padding: 6px;
    color: #27374F;
}
QMenu::item {
    padding: 6px 22px 6px 14px;
    border-radius: 6px;
}
QMenu::item:selected {
    background: rgba(77, 107, 254, 20);
    color: #3149C4;
}
QMenu::separator {
    height: 1px;
    background: rgba(38, 73, 122, 20);
    margin: 5px 8px;
}
QToolTip {
    background: #25364F;
    color: #FFFFFF;
    border: none;
    border-radius: 5px;
    padding: 4px 7px;
    font-size: 10px;
}
"""


def make_app_icon(size: int = 64) -> QIcon:
    """Draw a small fish icon so the app has no binary asset dependency."""

    size = max(16, int(size))
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    painter.scale(size / 64.0, size / 64.0)

    background = QLinearGradient(4, 2, 58, 62)
    background.setColorAt(0.0, QColor("#6E8BFF"))
    background.setColorAt(1.0, QColor("#32B7C9"))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(background)
    painter.drawEllipse(QRectF(2, 2, 60, 60))

    glow = QRadialGradient(42, 19, 30)
    glow.setColorAt(0.0, QColor(255, 255, 255, 70))
    glow.setColorAt(1.0, QColor(255, 255, 255, 0))
    painter.setBrush(glow)
    painter.drawEllipse(QRectF(8, 4, 50, 50))

    tail = QPainterPath()
    tail.moveTo(23, 34)
    tail.cubicTo(17, 28, 13, 24, 9, 22)
    tail.cubicTo(12, 29, 15, 32, 10, 38)
    tail.cubicTo(14, 39, 18, 41, 23, 38)
    tail.closeSubpath()
    painter.setBrush(QColor("#FFD3C9"))
    painter.drawPath(tail)

    body = QPainterPath()
    body.moveTo(23, 34)
    body.cubicTo(29, 22, 45, 21, 53, 31)
    body.cubicTo(57, 37, 53, 47, 44, 50)
    body.cubicTo(34, 53, 25, 45, 23, 34)
    body.closeSubpath()
    painter.setPen(QPen(QColor(255, 255, 255, 120), 1.2))
    painter.setBrush(QColor("#E8FBFF"))
    painter.drawPath(body)

    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor("#1D3557"))
    painter.drawEllipse(QRectF(43, 32, 4.2, 5.2))
    painter.setBrush(QColor(255, 255, 255, 210))
    painter.drawEllipse(QRectF(44.2, 33, 1.5, 1.8))

    painter.setPen(QPen(QColor("#E88A93"), 1.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    mouth = QPainterPath()
    mouth.moveTo(51, 40)
    mouth.cubicTo(52, 42, 54, 42, 55, 40)
    painter.drawPath(mouth)

    painter.end()
    return QIcon(pixmap)


def make_app_pixmap(size: int = 64) -> QPixmap:
    icon = make_app_icon(size)
    return icon.pixmap(size, size)