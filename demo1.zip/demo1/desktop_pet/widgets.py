"""Custom chat widgets: bubbles, typing dots, and the growing input box."""

from __future__ import annotations

import re

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontMetrics,
    QGuiApplication,
    QPainter,
    QPen,
    QTextCharFormat,
    QTextCursor,
    QTextDocument,
)
from PySide6.QtWidgets import QLabel, QMenu, QPlainTextEdit, QSizePolicy, QWidget

MAX_BUBBLE_WIDTH = 298
MAX_INPUT_CHARS = 2000


def _plain_for_measure(text: str) -> str:
    text = re.sub(r"```.*?```", "代码", text, flags=re.S)
    text = re.sub(r"[*_`#>\[\]]", "", text)
    return text or " "


def markdown_to_html(text: str, color: str = "#23334D") -> str:
    """Render a safe subset of Markdown through QTextDocument."""

    document = QTextDocument()
    font = QFont("Microsoft YaHei UI", 10)
    document.setDefaultFont(font)
    document.setDocumentMargin(0)
    document.setDefaultStyleSheet(
        """
        p { margin: 0 0 4px 0; }
        ul, ol { margin: 0 0 4px 0; }
        li { margin: 0; }
        h1, h2, h3, h4 { font-size: 12pt; margin: 2px 0 4px 0; }
        pre { background-color: #F2F5FB; margin: 4px 0; }
        code { background-color: #F2F5FB; font-family: Consolas, monospace; }
        a { color: #3C56D9; }
        """
    )
    document.setMarkdown(text)

    cursor = QTextCursor(document)
    cursor.select(QTextCursor.SelectionType.Document)
    fmt = QTextCharFormat()
    fmt.setForeground(QColor(color))
    cursor.mergeCharFormat(fmt)
    return document.toHtml()


class ChatBubble(QLabel):
    """A selectable, copyable message bubble that sizes itself to its text."""

    def __init__(self, role: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.role = role
        self._raw = ""
        self.setWordWrap(True)
        self.setTextFormat(Qt.TextFormat.RichText)
        self.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
            | Qt.TextInteractionFlag.LinksAccessibleByMouse
        )
        self.setOpenExternalLinks(True)
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Minimum)
        self.setMaximumWidth(MAX_BUBBLE_WIDTH)
        self.setObjectName(
            {
                "user": "bubbleUser",
                "assistant": "bubbleAssistant",
                "error": "bubbleError",
            }.get(role, "bubbleAssistant")
        )
        self.setCursor(Qt.CursorShape.IBeamCursor)

    @property
    def raw_text(self) -> str:
        return self._raw

    def set_content(self, text: str, *, final: bool = True) -> None:
        self._raw = text
        visible = text if final or self.role != "assistant" else text + "▍"
        if self.role == "user" or self.role == "error":
            self.setTextFormat(Qt.TextFormat.PlainText)
            self.setText(visible)
        else:
            self.setTextFormat(Qt.TextFormat.RichText)
            self.setText(markdown_to_html(visible))
        self._resize_to_text(visible)
        self.updateGeometry()

    def _resize_to_text(self, visible: str) -> None:
        metrics = QFontMetrics(self.font())
        lines = _plain_for_measure(visible).splitlines() or [" "]
        longest = max(metrics.horizontalAdvance(line) for line in lines)
        width = max(74, min(MAX_BUBBLE_WIDTH, longest + 30))
        self.setFixedWidth(width)
        self.adjustSize()

    def contextMenuEvent(self, event) -> None:  # noqa: N802
        menu = QMenu(self)
        copy_action = menu.addAction("复制这条消息")
        copy_action.triggered.connect(self._copy)
        menu.exec(event.globalPos())

    def _copy(self) -> None:
        QGuiApplication.clipboard().setText(self._raw)


class TypingIndicator(QWidget):
    """Three softly bouncing dots used while waiting for the first token."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedSize(58, 32)
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(60)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(58, 32)

    def _tick(self) -> None:
        self._phase += 0.18
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(QPen(QColor(38, 73, 122, 24), 1))
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawRoundedRect(QRectF(0.5, 2.5, 48, 27), 13, 13)
        for index in range(3):
            import math

            offset = (math.sin(self._phase - index * 0.9) + 1) * 1.6
            alpha = 90 + int((math.sin(self._phase - index * 0.9) + 1) * 55)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(90, 128, 190, alpha))
            painter.drawEllipse(
                QPointF(14 + index * 10, 16 - offset),
                2.5,
                2.5,
            )
        painter.end()


class GrowingTextEdit(QPlainTextEdit):
    """Enter sends, Shift+Enter adds a newline, height grows up to a limit."""

    submit = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("chatInput")
        self.setPlaceholderText("和大肥鱼说点什么…")
        self.setFixedHeight(42)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setTabChangesFocus(True)
        self.document().setDocumentMargin(0)
        self.document().contentsChanged.connect(self._adjust_height)
        self.document().documentLayout().documentSizeChanged.connect(lambda *_: self._adjust_height())
        self.textChanged.connect(self._limit_text)
        palette = self.palette()
        palette.setColor(palette.ColorRole.PlaceholderText, QColor("#A3AFC1"))
        self.setPalette(palette)

    def _adjust_height(self) -> None:
        doc_height = self.document().size().height()
        height = int(max(42, min(96, doc_height + 20)))
        if height != self.height():
            self.setFixedHeight(height)

    def keyPressEvent(self, event) -> None:  # noqa: N802
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                super().keyPressEvent(event)
                return
            self.submit.emit()
            event.accept()
            return
        super().keyPressEvent(event)

    def insertFromMimeData(self, source) -> None:  # noqa: N802
        remaining = MAX_INPUT_CHARS - len(self.toPlainText())
        if remaining <= 0:
            return
        text = source.text()[:remaining]
        self.insertPlainText(text)

    def append_text(self, text: str) -> None:
        remaining = MAX_INPUT_CHARS - len(self.toPlainText())
        if remaining > 0:
            self.insertPlainText(text[:remaining])

    def _limit_text(self) -> None:
        if len(self.toPlainText()) > MAX_INPUT_CHARS:
            cursor = self.textCursor()
            position = cursor.position()
            self.blockSignals(True)
            self.setPlainText(self.toPlainText()[:MAX_INPUT_CHARS])
            self.blockSignals(False)
            cursor.setPosition(min(position, MAX_INPUT_CHARS))
            self.setTextCursor(cursor)
        self._adjust_height()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._adjust_height()