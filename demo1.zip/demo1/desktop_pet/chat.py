"""Conversation state and offline demo replies."""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime

MAX_USER_CHARS = 4000
MAX_CONTEXT_CHARS = 14000


@dataclass(slots=True)
class ChatMessage:
    role: str
    content: str


class ChatSession:
    """Keeps a bounded conversation and builds API messages."""

    def __init__(
        self,
        system_prompt: str,
        *,
        max_history: int = 24,
    ) -> None:
        self._system_prompt = system_prompt
        self._max_history = max(4, min(100, int(max_history)))
        self._history: list[ChatMessage] = []

    def configure(self, system_prompt: str, max_history: int) -> None:
        self._system_prompt = system_prompt
        self._max_history = max(4, min(100, int(max_history)))

    def reset(self) -> None:
        self._history.clear()

    @property
    def history(self) -> tuple[ChatMessage, ...]:
        return tuple(self._history)

    @property
    def has_messages(self) -> bool:
        return bool(self._history)

    def add_user(self, text: str) -> ChatMessage:
        cleaned = text.strip()
        if not cleaned:
            raise ValueError("empty user message")
        message = ChatMessage("user", cleaned[:MAX_USER_CHARS])
        self._history.append(message)
        return message

    def add_assistant(self, text: str) -> ChatMessage:
        message = ChatMessage("assistant", text.strip())
        self._history.append(message)
        return message

    def pop_last_user(self) -> None:
        if self._history and self._history[-1].role == "user":
            self._history.pop()

    def build_messages(self) -> list[dict[str, str]]:
        """Return system + a trimmed history that starts with a user turn."""

        selected = self._history[-self._max_history :]
        while selected and selected[0].role != "user":
            selected = selected[1:]

        # Keep the context under a rough character budget, dropping whole pairs.
        total = sum(len(item.content) for item in selected)
        while len(selected) > 2 and total > MAX_CONTEXT_CHARS:
            removed = selected.pop(0)
            total -= len(removed.content)
            while selected and selected[0].role != "user":
                removed = selected.pop(0)
                total -= len(removed.content)
        while selected and selected[0].role != "user":
            selected = selected[1:]

        result = [{"role": "system", "content": self._system_prompt}]
        result.extend({"role": item.role, "content": item.content} for item in selected)
        return result


def welcome_message(pet_name: str, has_key: bool, appearance: str = "fish") -> str:
    name = pet_name.strip() or "大肥鱼"
    form = "今天换上了鲸鱼娘的样子" if appearance == "live2d" else "住在你桌面上的小鱼"
    if has_key:
        return (
            f"咕噜咕噜～我是{name}，{form}。\n"
            "今天想聊点什么？直接敲下面就好。"
        )
    return (
        f"咕噜咕噜～我是{name}，{form}。\n"
        "现在还是**演示模式**：点右上角的 ⚙ 填好 DeepSeek API Key，"
        "我就能真正联网陪你聊天啦。你也可以先在这里敲我试试。"
    )


def demo_reply(user_text: str, pet_name: str = "大肥鱼") -> str:
    """A transparent offline reply used when no API key is configured."""

    name = pet_name.strip() or "大肥鱼"
    text = user_text.strip()
    lowered = text.lower()

    if any(word in lowered for word in ("你好", "hello", "hi", "嗨", "在吗")):
        return (
            f"在的呀，我是{name}～*摆摆尾巴*\n"
            "不过现在是演示模式，正式聊天要先在右上角 ⚙ 里填 DeepSeek API Key 哦。"
        )
    if any(word in lowered for word in ("api", "key", "密钥", "设置", "配置", "怎么用")):
        return (
            "点聊天框右上角的 ⚙ 打开设置：\n"
            "1. 填入 DeepSeek API Key；\n"
            "2. Base URL 默认 https://api.deepseek.com；\n"
            "3. 模型选 deepseek-chat，保存即可。\n"
            "Key 会保存在本机 config.json 里，不会上传到别处。"
        )
    if any(word in lowered for word in ("你是谁", "介绍", "名字")):
        return (
            f"我是{name}，一只用 Python 做的桌面小鱼。\n"
            "等接上 Live2D 之后，我还会眨眼、摆尾、做表情。现在先由占位动画顶班～"
        )
    if any(word in lowered for word in ("几点", "时间")):
        return f"现在是 {datetime.now().strftime('%H:%M')}。*吐了个泡泡*"
    if any(word in lowered for word in ("谢谢", "感谢")):
        return "不客气～等填好 API Key，我就能帮你做更多事了。"
    if any(word in lowered for word in ("再见", "拜拜", "晚安")):
        return "拜拜～我就在桌面上，想我了再点开。*沉到水底*"
    if any(word in lowered for word in ("你好笨", "笨", "傻")):
        return "呜…等我连上 DeepSeek 的大脑袋，就不笨了。*鼓成河豚*"

    samples = (
        f"我听见啦：「{text[:32]}」。\n不过现在只是演示模式，还没连上 DeepSeek。点右上角 ⚙ 填入 API Key，我就能认真回答你了。",
        f"*歪头* 这句话我先记在小本本上。\n演示模式只能陪你聊聊设置和日常；填好 API Key 后，再来问我正经问题吧。",
        f"咕噜…「{text[:32]}」听起来挺有意思。\n先把我接上 DeepSeek 吧，不然我只能吐泡泡给你看。",
    )
    return random.choice(samples)