"""The frameless desktop pet window, chat panel, tray, and wiring."""

from __future__ import annotations

import logging
import time
from pathlib import Path

from PySide6.QtCore import QPoint, QTimer, Qt
from PySide6.QtGui import QColor, QCloseEvent, QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QLabel,
    QMenu,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSystemTrayIcon,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .api import DeepSeekClient
from .chat import ChatSession, demo_reply, welcome_message
from .config import (
    AppConfig,
    effective_api_key,
    effective_base_url,
    effective_model,
    save_config,
)
from .live2d import ERROR, HAPPY, IDLE, SPEAKING, THINKING, create_stage
from .settings_dialog import SettingsDialog
from .theme import DANGER, MUTED, SUCCESS, WARNING, make_app_icon
from .widgets import ChatBubble, GrowingTextEdit, TypingIndicator
from .workers import ChatWorker

logger = logging.getLogger(__name__)

WINDOW_WIDTH = 400
WINDOW_HEIGHT = 660


class PetWindow(QWidget):
    def __init__(
        self,
        config: AppConfig,
        *,
        config_path: Path | None = None,
        demo_override: bool = False,
    ) -> None:
        super().__init__()
        self.config = config
        self._config_path = config_path
        self._demo_override = demo_override
        self._worker: ChatWorker | None = None
        self._streaming = False
        self._assistant_bubble: ChatBubble | None = None
        self._response_text = ""
        self._last_user_text = ""
        self._last_reply_text = ""
        self._reacted_query = ""
        self._pool = None
        self._pool_next = 0.0
        self._pool_timer = QTimer(self)
        self._pool_timer.setInterval(1100)
        self._pool_timer.timeout.connect(self._pool_tick)
        self._typing_row: QWidget | None = None
        self._allow_close = False
        self._tray_tip_shown = False
        self._initializing = True

        self._session = ChatSession(config.system_prompt(), max_history=config.max_history)

        self.setWindowTitle(f"{config.pet_name} · DeepSeek 桌宠")
        self.setWindowIcon(make_app_icon(64))
        window_flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if config.always_on_top:
            window_flags |= Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(window_flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setObjectName("petRoot")

        self._position_timer = QTimer(self)
        self._position_timer.setSingleShot(True)
        self._position_timer.setInterval(700)
        self._position_timer.timeout.connect(self._save_position)
        QTimer.singleShot(1800, self._pool_tick)
        self._pool_timer.start()

        self._build_ui()
        self._build_tray()
        self._install_shortcuts()
        self._apply_config()
        self._reset_chat()

        self._initializing = False
        QTimer.singleShot(0, self._restore_position)

    # ------------------------------------------------------------------- UI
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        self.root_layout = root
        root.setContentsMargins(16, 10, 16, 18)
        root.setSpacing(0)

        self.stage, self._appearance = create_stage(self.config.appearance, self)
        self._wire_stage(self.stage)
        root.addWidget(self.stage, 0)

        self.panel = QFrame(self)
        self.panel.setObjectName("chatPanel")
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(30)
        shadow.setOffset(0, 9)
        shadow.setColor(QColor(21, 43, 79, 65))
        self.panel.setGraphicsEffect(shadow)
        root.addWidget(self.panel, 1)

        panel_layout = QVBoxLayout(self.panel)
        panel_layout.setContentsMargins(13, 10, 13, 12)
        panel_layout.setSpacing(7)

        header = QWidget(self.panel)
        header.setFixedHeight(43)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(2, 0, 0, 0)
        header_layout.setSpacing(2)

        title_column = QVBoxLayout()
        title_column.setContentsMargins(0, 0, 0, 0)
        title_column.setSpacing(0)
        self.name_label = QLabel("大肥鱼")
        self.name_label.setObjectName("petName")
        self.status_label = QLabel("●  演示模式")
        self.status_label.setObjectName("statusText")
        self.status_label.setStyleSheet(f"color:{WARNING};")
        title_column.addWidget(self.name_label)
        title_column.addWidget(self.status_label)
        header_layout.addLayout(title_column)
        header_layout.addStretch(1)

        self.new_button = self._header_button("＋", "开始新对话")
        self.new_button.clicked.connect(self._new_chat)
        self.appearance_button = self._header_button("鱼", "切换回大肥鱼")
        self.appearance_button.clicked.connect(self._toggle_appearance)
        self.settings_button = self._header_button("⚙", "设置")
        self.settings_button.clicked.connect(self._open_settings)
        self.hide_button = self._header_button("—", "隐藏到托盘")
        self.hide_button.clicked.connect(self._hide_to_tray)
        header_layout.addWidget(self.new_button)
        header_layout.addWidget(self.appearance_button)
        header_layout.addWidget(self.settings_button)
        header_layout.addWidget(self.hide_button)
        panel_layout.addWidget(header)

        self.chat_scroll = QScrollArea(self.panel)
        self.chat_scroll.setObjectName("chatScroll")
        self.chat_scroll.setWidgetResizable(True)
        self.chat_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.chat_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.chat_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.chat_container = QWidget()
        self.chat_container.setObjectName("chatContainer")
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.setContentsMargins(1, 1, 5, 1)
        self.chat_layout.setSpacing(7)
        self.chat_layout.addStretch(1)
        self.chat_scroll.setWidget(self.chat_container)
        panel_layout.addWidget(self.chat_scroll, 1)

        input_row = QHBoxLayout()
        input_row.setContentsMargins(0, 0, 0, 0)
        input_row.setSpacing(6)
        self.input = GrowingTextEdit(self.panel)
        self.input.submit.connect(self._on_submit)
        self.send_button = QPushButton(self.panel)
        self.send_button.setObjectName("sendButton")
        self.send_button.setText("发送")
        self.send_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_button.setFixedHeight(38)
        self.send_button.setMinimumWidth(64)
        self.send_button.clicked.connect(self._on_submit)
        input_row.addWidget(self.input, 1)
        input_row.addWidget(self.send_button)
        panel_layout.addLayout(input_row)

        self.input_hint = QLabel("Enter 发送 · Shift + Enter 换行")
        self.input_hint.setObjectName("inputHint")
        self.input_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        panel_layout.addWidget(self.input_hint)

    def _header_button(self, text: str, tooltip: str) -> QToolButton:
        button = QToolButton(self.panel)
        button.setObjectName("headerButton")
        button.setText(text)
        button.setToolTip(tooltip)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setFixedSize(26, 26)
        return button

    def _wire_stage(self, stage: QWidget) -> None:
        stage.double_clicked.connect(self._focus_input)
        stage.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        stage.customContextMenuRequested.connect(self._show_context_menu)
        if hasattr(stage, "load_failed"):
            stage.load_failed.connect(self._on_live2d_failed)

    def _update_appearance_button(self) -> None:
        current = getattr(self, "_appearance", "fish")
        if current == "haru":
            self.appearance_button.setText("鲸")
            self.appearance_button.setToolTip("切换到鲸鱼娘（旧 Live2D）")
        elif current == "live2d":
            self.appearance_button.setText("鱼")
            self.appearance_button.setToolTip("切换到大肥鱼（自绘动画）")
        else:
            self.appearance_button.setText("春")
            self.appearance_button.setToolTip("切换到 Haru（官方可编辑底模）")

    def _toggle_appearance(self) -> None:
        order = ["haru", "live2d", "fish"]
        try:
            index = order.index(self._appearance)
        except ValueError:
            index = 0
        self._set_appearance(order[(index + 1) % len(order)])

    def _set_appearance(self, appearance: str, *, persist: bool = True, notify: bool = True) -> None:
        if appearance not in {"fish", "live2d"}:
            appearance = "fish"
        if appearance == self._appearance:
            self._update_appearance_button()
            return
        if self._streaming:
            self._set_status("回复结束后再切换外观", "warn")
            return

        old_stage = self.stage
        new_stage, actual = create_stage(appearance, self)
        self.root_layout.replaceWidget(old_stage, new_stage)
        self.stage = new_stage
        self._appearance = actual
        self._wire_stage(new_stage)
        new_stage.show()
        new_stage.set_state(IDLE)
        shutdown = getattr(old_stage, "shutdown", None)
        if callable(shutdown):
            shutdown()
        old_stage.hide()
        old_stage.deleteLater()

        self.config.appearance = actual
        self._update_appearance_button()
        if persist:
            try:
                save_config(self.config, self._config_path)
            except OSError as exc:
                logger.warning("保存外观设置失败: %s", exc)

        if actual == appearance and not self._session.has_messages:
            self._reset_chat()
        if actual != appearance and notify:
            self._add_bubble(
                "🐋 Live2D 暂时不可用，已经切回大肥鱼。\n"
                "请确认 live2d-py 已安装，且 assets/live2d/whale 模型文件完整。",
                "error",
            )
            self._set_status("Live2D 不可用，已切回", "warn")

    def _on_live2d_failed(self, message: str) -> None:
        if self._appearance != "live2d":
            return
        logger.error("Live2D 加载失败: %s", message)
        QTimer.singleShot(0, lambda: self._fallback_from_live2d(message))

    def _fallback_from_live2d(self, message: str) -> None:
        if self._appearance != "live2d":
            return
        self._set_appearance("fish", persist=True, notify=False)
        self._add_bubble(f"⚠️ Live2D 加载失败，已切回大肥鱼。\n{message}", "error")
        self._set_status("Live2D 加载失败", "error")

    # ------------------------------------------------------------ configuration
    def _apply_config(self) -> None:
        self.name_label.setText(self.config.pet_name)
        self.setWindowTitle(f"{self.config.pet_name} · DeepSeek 桌宠")
        self.input.setPlaceholderText(f"和{self.config.pet_name}说点什么…")
        self._session.configure(self.config.system_prompt(), self.config.max_history)
        self._update_appearance_button()
        if self.tray is not None:
            self.tray.setToolTip(f"{self.config.pet_name} · DeepSeek 桌宠")
        self._refresh_status()

    def _has_live_key(self) -> bool:
        return not self._demo_override and bool(effective_api_key(self.config))

    def _refresh_status(self) -> None:
        if self._streaming:
            self._set_status("正在回复…", "busy")
        elif self._has_live_key():
            self._set_status("DeepSeek 已配置", "ok")
        else:
            self._set_status("演示模式 · 未配置 Key", "warn")

    def _set_status(self, text: str, tone: str = "idle") -> None:
        colors = {
            "ok": SUCCESS,
            "warn": WARNING,
            "busy": "#4D6BFE",
            "error": DANGER,
            "idle": MUTED,
        }
        color = colors.get(tone, MUTED)
        self.status_label.setText(f"●  {text}")
        self.status_label.setStyleSheet(f"color:{color};")

    # ---------------------------------------------------------------- messages
    def _add_bubble(self, text: str, role: str) -> ChatBubble:
        bubble = ChatBubble(role, self.chat_container)
        bubble.set_content(text)
        row = QWidget(self.chat_container)
        row.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(0)
        if role == "user":
            row_layout.addStretch(1)
            row_layout.addWidget(bubble, 0, Qt.AlignmentFlag.AlignTop)
        else:
            row_layout.addWidget(bubble, 0, Qt.AlignmentFlag.AlignTop)
            row_layout.addStretch(1)
        self.chat_layout.insertWidget(self.chat_layout.count() - 1, row)
        self._scroll_to_bottom()
        return bubble

    def _remove_bubble(self, bubble: ChatBubble) -> None:
        row = bubble.parentWidget()
        if row is None:
            return
        self.chat_layout.removeWidget(row)
        row.deleteLater()

    def _show_typing(self) -> None:
        self._remove_typing()
        row = QWidget(self.chat_container)
        row.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        indicator = TypingIndicator(row)
        row_layout.addWidget(indicator, 0, Qt.AlignmentFlag.AlignTop)
        row_layout.addStretch(1)
        self.chat_layout.insertWidget(self.chat_layout.count() - 1, row)
        self._typing_row = row
        self._scroll_to_bottom()

    def _remove_typing(self) -> None:
        if self._typing_row is None:
            return
        self.chat_layout.removeWidget(self._typing_row)
        self._typing_row.deleteLater()
        self._typing_row = None

    def _scroll_to_bottom(self) -> None:
        QTimer.singleShot(0, self._do_scroll_to_bottom)

    def _do_scroll_to_bottom(self) -> None:
        bar = self.chat_scroll.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _reset_chat(self) -> None:
        while self.chat_layout.count() > 1:
            item = self.chat_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._session.reset()
        self._assistant_bubble = None
        self._response_text = ""
        self._remove_typing()
        self._add_bubble(
            welcome_message(self.config.pet_name, self._has_live_key(), self._appearance),
            "assistant",
        )

    # ------------------------------------------------------------------ tray
    def _build_tray(self) -> None:
        self.tray: QSystemTrayIcon | None = None
        self.tray_menu: QMenu | None = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            logger.warning("系统托盘不可用")
            return
        self.tray = QSystemTrayIcon(make_app_icon(64), self)
        self.tray.setToolTip(f"{self.config.pet_name} · DeepSeek 桌宠")
        menu = QMenu()
        show_action = menu.addAction("显示桌宠")
        show_action.triggered.connect(self._show_window)
        new_action = menu.addAction("开始新对话")
        new_action.triggered.connect(self._new_chat)
        appearance_action = menu.addAction("切换外观（大肥鱼 / 鲸鱼娘）")
        appearance_action.triggered.connect(self._toggle_appearance)
        settings_action = menu.addAction("设置…")
        settings_action.triggered.connect(self._open_settings)
        menu.addSeparator()
        quit_action = menu.addAction("退出")
        quit_action.triggered.connect(self.quit_app)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()
        self.tray_menu = menu

    def _tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            if self.isVisible():
                self._hide_to_tray()
            else:
                self._show_window()

    def _install_shortcuts(self) -> None:
        self._shortcuts = []
        for sequence, callback in (
            ("Ctrl+,", self._open_settings),
            ("Ctrl+N", self._new_chat),
            ("Escape", self._hide_to_tray),
        ):
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(callback)
            self._shortcuts.append(shortcut)

    # ---------------------------------------------------------------- placement
    def _restore_position(self) -> None:
        target = None
        if self.config.window_x is not None and self.config.window_y is not None:
            candidate = QPoint(self.config.window_x, self.config.window_y)
            for screen in QGuiApplication.screens():
                visible = screen.availableGeometry()
                if visible.adjusted(-40, -20, 40, 20).contains(candidate + QPoint(60, 60)):
                    target = candidate
                    break
        if target is None:
            screen = QGuiApplication.primaryScreen()
            if screen is None:
                return
            area = screen.availableGeometry()
            target = QPoint(
                area.right() - self.width() - 26,
                area.bottom() - self.height() - 22,
            )
        self.move(target)

    def _save_position(self) -> None:
        if self._initializing:
            return
        self.config.window_x = self.x()
        self.config.window_y = self.y()
        try:
            save_config(self.config, self._config_path)
        except OSError as exc:
            logger.warning("保存窗口位置失败: %s", exc)

    def moveEvent(self, event) -> None:  # noqa: N802
        super().moveEvent(event)
        if not self._initializing:
            self._position_timer.start()
    # ------------------------------------------------------------------ chat
    def _on_submit(self) -> None:
        if self._streaming:
            self._stop_streaming()
            return
        text = self.input.toPlainText().strip()
        if not text:
            self.input.setFocus()
            return
        if len(text) > 2000:
            text = text[:2000]
        self.input.clear()
        self._add_bubble(text, "user")
        self._session.add_user(text)
        self._begin_reply(text)

    def _begin_reply(self, user_text: str) -> None:
        self._streaming = True
        self._response_text = ""
        self._last_user_text = user_text
        self._reacted_query = ""
        if self._pool is not None:
            self._pool.add(user_text, weight=1.4, kind="chat")
        self._assistant_bubble = None
        self._set_streaming_ui(True)
        self._set_status("正在思考…", "busy")
        self.stage.set_state(THINKING)
        self._show_typing()

        api_key = effective_api_key(self.config)
        if self._demo_override or not api_key:
            worker = ChatWorker(
                None,
                [],
                demo_text=demo_reply(user_text, self.config.pet_name),
                parent=self,
            )
        else:
            client = DeepSeekClient(
                api_key,
                effective_base_url(self.config),
                effective_model(self.config),
                timeout=75,
            )
            worker = ChatWorker(
                client,
                self._session.build_messages(),
                temperature=self.config.temperature,
                parent=self,
            )

        self._worker = worker
        worker.chunk.connect(self._on_chunk)
        worker.succeeded.connect(self._on_success)
        worker.failed.connect(self._on_failure)
        worker.cancelled.connect(self._on_cancelled)
        worker.finished.connect(lambda w=worker: self._on_worker_finished(w))
        worker.start()

    def _on_chunk(self, piece: str) -> None:
        if not piece:
            return
        self._remove_typing()
        if self._assistant_bubble is None:
            self._response_text = piece
            self._assistant_bubble = self._add_bubble(piece, "assistant")
        else:
            self._response_text += piece
            self._assistant_bubble.set_content(self._response_text, final=False)
        self.stage.set_state(SPEAKING)
        self._set_status("正在回复…", "busy")
        self._scroll_to_bottom()

    def _on_success(self, reply: str) -> None:
        self._remove_typing()
        full = reply.strip()
        if not full:
            self._on_failure("这次没有收到内容，请再试一次。")
            return
        if self._assistant_bubble is None:
            self._assistant_bubble = self._add_bubble(full, "assistant")
        else:
            self._assistant_bubble.set_content(full, final=True)
        self._response_text = full
        self._session.add_assistant(full)
        self._finish_streaming()
        self.stage.set_state(HAPPY)
        self._last_reply_text = full
        if self._pool is not None:
            self._pool.add(full, weight=1.2, kind="reply")
        QTimer.singleShot(600, self._pool_tick)
        QTimer.singleShot(1200, self._stage_idle_if_possible)
        self._scroll_to_bottom()

    def _pool_tick(self) -> None:
        if not hasattr(self.stage, "play_reaction"):
            return
        if self._pool is None:
            try:
                from .context_pool import ContextPool
                self._pool = ContextPool()
            except Exception:
                logger.exception("语境池初始化失败")
                return
        now = time.monotonic()
        self._pool.tick()
        if self._streaming or now < self._pool_next:
            return
        query = self._last_user_text.strip()
        if query and query != self._reacted_query:
            frames, matched, score = self._pool.sample_for(query)
            if frames and score >= 0.12:
                self._reacted_query = query
                self.stage.play_reaction(frames, fps=12, weight=0.68)
                self._pool_next = now + 3.2
                logger.info("语境反应: %s -> %s (%.2f)", query[:40], matched[:40], score)
                return
        frames = self._pool.sample_idle()
        if frames:
            self.stage.play_reaction(frames, fps=10, weight=0.22)
            self._pool_next = now + 5.2
        self._pool_next = now + 5.2

    def _play_text_reaction(self, reply: str) -> None:
        # Kept for older callers; the context-pool heartbeat is the active path.
        return

    def _on_failure(self, message: str) -> None:
        self._remove_typing()
        partial = self._response_text.strip()
        if partial and self._assistant_bubble is not None:
            self._assistant_bubble.set_content(partial, final=True)
            self._session.add_assistant(partial)
        else:
            if self._assistant_bubble is not None:
                self._remove_bubble(self._assistant_bubble)
            self._assistant_bubble = None
            self._session.pop_last_user()
        short = message.strip() or "请求失败，请稍后再试。"
        self._add_bubble("⚠️ " + short, "error")
        self._finish_streaming("连接异常", "error")
        self.stage.set_state(ERROR)
        QTimer.singleShot(2200, self._stage_idle_if_possible)
        self._scroll_to_bottom()

    def _on_cancelled(self, partial: str) -> None:
        self._remove_typing()
        partial = (partial or self._response_text).strip()
        if partial:
            if self._assistant_bubble is None:
                self._assistant_bubble = self._add_bubble(partial, "assistant")
            else:
                self._assistant_bubble.set_content(partial, final=True)
            self._session.add_assistant(partial)
        else:
            if self._assistant_bubble is not None:
                self._remove_bubble(self._assistant_bubble)
            self._assistant_bubble = None
            self._session.pop_last_user()
        self._finish_streaming("已停止", "idle")
        self.stage.set_state(IDLE)

    def _stop_streaming(self) -> None:
        worker = self._worker
        if worker is None:
            return
        worker.cancel()
        self.send_button.setEnabled(False)
        self._set_status("正在停止…", "busy")

    def _finish_streaming(self, status: str | None = None, tone: str = "ok") -> None:
        self._streaming = False
        self._assistant_bubble = None
        self._response_text = ""
        self._set_streaming_ui(False)
        if status:
            self._set_status(status, tone)
        else:
            self._refresh_status()
        self.input.setFocus()

    def _set_streaming_ui(self, streaming: bool) -> None:
        self.send_button.setText("停止" if streaming else "发送")
        self.send_button.setProperty("streaming", streaming)
        self.send_button.style().unpolish(self.send_button)
        self.send_button.style().polish(self.send_button)
        self.send_button.setEnabled(True)
        self.input.setEnabled(not streaming)
        self.new_button.setEnabled(not streaming)
        self.settings_button.setEnabled(not streaming)
        self.input.setPlaceholderText(
            "正在回复…" if streaming else f"和{self.config.pet_name}说点什么…"
        )

    def _on_worker_finished(self, worker: ChatWorker) -> None:
        if self._worker is worker:
            self._worker = None
        worker.deleteLater()

    def _stage_idle_if_possible(self) -> None:
        if not self._streaming:
            self.stage.set_state(IDLE)

    def _focus_input(self) -> None:
        if not self._streaming:
            self.input.setFocus()
            cursor = self.input.textCursor()
            cursor.movePosition(cursor.MoveOperation.End)
            self.input.setTextCursor(cursor)

    # --------------------------------------------------------------- actions
    def _new_chat(self) -> None:
        if self._streaming:
            self._set_status("请先停止当前回复", "warn")
            return
        self._reset_chat()
        self.input.clear()
        self._refresh_status()
        self._stage_idle_if_possible()
        self.input.setFocus()

    def _open_settings(self) -> None:
        if self._streaming:
            self._set_status("回复结束后再改设置", "warn")
            return
        dialog = SettingsDialog(self.config, self)
        if not dialog.exec():
            return
        new_config = dialog.result_config
        if new_config is None:
            return
        try:
            save_config(new_config, self._config_path)
        except OSError as exc:
            logger.exception("保存设置失败")
            QMessageBox.critical(self, "保存失败", f"无法写入配置文件：\n{exc}")
            return
        old_top = self.config.always_on_top
        old_key_state = self._has_live_key()
        old_name = self.config.pet_name
        old_appearance = self._appearance
        self.config = new_config
        self._apply_config()
        if new_config.appearance != old_appearance:
            self._set_appearance(new_config.appearance, persist=False, notify=True)
            self.config.appearance = self._appearance
            try:
                save_config(self.config, self._config_path)
            except OSError:
                logger.exception("保存实际外观设置失败")
        if not self._session.has_messages and (
            old_key_state != self._has_live_key() or old_name != new_config.pet_name
        ):
            self._reset_chat()
        if old_top != new_config.always_on_top:
            self.setWindowFlag(
                Qt.WindowType.WindowStaysOnTopHint,
                new_config.always_on_top,
            )
            self.show()
        self._set_status("设置已保存", "ok")
        QTimer.singleShot(1600, self._refresh_status)

    def _hide_to_tray(self) -> None:
        if self.tray is None:
            self._set_status("系统托盘不可用", "error")
            return
        if not self.isVisible():
            return
        self._position_timer.stop()
        self._save_position()
        self.hide()
        if not self._tray_tip_shown:
            self.tray.showMessage(
                "桌宠躲起来了",
                f"点击托盘里的{self.config.pet_name}就能把我叫回来。",
                QSystemTrayIcon.MessageIcon.Information,
                2500,
            )
            self._tray_tip_shown = True

    def _show_window(self) -> None:
        if not self.isVisible():
            self.show()
        self.raise_()
        self.activateWindow()
        self._stage_idle_if_possible()
        self.input.setFocus()

    def _show_context_menu(self, position: QPoint) -> None:
        menu = QMenu(self)
        new_action = menu.addAction("开始新对话")
        new_action.triggered.connect(self._new_chat)
        appearance_action = menu.addAction("切换外观（大肥鱼 / 鲸鱼娘）")
        appearance_action.triggered.connect(self._toggle_appearance)
        settings_action = menu.addAction("设置…")
        settings_action.triggered.connect(self._open_settings)
        hide_action = menu.addAction("隐藏到托盘")
        hide_action.triggered.connect(self._hide_to_tray)
        menu.addSeparator()
        quit_action = menu.addAction("退出")
        quit_action.triggered.connect(self.quit_app)
        menu.exec(self.stage.mapToGlobal(position))

    def _shutdown_stage(self) -> None:
        shutdown = getattr(self.stage, "shutdown", None)
        if callable(shutdown):
            shutdown()

    def quit_app(self) -> None:
        self._allow_close = True
        self._position_timer.stop()
        self._save_position()
        worker = self._worker
        if worker is not None:
            worker.cancel()
            if not worker.wait(1800):
                logger.warning("聊天线程未及时退出，强制结束")
                worker.terminate()
                worker.wait(600)
            self._worker = None
        self._shutdown_stage()
        if self.tray is not None:
            self.tray.hide()
        QApplication.instance().quit()

    def closeEvent(self, event: QCloseEvent) -> None:  # noqa: N802
        if self._allow_close:
            event.accept()
            return
        if self.tray is not None:
            self._hide_to_tray()
            event.ignore()
            return
        self._allow_close = True
        self._save_position()
        self._shutdown_stage()
        event.accept()
        QApplication.instance().quit()