"""Weighted context pool for continuous idle and reaction selection.

The pool holds chat turns and captured subtitle/motion fragments. Every tick
decays weights, evicts a small low-weight slice, and adds one more fragment.
Idle is not a separate hand-authored animation: it is sampled from the same
text/context pool, using low-energy captured fragments.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import random
import time

from . import reaction


@dataclass
class ContextItem:
    text: str
    tags: list[str] = field(default_factory=list)
    frames: list[dict] = field(default_factory=list)
    weight: float = 1.0
    kind: str = "chat"
    created: float = field(default_factory=time.monotonic)


class ContextPool:
    def __init__(self, capacity: int = 128, seed: int = 7) -> None:
        self.capacity = max(16, int(capacity))
        self.rng = random.Random(seed)
        self.items: list[ContextItem] = []
        self.bank = reaction.load_index()
        self._bank_index = 0
        bank_order = list(range(len(self.bank)))
        self.rng.shuffle(bank_order)
        self._bank_order = bank_order
        for _ in range(min(24, len(self._bank_order))):
            self._add_next_bank()

    def _add_next_bank(self) -> None:
        if not self._bank_order:
            return
        index = self._bank_order[self._bank_index % len(self._bank_order)]
        self._bank_index += 1
        item = self.bank[index]
        self.items.append(ContextItem(
            text=item.get("text", ""),
            tags=list(item.get("tags", [])),
            frames=item.get("frames", []),
            weight=0.32,
            kind="bank",
        ))

    def add(self, text: str, *, weight: float = 1.2, kind: str = "chat") -> None:
        text = (text or "").strip()
        if not text:
            return
        self.items.append(ContextItem(
            text=text,
            tags=reaction.tone_tags(text),
            frames=[],
            weight=max(0.05, float(weight)),
            kind=kind,
        ))
        self._trim()

    def tick(self, now: float | None = None) -> None:
        for item in self.items:
            item.weight *= 0.985
        self._trim()
        self._add_next_bank()

    def _trim(self) -> None:
        if len(self.items) <= self.capacity:
            return
        remove_count = max(1, int(len(self.items) * 0.04))
        # Keep very recent chat turns even if their weight is low.
        ranked = sorted(
            self.items,
            key=lambda item: (item.weight + (0.4 if item.kind == "chat" else 0.0)),
        )
        remove_ids = {id(item) for item in ranked[:remove_count]}
        self.items = [item for item in self.items if id(item) not in remove_ids]

    def latest_chat(self) -> str:
        chats = [item for item in self.items if item.kind == "chat" and item.text]
        if not chats:
            return ""
        return max(chats, key=lambda item: item.created).text

    def sample_idle(self) -> list[dict]:
        candidates = [item for item in self.items if item.frames]
        if not candidates:
            return reaction.idle_clip()

        def energy(item: ContextItem) -> float:
            frames = item.frames
            mouth = sum(abs(float(f.get("ParamMouthOpenY", 0.0)) - 0.1) for f in frames) / len(frames)
            head = sum(abs(float(f.get("ParamAngleX", 0.0))) / 30.0 for f in frames) / len(frames)
            return mouth + 0.8 * head

        candidates = sorted(candidates, key=energy)[:max(3, len(candidates) // 3)]
        total = sum(max(0.01, item.weight) for item in candidates)
        pick = self.rng.uniform(0, total)
        upto = 0.0
        for item in candidates:
            upto += max(0.01, item.weight)
            if upto >= pick:
                return item.frames
        return candidates[0].frames

    def sample_for(self, query: str) -> tuple[list[dict], str, float]:
        if not query:
            return self.sample_idle(), "", 0.0
        frames, matched, score = reaction.match(query)
        if frames:
            return frames, matched, score
        return self.sample_idle(), "", 0.0