"""大肥鱼桌宠 - a DeepSeek-powered desktop companion."""

__version__ = "0.2.0"