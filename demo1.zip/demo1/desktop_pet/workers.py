"""Background workers that keep network I/O off the UI thread."""

from __future__ import annotations

import logging
import threading
import time

from PySide6.QtCore import QThread, Signal

from .api import DeepSeekClient, DeepSeekError

logger = logging.getLogger(__name__)


class ChatWorker(QThread):
    """Streams a DeepSeek reply (or a local demo reply) into Qt signals."""

    chunk = Signal(str)
    succeeded = Signal(str)
    failed = Signal(str)
    cancelled = Signal(str)

    def __init__(
        self,
        client: DeepSeekClient | None,
        messages: list[dict[str, str]],
        *,
        demo_text: str | None = None,
        temperature: float = 1.1,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._client = client
        self._messages = messages
        self._demo_text = demo_text
        self._temperature = temperature
        self._cancel = threading.Event()

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def is_cancelled(self) -> bool:
        return self._cancel.is_set()

    def run(self) -> None:
        pieces: list[str] = []
        try:
            if self._client is None:
                stream = self._demo_stream(self._demo_text or "")
            else:
                stream = self._client.stream_chat(
                    self._messages,
                    temperature=self._temperature,
                    cancel_event=self._cancel,
                )

            for piece in stream:
                if self._cancel.is_set():
                    break
                if not piece:
                    continue
                pieces.append(piece)
                self.chunk.emit(piece)

            full = "".join(pieces).strip()
            if self._cancel.is_set():
                self.cancelled.emit(full)
            elif full:
                self.succeeded.emit(full)
            else:
                self.failed.emit("这次没有收到内容，请再试一次。")
        except DeepSeekError as exc:
            if self._cancel.is_set():
                self.cancelled.emit("".join(pieces).strip())
            else:
                logger.warning("DeepSeek 请求失败: %s", exc)
                self.failed.emit(str(exc))
        except Exception as exc:  # last-resort safety net for the worker thread
            logger.exception("聊天线程异常")
            if self._cancel.is_set():
                self.cancelled.emit("".join(pieces).strip())
            else:
                self.failed.emit(f"出了点意外：{exc}")

    def _demo_stream(self, text: str):
        # Split on punctuation first, then small character groups, so the demo
        # still feels like a streaming reply.
        buffer = ""
        for char in text:
            if self._cancel.is_set():
                return
            buffer += char
            if char in "。！？\n，、；：…" or len(buffer) >= 4:
                yield buffer
                buffer = ""
                time.sleep(0.035)
        if buffer:
            yield buffer


class ConnectionTestWorker(QThread):
    success = Signal(str)
    failure = Signal(str)

    def __init__(self, client: DeepSeekClient, parent=None) -> None:
        super().__init__(parent)
        self._client = client

    def run(self) -> None:
        try:
            reply = self._client.test_connection(timeout=25)
            self.success.emit(reply)
        except DeepSeekError as exc:
            self.failure.emit(str(exc))
        except Exception as exc:
            logger.exception("连接测试异常")
            self.failure.emit(f"测试失败：{exc}")