"""Retarget calibrated facial motion to the current Live2D parameter set."""

from __future__ import annotations

from typing import Any

TARGET_NAMES = [
    "ParamAngleX", "ParamAngleY", "ParamAngleZ", "ParamEyeLOpen", "ParamEyeROpen",
    "ParamEyeBallX", "ParamEyeBallY", "ParamMouthOpenY", "ParamMouthForm",
    "ParamBrowLY", "ParamBrowRY", "ParamCheek", "ParamBodyAngleX",
]


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(v)))


def channels(frame: dict[str, Any]) -> dict[str, float]:
    b = frame["blendshapes"]
    g = lambda k: float(b.get(k, 0.0))
    return {
        "eye_l": 1.0 - g("eyeBlinkLeft"),
        "eye_r": 1.0 - g("eyeBlinkRight"),
        "jaw": g("jawOpen"),
        "smile": (g("mouthSmileLeft") + g("mouthSmileRight")) / 2,
        "brow": g("browInnerUp") - (g("browDownLeft") + g("browDownRight")) / 2,
        "gaze_x": (g("eyeLookOutLeft") + g("eyeLookInRight")) - (g("eyeLookInLeft") + g("eyeLookOutRight")),
        "gaze_y": (g("eyeLookUpLeft") + g("eyeLookUpRight")) - (g("eyeLookDownLeft") + g("eyeLookDownRight")),
        "yaw": float(frame["head"][0]),
        "pitch": float(frame["head"][1]),
        "roll": float(frame["head"][2]),
    }


def piecewise(value: float, spec: dict[str, float], tmin: float, tmid: float, tmax: float) -> float:
    lo, mid, hi = spec["min"], spec["neutral"], spec["max"]
    if value <= mid:
        u = 0.0 if mid <= lo else (value - lo) / (mid - lo)
        return float(tmid + clamp(u, 0, 1) * (tmin - tmid))
    u = 0.0 if hi <= mid else (value - mid) / (hi - mid)
    return float(tmid + clamp(u, 0, 1) * (tmax - tmid))


def target_params(frame: dict[str, Any], profile: dict[str, Any]) -> dict[str, float]:
    c = channels(frame)
    eye_l = piecewise(c["eye_l"], profile["eye_l"], 0.0, 0.85, 1.0)
    eye_r = piecewise(c["eye_r"], profile["eye_r"], 0.0, 0.85, 1.0)
    jaw = piecewise(c["jaw"], profile["jaw"], 0.0, 0.1, 1.0)
    smile = piecewise(c["smile"], profile["smile"], -0.2, 0.0, 0.8)
    brow = piecewise(c["brow"], profile["brow"], -0.6, 0.0, 0.6)
    gx = piecewise(c["gaze_x"], profile["gaze_x"], -0.8, 0.0, 0.8)
    gy = piecewise(c["gaze_y"], profile["gaze_y"], -0.8, 0.0, 0.8)
    yaw = piecewise(c["yaw"], profile["yaw"], -30.0, 0.0, 30.0)
    pitch = piecewise(c["pitch"], profile["pitch"], -22.0, 0.0, 22.0)
    roll = piecewise(c["roll"], profile["roll"], -18.0, 0.0, 18.0)
    return {
        "ParamAngleX": yaw,
        "ParamAngleY": -pitch,
        "ParamAngleZ": roll,
        "ParamBodyAngleX": yaw * 0.4,
        "ParamEyeLOpen": clamp(eye_l, 0, 1),
        "ParamEyeROpen": clamp(eye_r, 0, 1),
        "ParamEyeBallX": clamp(gx, -1, 1),
        "ParamEyeBallY": clamp(gy, -1, 1),
        "ParamMouthOpenY": clamp(jaw, 0, 1),
        "ParamMouthForm": clamp(smile, -1, 1),
        "ParamBrowLY": clamp(brow, -1, 1),
        "ParamBrowRY": clamp(brow, -1, 1),
        "ParamCheek": clamp(smile * 0.65, 0, 1),
    }