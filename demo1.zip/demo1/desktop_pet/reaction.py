"""Text compression and captured-motion retrieval for chat reactions.

The compressor extracts roles and tone markers from text. The motion itself
comes from the captured human clip, not from hand-authored expression labels.
"""

from __future__ import annotations

import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
INDEX = ROOT / "analysis" / "reaction_index.json"

_CANONICALIZER = None
_INDEX_CACHE: list[dict] | None = None

_TONE = {
    "问": ("吗", "？", "?", "什么", "怎么", "为什么", "是不是", "呢", "干嘛", "哪", "谁"),
    "请": ("请", "帮我", "能不能", "可以吗", "麻烦", "拜托"),
    "怨": ("又", "老是", "怎么", "凭什么", "烦", "真是", "干嘛", "天天", "每次"),
    "讽": ("呵呵", "真厉害", "阴阳", "装", "可真是", "牛"),
    "玩": ("哈哈", "笑死", "逗", "玩笑", "乐"),
    "否": ("不", "没", "别", "不是", "拒绝"),
}


def normalize(text: str) -> str:
    return re.sub(r"[，。！？!?；;：:、,.…~～\s]+", "", text or "")


def bigrams(text: str) -> set[str]:
    s = normalize(text)
    return {s[i:i+2] for i in range(len(s)-1)} or ({s} if s else set())


def tone_tags(text: str) -> list[str]:
    out = []
    for tag, words in _TONE.items():
        if any(word in text for word in words):
            out.append(tag)
    if text.rstrip().endswith(("？", "?")):
        if "问" not in out:
            out.append("问")
    if re.search(r"不|没|别", text):
        if "否" not in out:
            out.append("否")
    return out


def compress(text: str) -> dict:
    """Use the local canonicalizer when available; fall back to raw text."""
    source = (text or "").strip()
    frame = None
    global _CANONICALIZER
    try:
        if _CANONICALIZER is None:
            from tools.text_compiler.canonicalizer import ChineseCanonicalizer
            _CANONICALIZER = ChineseCanonicalizer()
        frame = _CANONICALIZER.canonicalize(source)
    except Exception:
        frame = None
    canonical = getattr(frame, "canonical", "") or normalize(source)
    tags = tone_tags(source)
    if frame is not None:
        if getattr(frame, "subject_inferred", False):
            tags.append("省主")
        if getattr(frame, "passive", False):
            tags.append("被")
        if getattr(frame, "topic", None):
            tags.append("倒装")
    return {"source": source, "canonical": canonical, "tags": list(dict.fromkeys(tags))}


def load_index() -> list[dict]:
    global _INDEX_CACHE
    if _INDEX_CACHE is not None:
        return _INDEX_CACHE
    if not INDEX.is_file():
        _INDEX_CACHE = []
        return _INDEX_CACHE
    try:
        data = json.loads(INDEX.read_text(encoding="utf-8"))
        _INDEX_CACHE = data if isinstance(data, list) else []
    except Exception:
        _INDEX_CACHE = []
    return _INDEX_CACHE


def _score(query: dict, item: dict) -> float:
    a, b = bigrams(query["canonical"]), bigrams(item.get("text", ""))
    if not a or not b:
        return 0.0
    inter = len(a & b)
    text_score = inter / max(1.0, (len(a) * len(b)) ** 0.5)
    qtags, itags = set(query["tags"]), set(item.get("tags", []))
    tag_score = len(qtags & itags) / max(1, len(qtags | itags)) if qtags else 0.0
    return 0.7 * tag_score + 0.3 * text_score


def match(text: str) -> tuple[list[dict], str, float]:
    query = compress(text)
    best = None
    best_score = -1.0
    for item in load_index():
        score = _score(query, item)
        if score > best_score:
            best, best_score = item, score
    if best is None or not best.get("frames"):
        return [], query["canonical"], 0.0
    return best["frames"], best.get("text", ""), best_score

def idle_clip() -> list[dict]:
    """Pick a low-mouth, low-head-energy captured clip for idle breathing."""
    items = [item for item in load_index() if item.get("frames")]
    if not items:
        return []
    def energy(item: dict) -> float:
        frames = item["frames"]
        mouth = sum(abs(float(frame.get("ParamMouthOpenY", 0.0)) - 0.1) for frame in frames) / len(frames)
        head = sum(abs(float(frame.get("ParamAngleX", 0.0))) / 30.0 for frame in frames) / len(frames)
        return mouth + 0.8 * head
    return min(items, key=energy)["frames"]