"""A small DeepSeek chat client built on the Python standard library."""

from __future__ import annotations

import http.client
import json
import logging
import socket
import ssl
import threading
import urllib.error
import urllib.request
from collections.abc import Iterable, Iterator
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 60
MAX_ERROR_DETAIL = 280


class DeepSeekError(RuntimeError):
    """A user-facing DeepSeek request error."""

    def __init__(self, message: str, *, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


def normalize_base_url(base_url: str) -> str:
    """Accept a root URL, a /v1 URL, or a full chat-completions URL."""

    value = (base_url or "").strip().rstrip("/")
    suffix = "/chat/completions"
    if value.endswith(suffix):
        value = value[: -len(suffix)].rstrip("/")
    return value or "https://api.deepseek.com"


def chat_endpoint(base_url: str) -> str:
    return normalize_base_url(base_url) + "/chat/completions"


def _truncate(text: str) -> str:
    text = " ".join(text.split())
    return text if len(text) <= MAX_ERROR_DETAIL else text[:MAX_ERROR_DETAIL] + "…"


def _extract_error_detail(body: bytes) -> str:
    if not body:
        return ""
    text = body.decode("utf-8", errors="replace").strip()
    try:
        payload = json.loads(text)
    except ValueError:
        return _truncate(text)
    if isinstance(payload, dict):
        error = payload.get("error")
        if isinstance(error, dict):
            message = error.get("message") or error.get("type") or ""
            return _truncate(str(message))
        if isinstance(error, str):
            return _truncate(error)
        message = payload.get("message")
        if isinstance(message, str):
            return _truncate(message)
    return _truncate(text)


def http_error_message(status: int, detail: str = "") -> str:
    if status == 400:
        message = "请求参数有误，请检查模型名称或 Base URL。"
    elif status == 401:
        message = "API Key 无效或已失效，请在设置里重新填写。"
    elif status == 402:
        message = "DeepSeek 账户余额不足，请先充值后再试。"
    elif status == 403:
        message = "当前 API Key 没有访问权限。"
    elif status == 404:
        message = "接口地址不存在，请检查 Base URL 是否为 https://api.deepseek.com。"
    elif status == 429:
        message = "请求太频繁或额度受限，请稍等一会儿再试。"
    elif 500 <= status < 600:
        message = f"DeepSeek 服务暂时不可用（HTTP {status}），请稍后再试。"
    else:
        message = f"DeepSeek 返回了 HTTP {status}。"
    if detail:
        message += f"\n详细信息：{detail}"
    return message


def iter_sse_content(
    lines: Iterable[bytes | str],
    cancel_event: threading.Event | None = None,
) -> Iterator[str]:
    """Yield text deltas from an OpenAI-compatible SSE response."""

    for raw_line in lines:
        if cancel_event is not None and cancel_event.is_set():
            return
        if isinstance(raw_line, bytes):
            line = raw_line.decode("utf-8", errors="replace")
        else:
            line = raw_line
        line = line.strip()
        if not line or line.startswith(":") or not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            break
        try:
            event = json.loads(data)
        except ValueError:
            logger.debug("忽略无法解析的 SSE 数据: %r", data[:160])
            continue
        if not isinstance(event, dict):
            continue
        if event.get("error"):
            error = event["error"]
            if isinstance(error, dict):
                detail = str(error.get("message") or error)
            else:
                detail = str(error)
            raise DeepSeekError(f"DeepSeek 返回错误：{_truncate(detail)}")
        choices = event.get("choices")
        if not isinstance(choices, list) or not choices:
            continue
        choice = choices[0]
        if not isinstance(choice, dict):
            continue
        delta = choice.get("delta")
        if not isinstance(delta, dict):
            continue
        content = delta.get("content")
        if isinstance(content, str) and content:
            yield content


class DeepSeekClient:
    """Minimal blocking/streaming client for the DeepSeek chat API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.deepseek.com",
        model: str = "deepseek-chat",
        *,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = (api_key or "").strip()
        self.base_url = normalize_base_url(base_url)
        self.model = (model or "deepseek-chat").strip() or "deepseek-chat"
        self.timeout = timeout
        self.endpoint = chat_endpoint(self.base_url)

    def _headers(self, *, stream: bool) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
            "User-Agent": "DafeiyuDesktopPet/0.1",
        }

    def _body(
        self,
        messages: list[dict[str, str]],
        *,
        stream: bool,
        temperature: float,
        max_tokens: int,
    ) -> bytes:
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": stream,
            "temperature": max(0.0, min(2.0, float(temperature))),
            "max_tokens": max(16, int(max_tokens)),
        }
        return json.dumps(payload, ensure_ascii=False).encode("utf-8")

    def _open(
        self,
        messages: list[dict[str, str]],
        *,
        stream: bool,
        temperature: float,
        max_tokens: int,
    ):
        if not self.api_key:
            raise DeepSeekError("还没有配置 DeepSeek API Key，请先打开设置填写。")
        request = urllib.request.Request(
            self.endpoint,
            data=self._body(
                messages,
                stream=stream,
                temperature=temperature,
                max_tokens=max_tokens,
            ),
            headers=self._headers(stream=stream),
            method="POST",
        )
        try:
            return urllib.request.urlopen(request, timeout=self.timeout)
        except urllib.error.HTTPError as exc:
            try:
                detail = _extract_error_detail(exc.read())
            except OSError:
                detail = ""
            raise DeepSeekError(
                http_error_message(exc.code, detail),
                status=exc.code,
            ) from exc
        except urllib.error.URLError as exc:
            reason = exc.reason
            if isinstance(reason, (TimeoutError, socket.timeout)):
                raise DeepSeekError("连接 DeepSeek 超时，请检查网络后重试。") from exc
            if isinstance(reason, ssl.SSLError):
                raise DeepSeekError("HTTPS 证书校验失败，请检查系统时间或代理设置。") from exc
            raise DeepSeekError(
                f"无法连接 DeepSeek：{_truncate(str(reason))}。请检查网络、代理或 Base URL。"
            ) from exc
        except (TimeoutError, socket.timeout) as exc:
            raise DeepSeekError("连接 DeepSeek 超时，请检查网络后重试。") from exc
        except (http.client.HTTPException, OSError) as exc:
            raise DeepSeekError(f"网络请求失败：{_truncate(str(exc))}") from exc

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float = 1.1,
        max_tokens: int = 1200,
        cancel_event: threading.Event | None = None,
    ) -> Iterator[str]:
        """Yield assistant text deltas as they arrive."""

        response = self._open(
            messages,
            stream=True,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        try:
            with response:
                yield from iter_sse_content(response, cancel_event)
        except DeepSeekError:
            raise
        except (TimeoutError, socket.timeout) as exc:
            raise DeepSeekError("等待 DeepSeek 回复时超时了，请重试。") from exc
        except (http.client.HTTPException, OSError) as exc:
            if cancel_event is not None and cancel_event.is_set():
                return
            raise DeepSeekError(f"读取回复时网络中断：{_truncate(str(exc))}") from exc

    def test_connection(self, *, timeout: float | None = None) -> str:
        """Send a tiny non-streaming request and return the model reply."""

        old_timeout = self.timeout
        if timeout is not None:
            self.timeout = timeout
        try:
            response = self._open(
                [
                    {"role": "system", "content": "你是一个连接测试助手。"},
                    {"role": "user", "content": "只回复：连接成功"},
                ],
                stream=False,
                temperature=0.0,
                max_tokens=16,
            )
            with response:
                body = response.read()
        except DeepSeekError:
            raise
        except (OSError, http.client.HTTPException) as exc:
            raise DeepSeekError(f"读取测试响应失败：{_truncate(str(exc))}") from exc
        finally:
            self.timeout = old_timeout

        try:
            payload: Any = json.loads(body.decode("utf-8", errors="replace"))
            content = payload["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise DeepSeekError("DeepSeek 返回了无法识别的响应。") from exc
        if not isinstance(content, str) or not content.strip():
            raise DeepSeekError("DeepSeek 返回了空响应。")
        return content.strip()